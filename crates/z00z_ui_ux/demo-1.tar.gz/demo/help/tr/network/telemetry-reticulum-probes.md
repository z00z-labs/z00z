---
id: telemetry.reticulum.probes
title: Reticulum probları
summary: Reticulum probları, kayıtlı yerel Reticulum köprüsünden salt okunur taşıyıcı kanıtı sunar.
scope: context
---
## Bu görünümü kullanma {#current-view}
- Yerel köprünün sağladığı Reticulum probları kanıtını inceleyin; bu görünüm Reticulum durumunu değiştirmez.
- Kullanılamaz, güncel yerel anlık görüntü olmadığı anlamına gelir; adresler, hedefler, rotalar ve yükler gizli kalır.

## Yerel ve güvenli çalışma
- Cüzdan sırları ve özel taşıma verileri Yardım içine girmez.
- Bu Yardım uygulamayla paketlenir ve çevrimdışı çalışır.
