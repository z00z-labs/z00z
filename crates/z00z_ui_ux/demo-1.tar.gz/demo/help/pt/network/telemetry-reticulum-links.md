---
id: telemetry.reticulum.links
title: Ligações do Reticulum
summary: Ligações do Reticulum apresenta evidências de transporte só de leitura da ponte Reticulum local registada.
scope: context
---
## Utilizar esta vista {#current-view}
- Consulte as evidências de Ligações do Reticulum fornecidas pela ponte local; esta vista não altera o Reticulum.
- Indisponível significa que não existe um snapshot local recente; endereços, destinos, rotas e payloads permanecem ocultos.

## Funcionamento local e seguro
- Os segredos da carteira e os dados privados de transporte não entram na ajuda.
- Esta ajuda está incluída na aplicação e funciona offline.
