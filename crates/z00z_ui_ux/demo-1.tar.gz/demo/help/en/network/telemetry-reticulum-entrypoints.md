---
id: telemetry.reticulum.entrypoints
title: Reticulum entry points
summary: Reticulum entry points presents read-only carrier evidence from the registered local Reticulum bridge.
scope: context
---
## Use this view {#current-view}
- Review reticulum entry points evidence supplied by the registered local bridge; this view cannot change Reticulum.
- Unavailable means that no fresh local snapshot exists; addresses, destinations, routes, and payloads remain hidden.

## Local and safe behavior
- Wallet secrets and private transport data never enter Help.
- This Help is packaged with the application and works offline.
