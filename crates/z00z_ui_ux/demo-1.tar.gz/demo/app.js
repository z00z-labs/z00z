"use strict";

const main = document.querySelector("#main-content");
const pageTitle = document.querySelector("#page-title");
const pageContext = document.querySelector("#page-context");
const copyWalletAddress = document.querySelector("#copy-wallet-address");
const topbarAddressGroup = document.querySelector(".topbar-address-group");
const walletNav = document.querySelector("#wallet-nav");
const networkNav = document.querySelector("#network-nav");
const walletTabs = document.querySelector("#wallet-tabs");
const walletIdentity = document.querySelector("#wallet-identity");
const walletStatusbar = document.querySelector("#wallet-statusbar");
const lockWalletLabel = document.querySelector("#lock-wallet-label");
const mobileMenuButton = document.querySelector("#mobile-menu-button");
const mobileMenuBackdrop = document.querySelector("#mobile-menu-backdrop");
const mobilePopupMenu = document.querySelector("#mobile-popup-menu");
let mobilePopupType = "";
let mobilePopupTrigger = null;
const mobileMenuExpandedGroups = new Set();

const dialog = document.querySelector("#flow-dialog");
const dialogContent = document.querySelector("#dialog-content");
const appShell = document.querySelector("#app-shell");
const lockScreen = document.querySelector("#lock-screen");
const i18n = window.Z00ZI18n;
if (!i18n) throw new Error("Z00Z i18n must load before the wallet demo.");
const help = window.Z00ZHelp;
if (!help) throw new Error("Z00Z Help must load before the wallet demo.");
const demoRuntime = window.Z00ZDemo;
if (!demoRuntime?.PORT_CONTRACT || !demoRuntime.WALLET_CHAIN_OPTIONS || !demoRuntime.ASSET_CATALOG || !demoRuntime.createInitialState || !demoRuntime.createMockWalletGateway) {
  throw new Error("Z00Z production-port modules must load before the wallet demo.");
}
const uiLanguages = i18n.languages();
const paletteOptions = demoRuntime.PALETTE_OPTIONS;
const codeThemeOptions = demoRuntime.CODE_THEME_OPTIONS;
const walletChainOptions = demoRuntime.WALLET_CHAIN_OPTIONS;
const state = demoRuntime.createInitialState({
  search: window.location.search
});
const walletGateway = demoRuntime.createMockWalletGateway(state);
const passwordManagerIgnoreAttributeMap = Object.freeze({
  "data-form-type": "other",
  "data-1p-ignore": "true",
  "data-lpignore": "true",
  "data-bwignore": "true",
  "data-protonpass-ignore": "true"
});
const passwordManagerIgnoreAttributes = Object.entries(passwordManagerIgnoreAttributeMap)
  .map(([name, value]) => `${name}="${value}"`)
  .join(" ");

function secureEntryAttributes(section = "wallet") {
  return `type="text" class="secure-entry" data-secure-entry data-port-control="secure-entry" inputmode="text" autocomplete="section-z00z-${section} one-time-code" autocapitalize="none" autocorrect="off" spellcheck="false" ${passwordManagerIgnoreAttributes}`;
}

function suppressPasswordManagerUI(root = document) {
  const forms = root.querySelectorAll("form");
  const fields = root.querySelectorAll("input, textarea, select");
  const applyIgnoreAttributes = (element) => {
    Object.entries(passwordManagerIgnoreAttributeMap).forEach(([name, value]) => element.setAttribute(name, value));
  };

  forms.forEach((form) => {
    form.setAttribute("autocomplete", "off");
    applyIgnoreAttributes(form);
  });
  fields.forEach((field) => {
    applyIgnoreAttributes(field);
    if (field.matches('input[type="password"], input[data-secure-entry]')) {
      field.type = "text";
      field.classList.add("secure-entry");
      field.setAttribute("data-secure-entry", "");
      field.setAttribute("data-port-control", "secure-entry");
      field.setAttribute("inputmode", "text");
      if (!/one-time-code$/.test(field.autocomplete)) {
        field.setAttribute("autocomplete", "section-z00z-private one-time-code");
      }
      field.setAttribute("autocapitalize", "none");
      field.setAttribute("autocorrect", "off");
      field.setAttribute("spellcheck", "false");
    } else if (!field.hasAttribute("autocomplete")) {
      field.setAttribute("autocomplete", "off");
    }
  });
}

const headings = {
  home: ["app.home", "app.homeContext"],
  wallet: ["Wallet", "Assets, vouchers, and permissions stay distinct"],
  "wallet-send": ["assets.send", "Assets, vouchers, and permissions stay distinct"],
  "wallet-receive": ["assets.receive", "Assets, vouchers, and permissions stay distinct"],
  activity: ["History", "Asset, voucher, permission, policy, and security events"],
  swap: ["Swap", "Move value between assets in this wallet"],
  exchange: ["Exchange", "Compare external exchange routes for this wallet"],
  staking: ["Staking", "Put selected wallet value to work with clear terms"],
  "wallet-backup": ["Backup", "Protect the selected wallet with a verified local backup"],
  "wallet-settings": ["Wallet settings", "Configure this wallet without changing other local profiles"],
  settings: ["app.settings", "app.settingsContext"],
  telemetry: ["Telemetry", "Read-only local route and publication evidence"]
};

const telemetryTopbar = {
  onionnet: ["OnionNet", "network.routeTelemetry"],
  reticulum: ["Reticulum", "network.carrierTelemetry"],
  aggregators: ["Aggregators", "network.publicationTelemetry"]
};

const networkEntries = [
  { key: "reticulum", label: "Reticulum", initials: "R", helperKey: "network.carrierTelemetry" },
  { key: "onionnet", label: "OnionNet", initials: "O", helperKey: "network.routeTelemetry" },
  { key: "aggregators", label: "Aggregators", initials: "A", helperKey: "network.publicationTelemetry" }
];

function t(key, values) {
  return i18n.translate(state.language, key, values);
}

function walletChain(chainId) {
  return walletChainOptions.find(({ id }) => id === chainId) || walletChainOptions[0];
}

function walletChainOptionsMarkup(selectedChainId = "mainnet") {
  return walletChainOptions.map(({ id, label }) => `<option value="${escapeHtml(id)}"${id === selectedChainId ? " selected" : ""}>${escapeHtml(label)}</option>`).join("");
}

function walletChainBadgeMarkup(chainId) {
  const chain = walletChain(chainId);
  return `<span class="environment-tag is-${chain.tone}" title="${escapeHtml(t("common.readOnly"))}">${escapeHtml(chain.label)}</span>`;
}

function languageOptionsMarkup() {
  return uiLanguages.map(({ id, nativeName }) => `<option value="${id}"${state.language === id ? " selected" : ""}>${nativeName}</option>`).join("");
}

function regionalLocaleOptionsMarkup() {
  return uiLanguages.map(({ locale, nativeName }) => `<option value="${locale}"${state.regionalLocale === locale ? " selected" : ""}>${nativeName} · ${locale}</option>`).join("");
}

function applyDocumentTranslations() {
  document.documentElement.lang = state.language;
  document.documentElement.dir = uiLanguages.find((language) => language.id === state.language)?.direction ?? "ltr";
  document.title = t("app.documentTitle");
  document.querySelectorAll("[data-i18n]").forEach((element) => {
    element.textContent = t(element.dataset.i18n);
  });
}

function formatLocalizedNumber(value, options) {
  return i18n.formatNumber(value, state.language, state.regionalLocale, options);
}

function formatLocalizedDateTime(value, options) {
  return i18n.formatDateTime(value, state.language, state.regionalLocale, state.timeZone, options);
}

function formatLocalizedBitrate(bitsPerSecond) {
  return i18n.formatBitrate(bitsPerSecond, state.language, state.regionalLocale);
}

function walletScanLabel(scan) {
  return t(scan === "Scanning" ? "walletShell.scanning" : "walletShell.current");
}

function activeWallet() {
  return demoRuntime.activeWallet(state);
}

function activeWalletPreferences() {
  return demoRuntime.ensureWalletPreferences(state, activeWallet());
}

function yamlScalar(value) {
  return String(value).replaceAll('"', '\\"');
}

function effectiveDemoConfigYaml() {
  const wallet = activeWallet();
  const walletPreferences = activeWalletPreferences();
  return [
    "schema_version: 1",
    "",
    "app:",
    "  general:",
    `    language: \"${yamlScalar(state.language)}\"`,
    `    regional_locale: \"${yamlScalar(state.regionalLocale)}\"`,
    `    time_zone: \"${yamlScalar(state.timeZone)}\"`,
    `    network_units: ${state.networkUnits}`,
    `    notifications: ${state.notifications}`,
    "  appearance:",
    `    theme: ${state.theme}`,
    `    palette: ${state.palette}`,
    `    text_scale: ${state.textScale}`,
    `    reduced_motion: ${state.reducedMotion}`,
    `    code_theme: ${state.codeTheme}`,
    "",
    "wallet:",
    `  id: \"${yamlScalar(wallet.id)}\"`,
    `  chain: \"${yamlScalar(wallet.chainId)}\"`,
    "  display:",
    `    name: \"${yamlScalar(wallet.name)}\"`,
    `    currency: ${walletPreferences.currency}`,
    "  transactions:",
    `    default_fee: \"${yamlScalar(walletPreferences.defaultFee)}\"`,
    "  security:",
    `    lock_after_minutes: ${walletPreferences.lockAfterMinutes}`,
    "  backup:",
    `    auto_backup: ${walletPreferences.autoBackup}`,
    `    interval_hours: ${walletPreferences.backupIntervalHours}`,
    "    encrypt: true",
    "  policy_rules:",
    `    max_transaction: \"${yamlScalar(walletPreferences.policyRules.maxTransaction)}\"`,
    `    max_daily: \"${yamlScalar(walletPreferences.policyRules.maxDaily)}\"`,
    `    require_confirmation: ${walletPreferences.policyRules.requireConfirmation}`,
    `    allowed_assets: ${walletPreferences.policyRules.allowedAssets}`,
    `    allowed_recipients: \"${yamlScalar(walletPreferences.policyRules.allowedRecipients || "any")}\"`,
    `    time_restrictions: ${walletPreferences.policyRules.timeWindow}`,
    "  compliance_profile:",
    `    preview: \"${yamlScalar(walletPreferences.policyProfile)}\"`,
    "  privacy:",
    `    hide_sensitive_amounts: ${state.balanceHidden}`,
    "  advanced:",
    `    expert_details: ${state.expertDetails}`,
    "",
    "# Secrets, local paths, session tokens, and receiver material are excluded."
  ].join("\n");
}

function syncConfigDraftFromState() {
  state.configDraft = effectiveDemoConfigYaml();
  state.configStatus = "Local draft is in sync with the visible controls.";
}

function applyAppearancePreferences() {
  const root = document.documentElement;
  root.dataset.theme = state.theme;
  root.dataset.palette = state.palette;
  root.dataset.codeTheme = state.codeTheme;
  root.dataset.textScale = state.textScale;
  root.dataset.reducedMotion = String(state.reducedMotion);
  applyDocumentTranslations();
  const themeColor = getComputedStyle(root).getPropertyValue("--bg-canvas").trim();
  if (themeColor) document.querySelector('meta[name="theme-color"]').content = themeColor;
}

function readYamlScalar(source, key) {
  const match = source.match(new RegExp(`^\\s*${key}:\\s*(?:\\"([^\\"]*)\\"|([^#\\n]+))`, "m"));
  return match ? (match[1] ?? match[2]).trim() : null;
}

function validateAndApplyDemoConfig(source, apply = false) {
  const forbidden = /(^|\n)\s*(password|seed|private_key|session_token|receiver_secret|path):/i;
  if (!/^schema_version:\s*1\s*$/m.test(source)) return { valid: false, message: "Use schema_version: 1." };
  if (!/^app:\s*$/m.test(source) || !/^wallet:\s*$/m.test(source)) return { valid: false, message: "App and wallet sections are required." };
  if (forbidden.test(source)) return { valid: false, message: "Secrets and local paths are not allowed in this configuration." };

  const theme = readYamlScalar(source, "theme");
  const palette = readYamlScalar(source, "palette");
  const language = readYamlScalar(source, "language");
  const regionalLocale = readYamlScalar(source, "regional_locale");
  const timeZone = readYamlScalar(source, "time_zone");
  const networkUnits = readYamlScalar(source, "network_units");
  const textScale = readYamlScalar(source, "text_scale");
  const notifications = readYamlScalar(source, "notifications");
  const reducedMotion = readYamlScalar(source, "reduced_motion");
  const codeTheme = readYamlScalar(source, "code_theme");
  const chainId = readYamlScalar(source, "chain");
  const appLockAfter = readYamlScalar(source, "lock_after_minutes");
  const defaultFee = readYamlScalar(source, "default_fee");
  const hideSensitive = readYamlScalar(source, "hide_sensitive_amounts");
  const expertDetails = readYamlScalar(source, "expert_details");

  if (theme && !["dark", "light"].includes(theme)) return { valid: false, message: "Theme must be dark or light." };
  if (palette && !paletteOptions.some((entry) => entry.id === palette)) return { valid: false, message: "Palette must use one of the listed preset IDs." };
  if (language && !uiLanguages.some((entry) => entry.id === language)) return { valid: false, message: "language must be a supported UI language code." };
  if (regionalLocale && !uiLanguages.some((entry) => entry.locale === regionalLocale)) return { valid: false, message: "regional_locale must use a supported locale." };
  if (timeZone && !["UTC", "Asia/Jerusalem", "Europe/Berlin", "America/New_York", "Asia/Tokyo", "Asia/Shanghai"].includes(timeZone)) return { valid: false, message: "time_zone must use a supported IANA identifier." };
  if (networkUnits && networkUnits !== "decimal-bps") return { valid: false, message: "network_units must be decimal-bps." };
  if (textScale && !["100", "110", "125"].includes(textScale)) return { valid: false, message: "text_scale must be 100, 110, or 125." };
  if (notifications && !["true", "false"].includes(notifications)) return { valid: false, message: "notifications must be true or false." };
  if (reducedMotion && !["true", "false"].includes(reducedMotion)) return { valid: false, message: "reduced_motion must be true or false." };
  if (codeTheme && !codeThemeOptions.some((entry) => entry.id === codeTheme)) return { valid: false, message: "code_theme must use one of the listed preset IDs." };
  if (chainId !== activeWallet().chainId) return { valid: false, message: `chain is read-only and must remain ${activeWallet().chainId}.` };
  if (defaultFee && !/^\d+(?:\.\d+)?$/.test(defaultFee)) return { valid: false, message: "default_fee must be a non-negative decimal." };
  if (hideSensitive && !["true", "false"].includes(hideSensitive)) return { valid: false, message: "hide_sensitive_amounts must be true or false." };
  if (expertDetails && !["true", "false"].includes(expertDetails)) return { valid: false, message: "expert_details must be true or false." };
  if (appLockAfter && !["5", "15", "30", "never"].includes(appLockAfter.toLowerCase())) return { valid: false, message: "lock_after_minutes must be 5, 15, 30, or never." };

  if (apply) {
    if (theme) state.theme = theme;
    if (palette) state.palette = palette;
    if (language) state.language = language;
    if (regionalLocale) state.regionalLocale = regionalLocale;
    if (timeZone) state.timeZone = timeZone;
    if (networkUnits) state.networkUnits = networkUnits;
    if (textScale) state.textScale = textScale;
    if (notifications) state.notifications = notifications === "true";
    if (reducedMotion) state.reducedMotion = reducedMotion === "true";
    if (codeTheme) state.codeTheme = codeTheme;
    if (appLockAfter) state.autoLockMinutes = appLockAfter.toLowerCase();
    if (defaultFee) activeWalletPreferences().defaultFee = defaultFee;
    if (hideSensitive) state.balanceHidden = hideSensitive === "true";
    if (expertDetails) state.expertDetails = expertDetails === "true";
    applyAppearancePreferences();
  }

  return { valid: true, message: apply ? "Local concept draft applied. Runtime YAML write/watch is still unavailable." : "YAML draft is valid for this concept schema." };
}

function paletteCard(palette) {
  const isActive = state.palette === palette.id;
  return `<button class="palette-card${isActive ? " is-active" : ""}" type="button" data-palette="${palette.id}" aria-pressed="${isActive}">
    <span class="palette-swatches" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span>
    <span><strong>${palette.label}</strong></span>
  </button>`;
}

function codeThemeCard(theme) {
  const isActive = state.codeTheme === theme.id;
  return `<button class="code-theme-card${isActive ? " is-active" : ""}" type="button" data-code-theme="${theme.id}" aria-pressed="${isActive}">
    <span class="code-theme-card-heading"><strong>${theme.label}</strong>${isActive ? "<em>Active</em>" : ""}</span>
    <span class="code-theme-preview" aria-hidden="true">
      <span class="code-theme-preview-dots"><i></i><i></i><i></i><i></i></span>
      <span><b>// z00z preview</b></span>
      <span><strong>theme</strong><span> = </span><em>"demo"</em></span>
      <span><strong>epoch</strong><span> = </span><u>42</u></span>
    </span>
  </button>`;
}

function yamlCommentIndex(value) {
  let isQuoted = false;
  let isEscaped = false;
  for (let index = 0; index < value.length; index += 1) {
    const char = value[index];
    if (char === '"' && !isEscaped) isQuoted = !isQuoted;
    if (char === "#" && !isQuoted && (index === 0 || /\s/.test(value[index - 1]))) return index;
    isEscaped = char === "\\" && !isEscaped;
    if (char !== "\\") isEscaped = false;
  }
  return -1;
}

function yamlHighlightValue(value) {
  const commentIndex = yamlCommentIndex(value);
  const scalar = commentIndex === -1 ? value : value.slice(0, commentIndex);
  const comment = commentIndex === -1 ? "" : value.slice(commentIndex);
  const trailing = scalar.match(/\s*$/)?.[0] || "";
  const core = scalar.slice(0, scalar.length - trailing.length);
  let rendered = escapeHtml(core);
  if (/^"(?:[^"\\]|\\.)*"$/.test(core)) rendered = `<span class="yaml-token-string">${escapeHtml(core)}</span>`;
  else if (/^(?:true|false|null|~)$/i.test(core)) rendered = `<span class="yaml-token-number">${escapeHtml(core)}</span>`;
  else if (/^-?\d+(?:\.\d+)?$/.test(core)) rendered = `<span class="yaml-token-number">${escapeHtml(core)}</span>`;
  return `${rendered}${escapeHtml(trailing)}${comment ? `<span class="yaml-token-comment">${escapeHtml(comment)}</span>` : ""}`;
}

function yamlSyntaxHighlight(source) {
  return source.split("\n").map((line) => {
    const match = line.match(/^(\s*)([A-Za-z][A-Za-z0-9_-]*)(:)(\s*)(.*)$/);
    if (!match) return line.trimStart().startsWith("#") ? `<span class="yaml-token-comment">${escapeHtml(line)}</span>` : escapeHtml(line);
    return `${escapeHtml(match[1])}<span class="yaml-token-key">${escapeHtml(match[2])}</span><span class="yaml-token-punctuation">${match[3]}</span>${escapeHtml(match[4])}${yamlHighlightValue(match[5])}`;
  }).join("\n");
}

function yamlEditorMarkup(id, source, label, describedBy = "") {
  return `<label class="yaml-field"><span class="visually-hidden">${label}</span><span class="yaml-editor-shell"><pre class="yaml-highlight" aria-hidden="true">${yamlSyntaxHighlight(source)}</pre><textarea id="${id}" class="yaml-editor" spellcheck="false"${describedBy ? ` aria-describedby="${describedBy}"` : ""}>${escapeHtml(source)}</textarea></span></label>`;
}

function syncYamlHighlight(textarea) {
  const highlight = textarea.closest(".yaml-editor-shell")?.querySelector(".yaml-highlight");
  if (!highlight) return;
  highlight.innerHTML = yamlSyntaxHighlight(textarea.value);
  highlight.scrollTop = textarea.scrollTop;
  highlight.scrollLeft = textarea.scrollLeft;
}

function advancedConfigContent() {
  const hasYamlView = state.configView === "yaml";
  const hasFormView = state.configView === "form";
  const hasDiffView = state.configView === "diff";
  const walletPreferences = activeWalletPreferences();
  const source = state.configDraft || effectiveDemoConfigYaml();
  const formContent = `
    <div class="config-form-grid">
      <label><span>${t("app.language")}</span><select data-config-control="language">${languageOptionsMarkup()}</select></label>
      <label><span>${t("app.regionalFormat")}</span><select data-config-control="regional-locale">${regionalLocaleOptionsMarkup()}</select></label>
      <label><span>${t("app.timeZone")}</span><select data-config-control="time-zone"><option value="UTC"${state.timeZone === "UTC" ? " selected" : ""}>UTC</option><option value="Asia/Jerusalem"${state.timeZone === "Asia/Jerusalem" ? " selected" : ""}>Asia/Jerusalem</option><option value="Europe/Berlin"${state.timeZone === "Europe/Berlin" ? " selected" : ""}>Europe/Berlin</option><option value="America/New_York"${state.timeZone === "America/New_York" ? " selected" : ""}>America/New_York</option><option value="Asia/Tokyo"${state.timeZone === "Asia/Tokyo" ? " selected" : ""}>Asia/Tokyo</option><option value="Asia/Shanghai"${state.timeZone === "Asia/Shanghai" ? " selected" : ""}>Asia/Shanghai</option></select></label>
      <label><span>Palette</span><select data-config-control="palette">${paletteOptions.map((palette) => `<option value="${palette.id}"${state.palette === palette.id ? " selected" : ""}>${palette.label}</option>`).join("")}</select></label>
      <label><span>Text scale</span><select data-config-control="text-scale"><option value="100"${state.textScale === "100" ? " selected" : ""}>100%</option><option value="110"${state.textScale === "110" ? " selected" : ""}>110%</option><option value="125"${state.textScale === "125" ? " selected" : ""}>125%</option></select></label>
      <label><span>Code highlighting</span><select data-config-control="code-theme">${codeThemeOptions.map((theme) => `<option value="${theme.id}"${state.codeTheme === theme.id ? " selected" : ""}>${theme.label}</option>`).join("")}</select></label>
      <label><span>Default fee</span><input data-config-control="default-fee" inputmode="decimal" value="${escapeHtml(walletPreferences.defaultFee)}" aria-label="Default fee"></label>
    </div>`;
  const diffContent = `
    <div class="config-diff" aria-label="Visible controls and YAML mapping">
      <div><span>UI</span><strong>Appearance and wallet controls</strong></div><div>${icon("chevron")}</div><div><span>YAML</span><strong class="mono">app.* / wallet.*</strong></div>
      <p>Changes remain inside this browser concept. A future runtime integration must provide revisioned read, validate, write, and watch capabilities before local files can change.</p>
    </div>`;
  return `
    <div class="settings-heading"><div><p class="eyebrow">Advanced configuration</p><h2>YAML & diagnostics</h2><p>Visible controls and the local concept YAML describe the same safe settings. Secrets and local paths are excluded.</p></div><span class="config-source">Concept-local</span></div>
    <div class="choice-strip config-view-choices" role="tablist" aria-label="Configuration view">
      ${["yaml", "form", "diff"].map((view) => `<button class="choice-chip${state.configView === view ? " is-active" : ""}" type="button" role="tab" aria-selected="${state.configView === view}" data-config-view="${view}">${view === "yaml" ? "YAML" : view === "form" ? "Form" : "Mapping"}</button>`).join("")}
    </div>
    <div class="yaml-toolbar"><span><strong class="mono">wallet_config.yaml</strong><small>${escapeHtml(state.configStatus)}</small></span><div><button class="button" type="button" data-demo-action="config-validate">Validate</button><button class="button button-primary" type="button" data-demo-action="config-apply">Apply locally</button></div></div>
    <div role="tabpanel" class="config-panel">
      ${hasYamlView ? yamlEditorMarkup("config-yaml", source, "Concept configuration YAML", "config-capability-note") : ""}
      ${hasFormView ? formContent : ""}
      ${hasDiffView ? diffContent : ""}
    </div>
    <div class="config-foot"><span>${icon("shield")} No secrets or local paths</span><span>${icon("activity")} Local concept only</span><span>${icon("backup")} Runtime sync unavailable</span></div>
    <div class="capability-note" id="config-capability-note">${icon("alert")} <span><strong>Runtime integration boundary</strong><small>Apply locally updates this demo only. The runtime currently has no configuration write, watch, or revision RPC, so it cannot update a real wallet configuration.</small></span></div>
    <div class="setting-group"><div class="setting-line"><span class="setting-line-copy"><strong>Expert details</strong><small>Show identifiers, receipts, and lifecycle events</small></span><button class="toggle" type="button" aria-pressed="${state.expertDetails}" aria-label="Show expert details" data-demo-action="expert"></button></div><div class="setting-line"><span class="setting-line-copy"><strong>Sanitized diagnostics</strong><small>RPC, configuration, route, and synchronization events</small></span><button class="button" type="button" data-demo-action="diagnostics">Open</button></div></div>`;
}

function isWalletView() {
  return ["wallet", "wallet-send", "wallet-receive", "activity", "swap", "exchange", "staking", "wallet-backup", "wallet-settings"].includes(state.view);
}

function hasSelectedWalletContext() {
  return Boolean(state.selectedWalletId) && !["settings", "telemetry"].includes(state.view);
}

function addWalletProfile(name, chainId = "mainnet", scan = "Scanning") {
  const result = walletGateway.createProfile({ name, chainId, scan });
  if (!result.ok) throw new Error(result.error.message);
  return result.data.wallet;
}

function sidebarActiveTarget() {
  if (state.view === "telemetry") return { group: "network", id: state.telemetrySource };

  if (state.view === "settings") {
    if (["reticulum", "onionnet"].includes(state.settingsSection)) {
      return { group: "network", id: state.settingsSection };
    }
    return { group: "settings", id: "settings" };
  }

  return state.selectedWalletId
    ? { group: "wallet", id: state.selectedWalletId }
    : { group: null, id: null };
}

function renderWalletShell() {
  const wallet = activeWallet();
  const summary = wallet.summary;
  const sidebarTarget = sidebarActiveTarget();
  walletNav.innerHTML = `${state.wallets.map((entry) => `
    <button class="wallet-nav-item${sidebarTarget.group === "wallet" && entry.id === sidebarTarget.id ? " is-active" : ""}" type="button" ${sidebarTarget.group === "wallet" && entry.id === sidebarTarget.id ? 'aria-current="page"' : ""} data-wallet-id="${escapeHtml(entry.id)}">
      <span class="wallet-avatar" aria-hidden="true">${escapeHtml(entry.initials)}</span>
      <span class="wallet-nav-copy"><strong>${escapeHtml(entry.name)}</strong><small>${t("walletShell.balanceAvailable", { value: `<span class="mono">${sensitive(`${entry.summary.available} Z00Z`)}</span>` })}</small></span>
      <span class="wallet-nav-state${entry.summary.scan === "Scanning" ? " is-scanning" : ""}" aria-label="${escapeHtml(walletScanLabel(entry.summary.scan))}"></span>
    </button>`).join("")}
    <div class="wallet-nav-actions" id="wallet-nav-actions">
      <button class="nav-item nav-item-primary" type="button" data-demo-action="add-wallet">${icon("plus")}<span>${t("app.addWallet")}</span></button>
      <button class="nav-item nav-item-danger" type="button" data-demo-action="remove-wallet"${state.wallets.length === 0 ? " disabled" : ""}>${icon("remove")}<span>${t("app.removeWallet")}</span></button>
    </div>`;
  networkNav.innerHTML = networkEntries.map((entry) => {
    const isActive = sidebarTarget.group === "network" && sidebarTarget.id === entry.key;
    return `<button class="network-nav-item${isActive ? " is-active" : ""}" type="button" ${isActive ? 'aria-current="page"' : ""} data-network-section="${entry.key}" title="${t(entry.helperKey)}">
      <span class="network-avatar" aria-hidden="true">${entry.initials}</span>
      <span class="network-nav-copy"><strong>${entry.label}</strong></span>
      <span class="network-nav-state" aria-hidden="true"></span>
    </button>`;
  }).join("");
  const walletName = wallet.name;
  walletIdentity.innerHTML = `<span class="wallet-avatar" aria-hidden="true">${escapeHtml(wallet.initials)}</span><span><strong>${escapeHtml(walletName)}</strong><small class="mono">${escapeHtml(wallet.address)}</small></span>`;
  walletIdentity.setAttribute("aria-label", t("walletShell.identityAria", { wallet: walletName }));
  lockWalletLabel.innerHTML = `${escapeHtml(t("walletShell.lockLabel", { wallet: walletName }))} <span aria-hidden="true">·</span> <span class="mono">${escapeHtml(wallet.address)}</span>`;
  copyWalletAddress.setAttribute("aria-label", t("walletShell.copyAddress", { wallet: walletName }));
  copyWalletAddress.setAttribute("title", wallet.fullAddress);
  const globalHelpButton = document.querySelector(".help-button");
  globalHelpButton?.setAttribute("aria-label", t("help.openGlobal"));
  globalHelpButton?.setAttribute("title", t("help.title"));
  const telemetryTabSource = state.view === "telemetry" ? {
    reticulum: { label: "Reticulum", tabs: reticulumTelemetryTabs, selectedTab: state.reticulumTelemetryTab, actionName: "reticulum-telemetry-tab" },
    onionnet: { label: "OnionNet", tabs: onionnetTelemetryTabs, selectedTab: state.onionnetTelemetryTab, actionName: "onionnet-telemetry-tab" },
    aggregators: { label: "Aggregators", tabs: aggregatorsTelemetryTabs, selectedTab: state.aggregatorsTelemetryTab, actionName: "aggregators-telemetry-tab" }
  }[state.telemetrySource] : null;
  const settingsTabs = [
    { id: "general", labelKey: "settings.general", iconName: "settings" },
    { id: "reticulum", label: "Reticulum", iconName: "network" },
    { id: "onionnet", label: "OnionNet", iconName: "shield" },
    { id: "appearance", labelKey: "settings.appearance", iconName: "sun" }
  ];
  walletTabs.classList.toggle("is-settings-tabs", state.view === "settings");
  if (telemetryTabSource) {
    const { label, tabs, selectedTab, actionName } = telemetryTabSource;
    walletTabs.setAttribute("aria-label", `${label} telemetry parameters`);
    walletTabs.setAttribute("role", "tablist");
    walletTabs.innerHTML = tabs.map((tab) => `<button id="${state.telemetrySource}-tab-${tab.id}" class="wallet-tab${selectedTab === tab.id ? " is-active" : ""}" type="button" role="tab" aria-selected="${selectedTab === tab.id}" aria-controls="${state.telemetrySource}-panel-${tab.id}"${selectedTab === tab.id ? ' aria-current="page"' : ""} data-${actionName}="${tab.id}">${icon(tab.iconName)}<span>${t(tab.labelKey)}</span></button>`).join("");
  } else if (state.view === "settings") {
    walletTabs.setAttribute("aria-label", t("settings.sections"));
    walletTabs.setAttribute("role", "tablist");
    walletTabs.innerHTML = settingsTabs.map((tab) => {
      const isActive = state.settingsSection === tab.id;
      const label = tab.labelKey ? t(tab.labelKey) : tab.label;
      return `<button id="settings-tab-${tab.id}" class="wallet-tab${isActive ? " is-active" : ""}" type="button" role="tab" aria-selected="${isActive}"${isActive ? ' aria-current="page"' : ""} data-settings-section="${tab.id}">${icon(tab.iconName)}<span>${label}</span></button>`;
    }).join("");
  } else {
    walletTabs.setAttribute("aria-label", "Selected wallet");
    walletTabs.removeAttribute("role");
    walletTabs.innerHTML = [
      { view: "wallet", labelKey: "nav.assets", iconName: "wallet", mobilePopup: "assets" },
      { view: "wallet-send", labelKey: "assets.send", iconName: "send" },
      { view: "wallet-receive", labelKey: "assets.receive", iconName: "receive" },
      { view: "swap", labelKey: "nav.swap", iconName: "swap", title: "Compatibility preview — no canonical execution route" },
      { view: "exchange", labelKey: "nav.exchange", iconName: "exchange", title: "Spot venue or cross-chain intent preview", mobilePopup: "exchange" },
      { view: "staking", labelKey: "nav.staking", iconName: "staking", title: "Compatibility preview — validator and lock terms required" },
      { view: "wallet-backup", labelKey: "nav.backup", iconName: "backup" },
      { view: "activity", labelKey: "nav.history", iconName: "activity" },
      { view: "wallet-settings", labelKey: "nav.settings", iconName: "settings", mobilePopup: "wallet-settings" }
    ].map(({ view, labelKey, iconName, title = "", disabled = false, mobilePopup = "" }) => `<button class="wallet-tab${state.view === view ? " is-active" : ""}${disabled ? " is-unavailable" : ""}" type="button" ${state.view === view ? 'aria-current="page"' : ""}${disabled ? " disabled" : ""}${title ? ` title="${escapeHtml(title)}"` : ""}${mobilePopup ? ` data-mobile-popup="${mobilePopup}" aria-haspopup="menu"` : ""} data-view="${view}">${icon(iconName)}<span>${t(labelKey)}</span>${mobilePopup ? icon("chevron", "mobile-tab-disclosure") : ""}${disabled ? '<span class="sr-only">Unavailable</span>' : ""}</button>`).join("");
  }
  walletStatusbar.innerHTML = `
    <span><small>${t("walletShell.available")}</small><strong>${sensitive(`${summary.available} Z00Z`)}</strong></span>
    <span><small>${t("walletShell.locked")}</small><strong>${sensitive(`${summary.locked} Z00Z`)}</strong></span>
    <span><small>${t("walletShell.pendingIn")}</small><strong>${sensitive(`${summary.pendingIn} Z00Z`)}</strong></span>
    <span><small>${t("walletShell.pendingOut")}</small><strong>${sensitive(`${summary.pendingOut} Z00Z`)}</strong></span>
    <span class="statusbar-telemetry"><small>${t("walletShell.routeTelemetry")}</small><strong><span class="statusbar-state-dot" aria-hidden="true"></span>${t("common.unavailable")}</strong></span>`;
  walletTabs.hidden = !isWalletView() && !telemetryTabSource && state.view !== "settings";
  walletStatusbar.hidden = !hasSelectedWalletContext();
}

function icon(name, className = "") {
  return `<svg class="icon ${className}" aria-hidden="true"><use href="#i-${name}"/></svg>`;
}

function objectIconDefinition(definition, className = "") {
  if (!definition) return "";
  const classes = `icon object-family-glyph is-${definition.mode}${className ? ` ${className}` : ""}`;
  if (definition.mode === "mask") {
    const resolvedSource = new URL(definition.iconSrc, document.baseURI).href;
    return `<span class="${classes}" style="--object-family-source:url(${escapeHtml(resolvedSource)})" aria-hidden="true"></span>`;
  }
  return `<img class="${classes}" src="${escapeHtml(definition.iconSrc)}" alt="" decoding="async" draggable="false">`;
}

function objectFamilyIcon(family, className = "") {
  return objectIconDefinition(demoRuntime.OBJECT_FAMILY_ICON_LUT[family], className);
}

function objectTypeIcon(family, type, className = "") {
  const definition = demoRuntime.OBJECT_TYPE_ICON_LUT[family]?.[type] || demoRuntime.OBJECT_FAMILY_ICON_LUT[family];
  if (!definition) return "";
  const glyph = definition.iconSrc ? objectIconDefinition(definition) : icon(definition.iconName);
  return `<span class="object-type-icon ${definition.className}${className ? ` ${className}` : ""}" aria-hidden="true">${glyph}</span>`;
}

function assetIcon(asset, className = "") {
  if (!asset.iconSrc) return objectTypeIcon("asset", asset.type, className);
  return `<span class="object-type-icon is-${escapeHtml(asset.type)} has-brand-icon${className ? ` ${className}` : ""}" aria-hidden="true"><img src="${escapeHtml(asset.iconSrc)}" alt="" decoding="async" draggable="false"></span>`;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function sensitive(value) {
  return `<span class="sensitive${state.balanceHidden ? " is-hidden" : ""}"${state.balanceHidden ? ' aria-label="Amount hidden"' : ""}>${state.balanceHidden ? "Hidden" : escapeHtml(value)}</span>`;
}

function walletAssetEntries() {
  const wallet = activeWallet();
  const assetKeys = new Set(wallet.assetKeys || ["z00z"]);
  const kindKeys = { coin: "assets.kindCoin", token: "assets.kindToken", nft: "assets.kindCollectible" };
  const kinds = { coin: "Coin", token: "Token", nft: "NFT" };
  return demoRuntime.ASSET_CATALOG
    .filter((asset) => assetKeys.has(asset.key))
    .map((asset) => {
      const balance = asset.key === "z00z" ? wallet.summary.available : asset.demoBalance || "0.00";
      return {
        ...asset,
        kind: kinds[asset.type],
        kindKey: kindKeys[asset.type],
        balance,
        balanceLabel: `${balance} ${asset.unit}`,
        value: "0.00",
        priceKey: "common.unavailable",
        priceNoteKey: "assets.noMarketFeed",
        owner: asset.owner || wallet.fullAddress || wallet.address,
        currentSupply: asset.currentSupply || "Unavailable",
        maxSupply: asset.maxSupply || "Unavailable"
      };
    });
}

function supportedAsset(assetKey = "z00z") {
  const assets = walletAssetEntries();
  return assets.find((asset) => asset.key === assetKey) || assets[0];
}

function walletObjectEntry(family, objectId) {
  const wallet = activeWallet();
  const entries = family === "voucher" ? wallet.vouchers : family === "permission" ? wallet.permissions : [];
  return (entries || []).find((entry) => entry.id === objectId) || null;
}

const sendFamilies = Object.freeze([
  Object.freeze({ id: "asset", labelKey: "assets.sectionAssets", iconName: "assets", createFlow: "" }),
  Object.freeze({ id: "voucher", labelKey: "assets.sectionVouchers", iconName: "voucher", createFlow: "create-voucher" }),
  Object.freeze({ id: "permission", labelKey: "assets.sectionPermissions", iconName: "permission", createFlow: "create-permission" })
]);

function sendOptionEntries(family = "") {
  const wallet = activeWallet();
  const assets = walletAssetEntries().map((asset) => ({
    key: asset.key,
    family: "asset",
    label: asset.label,
    kindLabel: t(asset.kindKey),
    meta: asset.balanceLabel,
    asset
  }));
  const vouchers = (wallet.vouchers || [])
    .filter((voucher) => voucher.transferable)
    .map((voucher) => ({
      key: `voucher:${voucher.id}`,
      family: "voucher",
      label: voucher.title,
      kindLabel: t("assets.sectionVouchers"),
      meta: voucher.value,
      entry: voucher
    }));
  const permissions = (wallet.permissions || [])
    .filter((permission) => permission.transferable)
    .map((permission) => ({
      key: `permission:${permission.id}`,
      family: "permission",
      label: permission.title,
      kindLabel: t("assets.sectionPermissions"),
      meta: permission.remaining,
      entry: permission
    }));
  const entries = [...assets, ...vouchers, ...permissions];
  return family ? entries.filter((entry) => entry.family === family) : entries;
}

function defaultSendDraft() {
  return {
    family: "asset",
    step: 0,
    recipient: "",
    recipientLabel: "",
    amount: "",
    memo: "",
    itemKey: "z00z",
    completed: null
  };
}

function activeSendDraft() {
  const wallet = activeWallet();
  state.sendDrafts ||= {};
  state.sendDrafts[wallet.id] ||= defaultSendDraft();
  const draft = state.sendDrafts[wallet.id];
  if (!sendFamilies.some(({ id }) => id === draft.family)) draft.family = "asset";
  const options = sendOptionEntries(draft.family);
  if (!options.some((entry) => entry.key === draft.itemKey)) {
    draft.itemKey = options[0]?.key || "";
  }
  return draft;
}

function resetActiveSendDraft() {
  state.sendDrafts[activeWallet().id] = defaultSendDraft();
  return state.sendDrafts[activeWallet().id];
}

function selectedSendOption(draft = activeSendDraft()) {
  const options = sendOptionEntries(draft.family);
  return options.find((entry) => entry.key === draft.itemKey) || options[0];
}

function sendOptionsMarkup(family, selectedKey) {
  return sendOptionEntries(family).map((entry) => `<option value="${escapeHtml(entry.key)}"${entry.key === selectedKey ? " selected" : ""}>${escapeHtml(entry.label)} · ${escapeHtml(entry.kindLabel)}</option>`).join("");
}

function assetOptions(selectedKey = "z00z") {
  return walletAssetEntries().map((asset) => `<option value="${escapeHtml(asset.key)}"${asset.key === selectedKey ? " selected" : ""}>${escapeHtml(asset.label)} · ${t(asset.kindKey)}</option>`).join("");
}

function quickAction(target, label, helper, iconName, behavior = "flow") {
  const targetAttribute = behavior === "view" ? `data-view="${target}"` : `data-open-flow="${target}"`;
  const iconMarkup = iconName === "permission" ? objectFamilyIcon("right") : icon(iconName);
  return `
    <button class="quick-action" type="button" ${targetAttribute}>
      <span class="quick-action-icon">${iconMarkup}</span>
      <span><strong>${label}</strong><small>${helper}</small></span>
    </button>`;
}

function homeView() {
  const wallet = activeWallet();
  const summary = wallet.summary;
  return `
    <div class="view-enter">
      <section class="dashboard-grid" aria-label="Wallet overview">
        <article class="card balance-card">
          <div class="balance-card-top">
            <span class="balance-label">${icon("shield")} Available privately</span>
            <span class="asset-chip">Z00Z</span>
          </div>
          <p class="balance-amount">${sensitive(summary.available)} <span class="mono">Z00Z</span></p>
          <p class="balance-pending"><strong>${sensitive(`+ ${summary.pendingIn}`)}</strong> receiving · <strong>${sensitive(`− ${summary.pendingOut}`)}</strong> sending</p>
        </article>

        <article class="card privacy-card">
          <div class="privacy-card-header">
            <span class="shield-mark">${icon("shield")}</span>
            <span class="status-badge is-ready">Target simulation</span>
          </div>
          <h2>Private route model</h2>
          <p>Target layering is shown without pretending current RPC telemetry exists.</p>
          <div class="privacy-lines">
            <div class="privacy-line"><span>Privacy overlay</span><strong>OnionNet · target</strong></div>
            <div class="privacy-line"><span>Primary carrier</span><strong>Reticulum · target</strong></div>
            <div class="privacy-line"><span>Wallet scan</span><strong>${escapeHtml(summary.scan)}</strong></div>
            <div class="privacy-line"><span>Live route telemetry</span><strong>Unavailable</strong></div>
          </div>
        </article>
      </section>

      <section class="quick-section" aria-labelledby="quick-title">
        <div class="section-heading">
          <div><h2 id="quick-title">What would you like to do?</h2><p>Private actions with safe defaults</p></div>
        </div>
        <div class="quick-pairs">
          <div class="quick-pair">
            ${quickAction("wallet-send", "Send", "Send any supported asset", "send", "view")}
            ${quickAction("wallet-receive", "Receive", "Show this wallet's receiver card", "receive", "view")}
          </div>
          <div class="quick-pair">
            ${quickAction("asset-claim", "Claim", "Claim an asset allocation", "claim")}
            ${quickAction("permission", "Give permission", "Delegate a bounded right", "permission")}
          </div>
        </div>
      </section>

      <section class="home-lower">
        <article class="card panel" aria-labelledby="attention-title">
          <div class="section-heading">
            <div><h2 id="attention-title">Needs your attention</h2><p>Two items</p></div>
            <button class="section-link" type="button" data-view="activity">Review history ${icon("chevron")}</button>
          </div>
          <div class="attention-list">
            <button class="attention-item" type="button" data-open-flow="voucher-review">
              <span class="list-icon is-voucher">${objectFamilyIcon("voucher")}</span>
              <span class="list-copy"><strong>Travel refund voucher</strong><small>Offered by Northwind Travel · review required</small></span>
              <span class="list-meta"><strong>86.00 Z00Z</strong><small>Ends in 2 days</small></span>
            </button>
            <button class="attention-item" type="button" data-open-flow="permission-detail">
              <span class="list-icon is-right">${objectFamilyIcon("right")}</span>
              <span class="list-copy"><strong>Delivery receipt access</strong><small>Data access · cannot delegate</small></span>
              <span class="list-meta"><strong>2 of 5 uses</strong><small>Ends 31 Jul</small></span>
            </button>
          </div>
        </article>

        <article class="card panel" aria-labelledby="recent-title">
          <div class="section-heading">
            <div><h2 id="recent-title">Recent history</h2><p>Latest wallet events</p></div>
            <button class="section-link" type="button" data-view="activity">View history ${icon("chevron")}</button>
          </div>
          <div class="activity-list">
            ${activityRows(wallet.activities.slice(0, 3), true)}
          </div>
        </article>
      </section>
    </div>`;
}

function moneyView() {
  const assets = walletAssetEntries();
  const assetFilters = [
    ["all", "assets.all"],
    ["coin", "assets.filterCoins"],
    ["token", "assets.filterTokens"],
    ["nft", "assets.filterNfts"]
  ];
  const filteredAssets = state.assetFilter === "all"
    ? assets
    : assets.filter((asset) => asset.type === state.assetFilter);
  return `
    <div class="view-enter">
      <div class="choice-strip" aria-label="${t("assets.filters")}">${assetFilters.map(([value, labelKey]) => `<button class="choice-chip${state.assetFilter === value ? " is-active" : ""}" type="button" data-asset-filter="${value}" aria-pressed="${state.assetFilter === value}">${t(labelKey)}</button>`).join("")}</div>
      <div class="asset-list" role="table" aria-label="${t("nav.assets")}">
        <div class="asset-table-head" role="row" aria-hidden="true"><span>${t("assets.name")}</span><span>${t("assets.balance")}</span><span>${t("assets.value")}</span><span>${t("assets.price")}</span></div>
        ${filteredAssets.map((asset) => `
          <article class="card asset-row" role="row">
            <button class="asset-identity-button" type="button" data-open-flow="asset-detail" data-asset-key="${escapeHtml(asset.key)}" aria-label="${t("assets.viewDetails", { asset: asset.label })}">
              ${assetIcon(asset, "asset-logo")}
              <span class="asset-info"><strong><span class="object-label">${escapeHtml(asset.label)}</span><span class="object-kind">${t(asset.kindKey)}</span></strong></span>
            </button>
            <div class="asset-number" role="cell"><small class="asset-number-label">${t("assets.balance")}</small><strong>${sensitive(asset.balanceLabel)}</strong></div>
            <div class="asset-number" role="cell"><small class="asset-number-label">${t("assets.value")}</small><strong>${asset.value === "—" ? asset.value : sensitive(asset.value)}</strong></div>
            <div class="asset-number" role="cell"><small class="asset-number-label">${t("assets.price")}</small><strong>${t(asset.priceKey)}</strong></div>
          </article>`).join("")}
      </div>
    </div>`;
}

function sendItemIcon(item, className = "") {
  if (item.family === "asset") return assetIcon(item.asset, className);
  return objectTypeIcon(item.family === "voucher" ? "voucher" : "right", item.entry.kind, className);
}

function sendStepIndicator(activeStep) {
  return `<div class="step-indicator" aria-label="Step ${activeStep + 1} of 3">${Array.from({ length: 3 }, (_, index) => `<span class="${index < activeStep ? "is-done" : index === activeStep ? "is-active" : ""}"></span>`).join("")}</div>`;
}

function sendPanelFrame({ title, subtitle, step, body, footer }) {
  return `<section class="send-panel" aria-labelledby="send-panel-title">
    <header class="wallet-action-header send-panel-header">
      <div><h2 id="send-panel-title">${escapeHtml(title)}</h2><p>${escapeHtml(subtitle)}</p></div>
      ${sendStepIndicator(step)}
    </header>
    <div class="send-panel-body">${body}</div>
    <footer class="send-panel-footer">${footer}</footer>
  </section>`;
}

function sendFamilyContextNav(activeFamily) {
  return `<nav class="context-nav context-tab-list" aria-label="${t("send.familyNavigation")}">${sendFamilies.map(({ id, labelKey, iconName }) => `
    <button class="context-nav-item${activeFamily === id ? " is-active" : ""}" type="button" ${activeFamily === id ? 'aria-current="page"' : ""} data-send-family="${id}">
      ${icon(iconName)}<span><strong>${t(labelKey)}</strong></span>
    </button>`).join("")}</nav>`;
}

function sendFamilyFacts(item) {
  if (!item) return "";
  const facts = item.family === "asset"
    ? [
      [t("send.objectType"), item.kindLabel],
      [t("send.spendableBalance"), item.asset.balanceLabel],
      [t("send.unit"), item.asset.unit],
      [t("common.chain"), walletChain(activeWallet().chainId).label]
    ]
    : item.family === "voucher"
      ? [
        [t("send.conditionalValue"), item.entry.value],
        [t("send.lifecycle"), item.entry.status],
        [t("send.expires"), item.entry.expiry || t("common.unavailable")],
        [t("send.receiverAcceptance"), t("send.required")]
      ]
      : [
        [t("send.authorityValue"), t("send.zeroValue")],
        [t("send.action"), item.entry.action],
        [t("send.scope"), item.entry.scope],
        [t("send.remainingUses"), item.entry.remaining],
        [t("send.expires"), item.entry.expiry],
        [t("send.delegation"), item.entry.delegation]
      ];
  return `<dl class="send-family-facts">${facts.map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`).join("")}</dl>`;
}

function sendEmptyPanel(draft) {
  const family = sendFamilies.find(({ id }) => id === draft.family) || sendFamilies[0];
  const action = family.createFlow
    ? `<button class="button button-primary" type="button" data-open-flow="${family.createFlow}">${icon("plus")} ${t(family.id === "voucher" ? "assets.createVoucher" : "assets.createPermission")}</button>`
    : "";
  return sendPanelFrame({
    title: t("send.title"),
    subtitle: t("send.subtitle"),
    step: 0,
    body: `<div class="object-empty-state"><h2>${t(`send.empty.${family.id}`)}</h2>${action}</div>`,
    footer: `<button class="button button-quiet" type="button" data-send-action="cancel">${t("common.back")}</button>`
  });
}

function walletSendView() {
  const wallet = activeWallet();
  const draft = activeSendDraft();
  const item = selectedSendOption(draft);
  const frame = !item && draft.step !== 2
    ? sendEmptyPanel(draft)
    : draft.step === 0
      ? (() => {
        const amountField = item.family === "asset"
          ? `<div class="field-group"><label class="field-label" for="send-amount">${t("send.amount")}</label><div class="input-with-affix"><input id="send-amount" name="amount" type="number" min="${item.asset.divisible ? "0.01" : "1"}" max="${escapeHtml(item.asset.balance.replaceAll(",", ""))}" step="${item.asset.divisible ? "0.01" : "1"}" inputmode="decimal" value="${escapeHtml(draft.amount)}" placeholder="${item.asset.divisible ? "0.00" : "1"}" aria-describedby="send-amount-hint send-amount-error" required><span class="input-affix">${escapeHtml(item.asset.unit)}</span></div><p class="field-hint" id="send-amount-hint">${t("send.available", { value: sensitive(`${item.asset.balance} ${item.asset.unit}`) })}</p><p class="field-error" id="send-amount-error" role="alert"></p></div>`
          : `<div class="field-group"><span class="field-label">${t("send.transferObject")}</span><div class="send-object-value">${sendItemIcon(item, "send-object-icon")}<span><strong>${escapeHtml(item.label)}</strong><small>${escapeHtml(item.meta)}</small></span></div><p class="field-error" id="send-amount-error" role="alert"></p></div>`;
        return sendPanelFrame({
          title: t("send.title"),
          subtitle: t("send.subtitle"),
          step: 0,
          body: `<form class="form-grid" id="send-entry" autocomplete="off" novalidate>
            <div class="field-group"><label class="field-label" for="send-recipient">${t("send.recipient")}</label><input id="send-recipient" name="recipient" value="${escapeHtml(draft.recipient)}" placeholder="${t("send.recipientPlaceholder")}" autocomplete="off" aria-describedby="send-recipient-error" required><p class="field-error" id="send-recipient-error" role="alert"></p></div>
            <div class="field-group"><label class="field-label" for="send-item">${t(`send.itemLabel.${item.family}`)}</label><select id="send-item" name="itemKey">${sendOptionsMarkup(item.family, item.key)}</select></div>
            ${sendFamilyFacts(item)}
            ${amountField}
            <div class="field-group"><label class="field-label" for="send-memo">${t("send.note")} <span class="muted">(${t("send.optional")})</span></label><input id="send-memo" name="memo" value="${escapeHtml(draft.memo)}" maxlength="80" placeholder="${t("send.notePlaceholder")}" autocomplete="off"></div>
          </form>`,
          footer: `<button class="button button-quiet" type="button" data-send-action="cancel">${t("send.cancel")}</button><button class="button button-primary" type="submit" form="send-entry">${t("send.review")} ${icon("chevron")}</button>`
        });
      })()
      : draft.step === 1
        ? (() => {
          const amountLabel = item.family === "asset" ? `${draft.amount} ${item.asset.unit}` : item.meta;
          return sendPanelFrame({
            title: t("send.reviewTitle"),
            subtitle: t("send.reviewSubtitle"),
            step: 1,
            body: `<div class="review-card review-hero">${sendItemIcon(item, "list-icon")}<strong>${escapeHtml(amountLabel)}</strong><span>${escapeHtml(item.label)} · ${escapeHtml(draft.recipientLabel)}</span></div>
              <div class="review-card">
                <div class="summary-row"><span>${t("send.family")}</span><strong>${t(`send.familyName.${item.family}`)}</strong></div>
                <div class="summary-row"><span>${t("send.item")}</span><strong>${escapeHtml(item.label)}</strong></div>
                <div class="summary-row"><span>${t("send.recipientShort")}</span><strong>${escapeHtml(draft.recipientLabel)}</strong></div>
                <div class="summary-row"><span>${t("send.from")}</span><strong>${escapeHtml(wallet.name)}</strong></div>
                <div class="summary-row"><span>${t("send.fee")}</span><strong>${item.family === "asset" ? t("send.feeAtAuthorization") : t("send.notApplicable")}</strong></div>
                ${draft.memo ? `<div class="summary-row"><span>${t("send.noteShort")}</span><strong>${escapeHtml(draft.memo)}</strong></div>` : ""}
              </div>
              <div class="confirmation-note">${icon("shield")} ${t(`send.confirmation.${item.family}`)}</div>`,
            footer: `<button class="button" type="button" data-send-action="back">${t("common.back")}</button><button class="button button-primary" type="button" data-send-action="submit">${t(`send.submit.${item.family}`)}</button>`
          });
        })()
        : (() => {
          const completed = draft.completed || { family: item.family, label: item.label, amountLabel: item.meta, recipientLabel: draft.recipientLabel };
          return sendPanelFrame({
            title: t(`send.sent.${completed.family}`),
            subtitle: t("send.settlementPending"),
            step: 2,
            body: `<div class="result-state"><span class="result-icon is-settling">${icon("activity")}</span><h3>${t("send.settling")}</h3><p>${escapeHtml(completed.label)} · ${escapeHtml(completed.recipientLabel)}</p><div class="receipt-ref">TX-8A42</div></div><div class="review-card"><div class="summary-row"><span>${t("send.value")}</span><strong>${escapeHtml(completed.amountLabel)}</strong></div><div class="summary-row"><span>${t("send.nextUpdate")}</span><strong>${t("send.automatic")}</strong></div></div>`,
            footer: `<button class="button" type="button" data-send-action="history">${t("send.viewHistory")}</button><button class="button button-primary" type="button" data-send-action="done">${t("history.done")}</button>`
          });
        })();

  return `<div class="view-enter workspace-layout send-workspace-layout"><aside class="context-rail">${sendFamilyContextNav(draft.family)}</aside><div class="workspace-panel send-view">${frame}</div></div>`;
}

function walletReceiveView() {
  const wallet = activeWallet();
  const fullAddress = wallet.fullAddress || wallet.address;
  const addressLabel = fullAddress.length > 28
    ? `${fullAddress.slice(0, 12)}…${fullAddress.slice(-10)}`
    : fullAddress;
  const copyLabel = t("walletShell.copyAddress", { wallet: wallet.name });

  return `
    <div class="view-enter receiver-view">
      <section class="receiver-card" aria-labelledby="receiver-card-title">
        <header class="wallet-action-header receiver-card-header">
          <div>
            <h2 id="receiver-card-title">${escapeHtml(t("receive.title"))}</h2>
            <p>${escapeHtml(t("receive.subtitle"))}</p>
          </div>
        </header>
        <div class="receiver-card-body">
          <div class="mock-qr receiver-card-qr" aria-label="${escapeHtml(`${t("assets.receive")} QR`)}">${qrCells(fullAddress)}</div>
          <div class="receiver-address-control" title="${escapeHtml(fullAddress)}">
            <code class="receiver-card-address">${escapeHtml(addressLabel)}</code>
            <button class="icon-button receiver-card-copy" type="button" data-demo-action="copy-wallet-address" aria-label="${escapeHtml(copyLabel)}" title="${escapeHtml(fullAddress)}">${icon("copy")}</button>
          </div>
        </div>
      </section>
    </div>`;
}

const walletSections = [
  { key: "assets", labelKey: "assets.sectionAssets", iconName: "assets" },
  { key: "vouchers", labelKey: "assets.sectionVouchers", iconName: "voucher" },
  { key: "permissions", labelKey: "assets.sectionPermissions", iconName: "permission" }
];

function walletContextNav() {
  return `<nav class="context-nav context-tab-list" aria-label="${t("assets.sections")}">${walletSections.map(({ key, labelKey, iconName, objectFamily }) => `
    <button class="context-nav-item${state.walletSection === key ? " is-active" : ""}" type="button" ${state.walletSection === key ? 'aria-current="page"' : ""} data-wallet-section="${key}">
      ${objectFamily ? objectFamilyIcon(objectFamily) : icon(iconName)}<span><strong>${t(labelKey)}</strong></span>
    </button>`).join("")}</nav>`;
}

function vouchersPanel() {
  const vouchers = activeWallet().vouchers || [];
  if (!vouchers.length) {
    return `<div class="object-empty-state">
      <span class="list-icon is-voucher">${objectFamilyIcon("voucher")}</span>
      <h2>${t("assets.noVouchers")}</h2>
      <button class="button button-primary" type="button" data-open-flow="create-voucher">${icon("plus")} ${t("assets.createVoucher")}</button>
    </div>`;
  }
  return `
    <div class="choice-strip" aria-label="Voucher filters"><button class="choice-chip is-active" type="button">Needs action</button><button class="choice-chip" type="button">Redeemable</button><button class="choice-chip" type="button">History</button><button class="choice-chip" type="button">Quarantined</button></div>
    <div class="claim-list">
      ${vouchers.map((voucher) => `<button class="claim-row" type="button" data-open-flow="${escapeHtml(voucher.detailFlow || "voucher-detail")}" data-object-id="${escapeHtml(voucher.id)}">${objectTypeIcon("voucher", voucher.kind, "list-icon")}<span class="list-copy"><strong>${escapeHtml(voucher.title)}</strong></span><span class="list-meta"><strong>${escapeHtml(voucher.value)}</strong><small class="status-badge is-${escapeHtml(voucher.tone)}">${escapeHtml(voucher.status)}</small></span></button>`).join("")}
    </div>`;
}

const permissionDetails = Object.freeze({
  receipt: Object.freeze({
    title: "Delivery receipt access",
    subtitle: "Held data-access permission",
    remaining: "2 of 5 uses",
    classLabel: "Data access",
    action: "View receipt",
    scope: "receipts.example",
    delegation: "Forbidden",
    expiry: "31 Jul 2026",
    rightId: "right_54ac…1f88",
    kind: "data_access"
  }),
  deploy: Object.freeze({
    title: "Deploy to staging",
    subtitle: "Held machine-capability permission",
    remaining: "1 use",
    classLabel: "Machine capability",
    action: "Deploy",
    scope: "staging.example",
    delegation: "Attenuation only",
    expiry: "19 Aug 2026",
    rightId: "right_8d9e…4a62",
    kind: "machine_capability"
  })
});

function permissionsPanel() {
  const permissions = activeWallet().permissions || [];
  if (!permissions.length) {
    return `<div class="object-empty-state">
      <span class="list-icon is-right">${objectFamilyIcon("right")}</span>
      <h2>${t("assets.noPermissions")}</h2>
      <button class="button button-primary" type="button" data-open-flow="create-permission">${icon("plus")} ${t("assets.createPermission")}</button>
    </div>`;
  }
  return `
    <div class="choice-strip" aria-label="Permission filters"><button class="choice-chip is-active" type="button">Held</button><button class="choice-chip" type="button">Delegated</button><button class="choice-chip" type="button">Used</button></div>
    <div class="permission-list">
      ${permissions.map((permission) => `<button class="permission-row" type="button" data-open-flow="permission-detail" data-permission-id="${escapeHtml(permission.id)}">${objectTypeIcon("right", permission.kind, "list-icon")}<span class="list-copy"><strong>${escapeHtml(permission.title)}</strong></span><span class="list-meta"><strong>${escapeHtml(permission.remaining)}</strong><small class="status-badge is-${escapeHtml(permission.tone)}">${escapeHtml(permission.status)}</small></span></button>`).join("")}
    </div>`;
}

function walletView() {
  const panel = state.walletSection === "assets" ? moneyView() : state.walletSection === "vouchers" ? vouchersPanel() : permissionsPanel();
  return `<div class="view-enter workspace-layout wallet-assets-layout"><aside class="context-rail">${walletContextNav()}</aside><div class="workspace-panel">${panel}</div></div>`;
}

function statusText(status) {
  const key = {
    settling: "history.settling",
    settled: "history.settled",
    active: "history.active",
    attention: "history.needsAttention"
  }[status] || "history.ready";
  return t(key);
}

function activityText(item, field) {
  const key = item[`${field}Key`];
  if (!key) return item[field] || "";
  const values = { ...item[`${field}Values`] };
  Object.entries(item[`${field}ValueKeys`] || {}).forEach(([name, valueKey]) => {
    values[name] = t(valueKey);
  });
  return t(key, values);
}

function activityRows(items, compact = false) {
  if (!items.length) {
    return `<div class="empty-state"><span class="list-icon">${icon("search")}</span><h3>${t("history.noMatching")}</h3><p>${t("history.tryAnother")}</p></div>`;
  }

  return items.map((item) => {
    const iconName = item.id.startsWith("claim-") ? "claim" : item.type === "security" ? "backup" : item.direction === "in" ? "receive" : "send";
    const iconMarkup = item.type === "voucher" ? objectFamilyIcon("voucher") : item.type === "permission" ? objectFamilyIcon("right") : icon(iconName);
    const iconClass = item.direction === "in" ? "is-incoming" : item.direction === "out" ? "is-outgoing" : "";
    const amountClass = item.direction === "in" ? "positive" : item.direction === "out" ? "negative" : "";
    return `
      <button class="activity-row" type="button" data-open-activity="${escapeHtml(item.id)}">
        <span class="activity-icon ${iconClass}">${iconMarkup}</span>
        <span class="activity-copy"><strong>${escapeHtml(activityText(item, "title"))}</strong><small><span class="activity-detail">${escapeHtml(activityText(item, "detail"))}${compact ? ` · ${escapeHtml(activityText(item, "time"))}` : ""}</span>${compact ? "" : `<span class="status-badge is-${escapeHtml(item.status)}">${statusText(item.status)}</span>`}</small></span>
        <span class="activity-value"><strong class="${amountClass}">${escapeHtml(activityText(item, "amount"))}</strong><small>${escapeHtml(activityText(item, "time"))}</small></span>
      </button>`;
  }).join("");
}

function matchesActivityFilter(item, filter) {
  if (filter === "all") return true;
  if (filter === "asset") return item.type === "asset" || item.type === "money";
  return item.type === filter;
}

function activityView() {
  const visible = activeWallet().activities.filter((item) => matchesActivityFilter(item, state.activityFilter));

  const filters = [
    ["all", "history.all"], ["asset", "history.assets"], ["voucher", "history.vouchers"], ["permission", "history.permissions"], ["security", "history.system"]
  ].map(([value, labelKey]) => `<button class="choice-chip${state.activityFilter === value ? " is-active" : ""}" type="button" data-filter="${value}">${t(labelKey)}</button>`).join("");

  return `
    <div class="view-enter">
      <div class="filter-bar choice-strip" aria-label="${t("history.filters")}">
        ${filters}
        <label class="search-wrap"><span class="sr-only">${t("history.search")}</span>${icon("search")}<input id="activity-search" type="search" placeholder="${t("history.search")}" autocomplete="off"></label>
      </div>
      <section class="activity-card-list" id="activity-results" aria-label="${t("history.results")}">
        ${activityRows(visible)}
      </section>
    </div>`;
}

function swapView() {
  const asset = supportedAsset("z00z");
  return `
    <div class="view-enter wallet-tool-view">
      <section class="wallet-tool-grid wallet-tool-grid-single wallet-tool-grid-centered">
        <article class="card wallet-tool-card swap-card">
          <div class="tool-card-heading"><span class="list-icon">${icon("swap")}</span><div><h2>Build a swap</h2></div></div>
          <div class="form-grid">
            <div class="field-group"><label class="field-label" for="swap-from">From</label><select id="swap-from">${assetOptions("z00z")}</select><p class="field-hint">Available: ${sensitive(`${asset.balance} ${asset.unit}`)}</p></div>
            <div class="field-group"><label class="field-label" for="swap-amount">Amount</label><div class="input-with-affix"><input id="swap-amount" type="number" min="0.01" max="${escapeHtml(asset.balance.replaceAll(",", ""))}" step="0.01" inputmode="decimal" placeholder="0.00"><span class="input-affix">Z00Z</span></div></div>
            <div class="field-group"><label class="field-label" for="swap-to">To</label><select id="swap-to">${assetOptions("dai")}</select></div>
            <button class="button button-primary" type="button" data-demo-action="preview-swap">${icon("swap")} Preview swap</button>
          </div>
        </article>
      </section>
    </div>`;
}

function defaultExchangeDraft() {
  return {
    step: 0,
    providerId: "near-intents",
    sourceAssetKey: "z00z",
    amount: "",
    destinationId: demoRuntime.exchangeProvider("near-intents").defaultDestination,
    orderType: "market",
    limitPrice: "",
    recipient: "",
    refundAddress: "",
    slippageBps: "100",
    deadlineMinutes: "5"
  };
}

function activeExchangeDraft() {
  const wallet = activeWallet();
  state.exchangeDrafts ||= {};
  state.exchangeDrafts[wallet.id] ||= defaultExchangeDraft();
  const draft = state.exchangeDrafts[wallet.id];
  const provider = demoRuntime.exchangeProvider(draft.providerId);
  if (!walletAssetEntries().some(({ key }) => key === draft.sourceAssetKey)) draft.sourceAssetKey = walletAssetEntries()[0]?.key || "z00z";
  if (!demoRuntime.exchangeDestinations(provider.id).some(({ id }) => id === draft.destinationId)) {
    draft.destinationId = provider.defaultDestination;
  }
  return draft;
}

function exchangeProviderContextNav(draft) {
  return `<nav class="context-nav context-tab-list exchange-provider-context" role="radiogroup" aria-label="${t("exchange.executionModel")}">${Object.values(demoRuntime.EXCHANGE_PROVIDER_LUT).map((provider) => `
    <button class="context-nav-item${draft.providerId === provider.id ? " is-active" : ""}" type="button" role="radio" aria-checked="${draft.providerId === provider.id}" data-exchange-provider="${provider.id}">
      ${icon(provider.iconName)}<span><strong>${t(provider.labelKey)}</strong></span>
    </button>`).join("")}</nav>`;
}

function exchangeDestinationOptions(draft) {
  return demoRuntime.exchangeDestinations(draft.providerId).map((destination) => `<option value="${escapeHtml(destination.id)}"${draft.destinationId === destination.id ? " selected" : ""}>${escapeHtml(destination.label)} · ${escapeHtml(destination.network)}</option>`).join("");
}

function exchangeProviderFields(draft) {
  if (draft.providerId === "hyperliquid") {
    return `
      <div class="field-group"><label class="field-label" for="exchange-order-type">${t("exchange.orderType")}</label><select id="exchange-order-type" name="orderType"><option value="market"${draft.orderType === "market" ? " selected" : ""}>${t("exchange.market")}</option><option value="limit"${draft.orderType === "limit" ? " selected" : ""}>${t("exchange.limit")}</option></select></div>
      ${draft.orderType === "limit" ? `<div class="field-group"><label class="field-label" for="exchange-limit-price">${t("exchange.limitPrice")}</label><input id="exchange-limit-price" name="limitPrice" type="number" min="0" step="any" inputmode="decimal" value="${escapeHtml(draft.limitPrice)}" placeholder="${t("exchange.limitPricePlaceholder")}"></div>` : ""}`;
  }
  return `
    <div class="field-group"><label class="field-label" for="exchange-recipient">${t("exchange.recipient")}</label><input id="exchange-recipient" name="recipient" value="${escapeHtml(draft.recipient)}" placeholder="${t("exchange.recipientPlaceholder")}" autocomplete="off"></div>
    <div class="field-group"><label class="field-label" for="exchange-refund">${t("exchange.refundAddress")}</label><input id="exchange-refund" name="refundAddress" value="${escapeHtml(draft.refundAddress)}" placeholder="${t("exchange.refundPlaceholder")}" autocomplete="off"></div>
    <div class="exchange-control-grid">
      <div class="field-group"><label class="field-label" for="exchange-slippage">${t("exchange.slippage")}</label><select id="exchange-slippage" name="slippageBps"><option value="50"${draft.slippageBps === "50" ? " selected" : ""}>0.5%</option><option value="100"${draft.slippageBps === "100" ? " selected" : ""}>1%</option><option value="200"${draft.slippageBps === "200" ? " selected" : ""}>2%</option></select></div>
      <div class="field-group"><label class="field-label" for="exchange-deadline">${t("exchange.deadline")}</label><select id="exchange-deadline" name="deadlineMinutes"><option value="3"${draft.deadlineMinutes === "3" ? " selected" : ""}>3 min</option><option value="5"${draft.deadlineMinutes === "5" ? " selected" : ""}>5 min</option><option value="10"${draft.deadlineMinutes === "10" ? " selected" : ""}>10 min</option></select></div>
    </div>`;
}

function captureExchangeDraft(form) {
  const draft = activeExchangeDraft();
  const fields = ["sourceAssetKey", "amount", "destinationId", "orderType", "limitPrice", "recipient", "refundAddress", "slippageBps", "deadlineMinutes"];
  fields.forEach((name) => {
    if (form.elements[name]) draft[name] = form.elements[name].value.trim();
  });
  return draft;
}

function exchangeReview(draft) {
  const provider = demoRuntime.exchangeProvider(draft.providerId);
  const source = supportedAsset(draft.sourceAssetKey);
  const destination = demoRuntime.EXCHANGE_DESTINATION_LUT[draft.destinationId];
  const providerRows = draft.providerId === "hyperliquid"
    ? `<div class="summary-row"><span>${t("exchange.pair")}</span><strong>${escapeHtml(source.unit)}/${escapeHtml(destination.unit)}</strong></div>
       <div class="summary-row"><span>${t("exchange.orderType")}</span><strong>${t(`exchange.${draft.orderType}`)}</strong></div>
       ${draft.orderType === "limit" ? `<div class="summary-row"><span>${t("exchange.limitPrice")}</span><strong>${escapeHtml(draft.limitPrice)}</strong></div>` : ""}`
    : `<div class="summary-row"><span>${t("exchange.route")}</span><strong>${escapeHtml(walletChain(activeWallet().chainId).label)} → ${escapeHtml(destination.network)}</strong></div>
       <div class="summary-row"><span>${t("exchange.mode")}</span><strong>${t("exchange.exactInput")}</strong></div>
       <div class="summary-row"><span>${t("exchange.recipient")}</span><strong>${escapeHtml(draft.recipient)}</strong></div>
       <div class="summary-row"><span>${t("exchange.refundAddress")}</span><strong>${escapeHtml(draft.refundAddress)}</strong></div>
       <div class="summary-row"><span>${t("exchange.slippage")}</span><strong>${Number(draft.slippageBps) / 100}%</strong></div>
       <div class="summary-row"><span>${t("exchange.deadline")}</span><strong>${escapeHtml(draft.deadlineMinutes)} min</strong></div>`;
  return `<article class="card wallet-tool-card exchange-card">
    <div class="tool-card-heading"><span class="list-icon">${icon(provider.iconName)}</span><div><h2>${t("exchange.reviewTitle")}</h2></div></div>
    <div class="review-card">
      <div class="summary-row"><span>${t("exchange.executionModel")}</span><strong>${t(provider.labelKey)}</strong></div>
      <div class="summary-row"><span>${t("exchange.from")}</span><strong>${escapeHtml(draft.amount)} ${escapeHtml(source.unit)}</strong></div>
      <div class="summary-row"><span>${t("exchange.to")}</span><strong>${escapeHtml(destination.label)} · ${escapeHtml(destination.network)}</strong></div>
      ${providerRows}
    </div>
    <div class="exchange-unavailable-grid">
      <div><span>${t("exchange.rate")}</span><strong>${t("common.unavailable")}</strong></div>
      <div><span>${t("exchange.expectedOutput")}</span><strong>${t("common.unavailable")}</strong></div>
      <div><span>${t("exchange.minimumReceived")}</span><strong>${t("common.unavailable")}</strong></div>
      <div><span>${t("exchange.fee")}</span><strong>${t("common.unavailable")}</strong></div>
      <div><span>${t("exchange.eta")}</span><strong>${t("common.unavailable")}</strong></div>
      ${draft.providerId === "near-intents"
        ? `<div><span>${t("exchange.depositAddress")}</span><strong>${t("common.unavailable")}</strong></div><div><span>${t("exchange.executionStatus")}</span><strong>${t("common.unavailable")}</strong></div>`
        : `<div><span>${t("exchange.marketState")}</span><strong>${t("common.unavailable")}</strong></div>`}
    </div>
    <div class="confirmation-note">${icon("shield")} ${t("exchange.connectorBoundary")}</div>
    <div class="wallet-tool-actions"><button class="button" type="button" data-exchange-action="back">${t("common.back")}</button><button class="button button-primary" type="button" data-exchange-action="new">${t("exchange.editRequest")}</button></div>
  </article>`;
}

function exchangeView() {
  const draft = activeExchangeDraft();
  const asset = supportedAsset(draft.sourceAssetKey);
  const panel = draft.step === 1
    ? `<section class="wallet-tool-grid wallet-tool-grid-single wallet-tool-grid-centered">${exchangeReview(draft)}</section>`
    : `<section class="wallet-tool-grid wallet-tool-grid-single wallet-tool-grid-centered">
        <article class="card wallet-tool-card exchange-card">
          <div class="tool-card-heading"><span class="list-icon">${icon("exchange")}</span><div><h2>${t("exchange.title")}</h2></div></div>
          <form class="form-grid" id="exchange-entry" autocomplete="off" novalidate>
            <div class="field-group"><label class="field-label" for="exchange-source">${t("exchange.sourceAsset")}</label><select id="exchange-source" name="sourceAssetKey">${assetOptions(draft.sourceAssetKey)}</select><p class="field-hint">${t("send.available", { value: sensitive(`${asset.balance} ${asset.unit}`) })}</p></div>
            <div class="field-group"><label class="field-label" for="exchange-amount">${t("exchange.amount")}</label><div class="input-with-affix"><input id="exchange-amount" name="amount" type="number" min="${asset.divisible ? "0.01" : "1"}" max="${escapeHtml(asset.balance.replaceAll(",", ""))}" step="${asset.divisible ? "0.01" : "1"}" inputmode="decimal" value="${escapeHtml(draft.amount)}" placeholder="0.00" aria-describedby="exchange-error" required><span class="input-affix">${escapeHtml(asset.unit)}</span></div></div>
            <div class="field-group"><label class="field-label" for="exchange-destination">${t("exchange.destinationAsset")}</label><select id="exchange-destination" name="destinationId">${exchangeDestinationOptions(draft)}</select></div>
            ${exchangeProviderFields(draft)}
            <p class="field-error" id="exchange-error" role="alert"></p>
            <button class="button button-primary" type="submit">${icon("exchange")} ${t("exchange.review")}</button>
          </form>
        </article>
      </section>`;
  return `<div class="view-enter workspace-layout exchange-workspace-layout">
    <aside class="context-rail">${exchangeProviderContextNav(draft)}</aside>
    <div class="workspace-panel wallet-tool-view">${panel}</div>
  </div>`;
}

function stakingView() {
  const wallet = activeWallet();
  const summary = wallet.summary;
  return `
    <div class="view-enter wallet-tool-view">
      <section class="wallet-tool-grid wallet-tool-grid-single wallet-tool-grid-centered">
        <article class="card wallet-tool-card staking-card">
          <div class="tool-card-heading"><span class="list-icon">${icon("staking")}</span><div><h2>${t("staking.prepare")}</h2></div></div>
          <div class="staking-summary" aria-label="${t("staking.totals")}">
            <div class="staking-metric"><span>${t("staking.availableToStake")}</span><strong>${sensitive(`${summary.available} Z00Z`)}</strong></div>
            <div class="staking-metric"><span>${t("staking.staked")}</span><strong>0.00 Z00Z</strong></div>
            <div class="staking-metric"><span>${t("staking.rewards")}</span><strong>0.00 Z00Z</strong></div>
          </div>
          <div class="form-grid">
            <div class="field-group"><label class="field-label" for="stake-amount">${t("staking.amount")}</label><div class="input-with-affix"><input id="stake-amount" type="number" min="0.01" max="${escapeHtml(summary.available.replaceAll(",", ""))}" step="0.01" inputmode="decimal" placeholder="0.00"><span class="input-affix">Z00Z</span></div><p class="field-hint">${t("staking.availableBalance", { value: sensitive(`${summary.available} Z00Z`) })}</p></div>
            <div class="field-group"><label class="field-label" for="stake-validator">${t("staking.validator")}</label><select id="stake-validator"><option>${t("staking.validatorPlaceholder")}</option></select></div>
            <button class="button button-primary" type="button" data-demo-action="prepare-stake">${icon("staking")} ${t("staking.review")}</button>
          </div>
        </article>
      </section>
    </div>`;
}

function walletBackupView() {
  return `
    <div class="view-enter wallet-tool-view">
      <section class="wallet-tool-grid wallet-tool-grid-single wallet-tool-grid-centered">
        <article class="card wallet-tool-card backup-card">
          <div class="tool-card-heading backup-card-heading"><span class="list-icon">${icon("backup")}</span><div><h2>Backup status</h2></div></div>
          <div class="review-card backup-summary"><div class="summary-row"><span>Latest backup</span><strong>10 Jul 2026 · 09:42</strong></div><div class="summary-row"><span>Integrity</span><strong class="trust-label">${icon("shield")} Verified</strong></div><div class="summary-row"><span>Destination</span><strong>Encrypted local file</strong></div></div>
          <div class="wallet-backup-actions">
            <button class="button button-primary button-full wallet-backup-action" type="button" data-demo-action="backup">${icon("backup")} Create fresh backup</button>
            <button class="button button-full wallet-backup-recovery" type="button" data-demo-action="restore">${icon("restore")} Recover from backup</button>
          </div>
        </article>
      </section>
    </div>`;
}

const walletSettingsMeta = {
  general: ["General", "settings"],
  security: ["Security", "shield"],
  backup: ["Backup", "backup"],
  policies: ["Policies", "permission"],
  advanced: ["Advanced", "advanced"]
};

function isMobileNavigation() {
  return window.matchMedia("(max-width: 767px)").matches;
}

function isMobileDrawer(type) {
  return type === "menu";
}

function mobilePopupHeader(label, branded = false) {
  return `<header class="mobile-popup-header${branded ? " is-branded" : ""}">
    <span class="mobile-popup-icon-spacer"></span>
    ${branded
      ? `<span class="mobile-drawer-brand"><img src="assets/logo/z00z-logo-gold-circle.png" alt=""><strong>Z00Z</strong></span>`
      : `<strong>${escapeHtml(label)}</strong>`}
    <button class="mobile-popup-icon" type="button" data-mobile-popup-close aria-label="${escapeHtml(t("common.close"))}">${icon("close")}</button>
  </header>`;
}

function mobilePopupItem({ label, iconName = "", active = false, attributes = "", trailing = "" }) {
  return `<button class="mobile-popup-item${active ? " is-active" : ""}" type="button"${active ? ' aria-current="page"' : ""} ${attributes}>
    ${iconName ? icon(iconName) : ""}
    <span>${escapeHtml(label)}</span>
    ${trailing}
  </button>`;
}

function mobileMenuAccordionMarkup({ group, label, iconName, content }) {
  const expanded = mobileMenuExpandedGroups.has(group);
  const buttonId = `mobile-menu-${group}-toggle`;
  const panelId = `mobile-menu-${group}`;
  return `<section class="mobile-menu-accordion">
    <button id="${buttonId}" class="mobile-popup-item mobile-menu-accordion-toggle" type="button" data-mobile-menu-group="${group}" aria-expanded="${expanded}" aria-controls="${panelId}">
      ${icon(iconName)}
      <span>${escapeHtml(label)}</span>
      ${icon("chevron", "mobile-menu-accordion-chevron")}
    </button>
    <div id="${panelId}" class="mobile-menu-accordion-panel" data-mobile-menu-panel="${group}" role="region" aria-labelledby="${buttonId}"${expanded ? "" : " hidden"}>
      ${content}
    </div>
  </section>`;
}

function mobileWalletAccordionContent() {
  return `<div class="mobile-menu-accordion-items">
    ${state.wallets.map((wallet) => `<button class="mobile-popup-item${wallet.id === state.selectedWalletId ? " is-active" : ""}" type="button"${wallet.id === state.selectedWalletId ? ' aria-current="page"' : ""} data-mobile-select-wallet="${escapeHtml(wallet.id)}">
      <span class="wallet-avatar" aria-hidden="true">${escapeHtml(wallet.initials)}</span>
      <span>${escapeHtml(wallet.name)}</span>
      ${wallet.id === state.selectedWalletId ? icon("check") : ""}
    </button>`).join("")}
  </div>
  <div class="mobile-wallet-actions">
    <button class="mobile-popup-item mobile-wallet-action is-add" type="button" data-mobile-popup-action="add-wallet">${icon("plus")}<span>${t("app.addWallet")}</span></button>
    <button class="mobile-popup-item mobile-wallet-action is-remove" type="button" data-mobile-popup-action="remove-wallet"${state.wallets.length === 0 ? " disabled" : ""}>${icon("remove")}<span>${t("app.removeWallet")}</span></button>
  </div>`;
}

function mobileNetworkAccordionContent() {
  return `<div class="mobile-menu-accordion-items">
    ${networkEntries.map((entry) => `<button class="mobile-popup-item${state.view === "telemetry" && state.telemetrySource === entry.key ? " is-active" : ""}" type="button"${state.view === "telemetry" && state.telemetrySource === entry.key ? ' aria-current="page"' : ""} data-mobile-select-network="${entry.key}">
      <span class="network-avatar" aria-hidden="true">${entry.initials}</span>
      <span>${escapeHtml(entry.label)}</span>
      ${state.view === "telemetry" && state.telemetrySource === entry.key ? icon("check") : ""}
    </button>`).join("")}
  </div>`;
}

function mobilePopupMarkup(type) {
  if (type === "assets") {
    return `${mobilePopupHeader(t("assets.sections"))}
      <div class="mobile-popup-list">
        ${walletSections.map(({ key, labelKey, iconName }) => mobilePopupItem({
          label: t(labelKey),
          iconName,
          active: state.view === "wallet" && state.walletSection === key,
          attributes: `data-mobile-wallet-section="${key}"`
        })).join("")}
      </div>`;
  }
  if (type === "wallet-settings") {
    return `${mobilePopupHeader(t("nav.settings"))}
      <div class="mobile-popup-list">
        ${Object.entries(walletSettingsMeta).map(([key, [label, iconName]]) => mobilePopupItem({
          label,
          iconName,
          active: state.view === "wallet-settings" && state.walletSettingsSection === key,
          attributes: `data-mobile-wallet-settings-section="${key}"`
        })).join("")}
      </div>`;
  }
  if (type === "exchange") {
    const draft = activeExchangeDraft();
    return `${mobilePopupHeader(t("exchange.executionModel"))}
      <div class="mobile-popup-list">
        ${Object.values(demoRuntime.EXCHANGE_PROVIDER_LUT).map((provider) => mobilePopupItem({
          label: t(provider.labelKey),
          iconName: provider.iconName,
          active: draft.providerId === provider.id,
          attributes: `data-mobile-exchange-provider="${provider.id}"`
        })).join("")}
      </div>`;
  }
  return `${mobilePopupHeader(t("app.menu"), true)}
    <div class="mobile-popup-list">
      ${mobileMenuAccordionMarkup({
        group: "wallets",
        label: t("app.wallets"),
        iconName: "wallet",
        content: mobileWalletAccordionContent()
      })}
      ${mobileMenuAccordionMarkup({
        group: "network",
        label: t("app.network"),
        iconName: "network",
        content: mobileNetworkAccordionContent()
      })}
      ${mobilePopupItem({ label: t("app.settings"), iconName: "settings", active: state.view === "settings", attributes: 'data-mobile-app-view="settings"' })}
      ${mobilePopupItem({ label: t("help.title"), iconName: "question", attributes: 'data-help-topic="app"' })}
      ${mobilePopupItem({ label: t("app.logOut"), iconName: "logout", attributes: 'data-mobile-popup-action="logout"' })}
    </div>`;
}

function positionMobilePopup(trigger) {
  if (isMobileDrawer(mobilePopupType)) {
    mobilePopupMenu.style.removeProperty("--mobile-popup-left");
    mobilePopupMenu.style.removeProperty("--mobile-popup-top");
    mobilePopupMenu.style.removeProperty("--mobile-popup-width");
    return;
  }
  const navigationBounds = document.querySelector("#primary-topbar").getBoundingClientRect();
  const triggerBounds = trigger?.getBoundingClientRect();
  const popupWidth = Math.min(300, window.innerWidth - 16);
  const preferredLeft = triggerBounds ? triggerBounds.left : 8;
  const left = Math.max(8, Math.min(preferredLeft, window.innerWidth - popupWidth - 8));
  mobilePopupMenu.style.setProperty("--mobile-popup-left", `${left}px`);
  mobilePopupMenu.style.setProperty("--mobile-popup-top", `${navigationBounds.bottom + 7}px`);
  mobilePopupMenu.style.setProperty("--mobile-popup-width", `${popupWidth}px`);
}

function closeMobilePopup({ restoreFocus = false } = {}) {
  if (!mobilePopupMenu || mobilePopupMenu.hidden) return;
  const trigger = mobilePopupTrigger;
  mobilePopupMenu.hidden = true;
  mobilePopupMenu.innerHTML = "";
  mobilePopupMenu.removeAttribute("data-popup-type");
  mobilePopupMenu.setAttribute("role", "menu");
  mobilePopupMenu.removeAttribute("aria-modal");
  mobileMenuBackdrop.hidden = true;
  document.body.classList.remove("has-mobile-drawer");
  mobilePopupType = "";
  mobilePopupTrigger = null;
  mobileMenuButton.setAttribute("aria-expanded", "false");
  document.querySelectorAll("[data-mobile-popup]").forEach((button) => button.setAttribute("aria-expanded", "false"));
  if (restoreFocus && trigger?.isConnected) trigger.focus();
}

function openMobilePopup(type, trigger = mobileMenuButton) {
  if (!isMobileNavigation()) return;
  if (!mobilePopupMenu.hidden && mobilePopupType === type && mobilePopupTrigger === trigger) {
    closeMobilePopup({ restoreFocus: true });
    return;
  }
  mobilePopupType = type;
  mobilePopupTrigger = trigger;
  mobilePopupMenu.innerHTML = mobilePopupMarkup(type);
  mobilePopupMenu.dataset.popupType = type;
  mobilePopupMenu.setAttribute("role", isMobileDrawer(type) ? "dialog" : "menu");
  if (isMobileDrawer(type)) {
    mobilePopupMenu.setAttribute("aria-modal", "true");
    mobileMenuBackdrop.hidden = false;
    document.body.classList.add("has-mobile-drawer");
  } else {
    mobilePopupMenu.removeAttribute("aria-modal");
    mobileMenuBackdrop.hidden = true;
    document.body.classList.remove("has-mobile-drawer");
  }
  mobilePopupMenu.hidden = false;
  mobileMenuButton.setAttribute("aria-expanded", String(trigger === mobileMenuButton));
  document.querySelectorAll("[data-mobile-popup]").forEach((button) => button.setAttribute("aria-expanded", String(button === trigger)));
  positionMobilePopup(trigger);
  requestAnimationFrame(() => mobilePopupMenu.querySelector("button")?.focus());
}

function walletSettingsContextNav() {
  const item = (key) => {
    const [label, iconName] = walletSettingsMeta[key];
    const active = state.walletSettingsSection === key;
    return `<button class="context-nav-item${active ? " is-active" : ""}" type="button" ${active ? 'aria-current="page"' : ""} data-wallet-settings-section="${key}">${icon(iconName)}<span><strong>${label}</strong></span></button>`;
  };
  return `<nav class="context-nav context-tab-list wallet-settings-context" aria-label="Selected wallet settings">${item("general")}${item("security")}${item("backup")}${item("policies")}${item("advanced")}</nav>`;
}

function walletSettingsYaml() {
  const wallet = activeWallet();
  const preferences = activeWalletPreferences();
  return [
    "schema_version: 1",
    "wallet:",
    `  id: \"${yamlScalar(wallet.id)}\"`,
    `  chain: \"${yamlScalar(wallet.chainId)}\"`,
    "  display:",
    `    name: \"${yamlScalar(wallet.name)}\"`,
    `    currency: ${preferences.currency}`,
    "  transactions:",
    `    default_fee: \"${yamlScalar(preferences.defaultFee)}\"`,
    "  security:",
    `    lock_after_minutes: ${preferences.lockAfterMinutes}`,
    "  backup:",
    `    auto_backup: ${preferences.autoBackup}`,
    `    interval_hours: ${preferences.backupIntervalHours}`,
    "    encrypt: true",
    "  policy_rules:",
    `    max_transaction: \"${yamlScalar(preferences.policyRules.maxTransaction)}\"`,
    `    max_daily: \"${yamlScalar(preferences.policyRules.maxDaily)}\"`,
    `    require_confirmation: ${preferences.policyRules.requireConfirmation}`,
    `    allowed_assets: ${preferences.policyRules.allowedAssets}`,
    `    allowed_recipients: \"${yamlScalar(preferences.policyRules.allowedRecipients || "any")}\"`,
    `    time_restrictions: ${preferences.policyRules.timeWindow}`,
    "  compliance_profile:",
    `    preview: \"${yamlScalar(preferences.policyProfile)}\"`,
    "# Secrets, paths, session tokens, and receiver material are excluded."
  ].join("\n");
}

function walletSettingsGeneralDetail() {
  const wallet = activeWallet();
  return `
    <div class="setting-group settings-first-group">
      <div class="setting-line compact-row" data-help-anchor="wallet-name"><strong class="compact-row-label">Wallet name</strong><span class="compact-value" title="${escapeHtml(wallet.name)}">${escapeHtml(wallet.name)}</span><button class="button compact-action" type="button" data-open-flow="wallet-rename">Rename</button></div>
      <div class="setting-line compact-row" data-help-anchor="wallet-id"><strong class="compact-row-label">Wallet ID</strong><span class="compact-value mono" title="${escapeHtml(wallet.id)}">${escapeHtml(wallet.id)}</span><span class="status-badge compact-action">Read-only</span></div>
      <div class="setting-line compact-row" data-help-anchor="wallet-chain" data-wallet-chain-readonly aria-label="${escapeHtml(t("common.chain"))}: ${escapeHtml(walletChain(wallet.chainId).label)}. ${escapeHtml(t("common.readOnly"))}."><strong class="compact-row-label">${t("common.chain")}</strong><span class="compact-value"></span><span class="compact-action">${walletChainBadgeMarkup(wallet.chainId)}</span></div>
    </div>`;
}

function walletSettingsSecurityDetail() {
  const wallet = activeWallet();
  const preferences = activeWalletPreferences();
  return `
    <div class="setting-group settings-first-group">
      <div class="setting-line compact-row" data-help-anchor="wallet-lock"><label class="compact-row-label" for="wallet-lock-after">Lock app after</label><select class="compact-value" id="wallet-lock-after" data-wallet-settings-control="lock-after"><option value="5"${preferences.lockAfterMinutes === "5" ? " selected" : ""}>5 minutes</option><option value="15"${preferences.lockAfterMinutes === "15" ? " selected" : ""}>15 minutes</option><option value="30"${preferences.lockAfterMinutes === "30" ? " selected" : ""}>30 minutes</option><option value="never"${preferences.lockAfterMinutes === "never" ? " selected" : ""}>Never</option></select><span class="compact-action"></span></div>
      <div class="setting-line compact-row"><strong class="compact-row-label">Lock now</strong><span class="compact-value"></span><button class="button compact-action" type="button" data-demo-action="lock">Lock now</button></div>
      <div class="setting-line compact-row"><strong class="compact-row-label">${t("walletSettings.password")}</strong><span class="compact-value"></span><button class="button compact-action" type="button" data-open-flow="wallet-password-change">${t("walletSettings.changePassword")}</button></div>
    </div>
    <div class="setting-group wallet-key-settings">
      <div class="setting-line compact-row" data-help-anchor="recovery-phrase"><strong class="compact-row-label">Recovery phrase</strong><span class="compact-value"></span><button class="button compact-action" type="button" data-open-flow="wallet-seed-reveal">View phrase</button></div>
      <div class="setting-line compact-row"><strong class="compact-row-label">Public keys</strong><span class="compact-value"></span><button class="button compact-action" type="button" data-open-flow="wallet-public-export">View keys</button></div>
      <div class="setting-line compact-row"><strong class="compact-row-label">Master key</strong><span class="compact-value" title="${escapeHtml(preferences.lastMasterKeyRotation)}">${escapeHtml(preferences.lastMasterKeyRotation)}</span><button class="button button-primary compact-action" type="button" data-open-flow="wallet-key-rotation">Rotate</button></div>
    </div>`;
}

function walletSettingsBackupDetail() {
  const wallet = activeWallet();
  const preferences = activeWalletPreferences();
  return `
    <div class="review-card wallet-settings-summary"><div class="summary-row"><span>Latest backup</span><strong>10 Jul 2026 · 09:42</strong></div><div class="summary-row"><span>Integrity</span><strong class="trust-label">${icon("shield")} Verified</strong></div><div class="summary-row"><span>Encryption</span><strong>Enabled</strong></div><div class="summary-row"><span>Wallet</span><strong>${escapeHtml(wallet.name)}</strong></div></div>
    <div class="setting-group"><div class="setting-line compact-row" data-help-anchor="automatic-backup"><strong class="compact-row-label">Automatic backup</strong><span class="compact-value"></span><button class="toggle compact-action" type="button" aria-pressed="${preferences.autoBackup}" aria-label="Automatic wallet backup" data-demo-action="wallet-auto-backup"></button></div><div class="setting-line compact-row"><label class="compact-row-label" for="wallet-backup-interval">Backup interval</label><select class="compact-value" id="wallet-backup-interval" data-wallet-settings-control="backup-interval"><option value="6"${preferences.backupIntervalHours === "6" ? " selected" : ""}>Every 6 hours</option><option value="24"${preferences.backupIntervalHours === "24" ? " selected" : ""}>Every 24 hours</option><option value="72"${preferences.backupIntervalHours === "72" ? " selected" : ""}>Every 3 days</option></select><span class="compact-action"></span></div></div>`;
}

function walletSettingsPoliciesDetail() {
  const preferences = activeWalletPreferences();
  const rules = preferences.policyRules;
  return `
    <div class="setting-group settings-first-group">
      <div class="setting-line compact-row" data-help-anchor="policy-profile"><strong class="compact-row-label">Profile preview</strong><span class="compact-value" title="${escapeHtml(preferences.policyProfile)}">${escapeHtml(preferences.policyProfile)}</span><span class="status-badge is-ready compact-action">Target</span></div>
      <div class="setting-line compact-row"><strong class="compact-row-label">Local spend rules</strong><span class="compact-value mono">${escapeHtml(rules.maxTransaction)} / ${escapeHtml(rules.maxDaily)} Z00Z</span><button class="button button-primary compact-action" type="button" data-open-flow="wallet-policy-apply">Review</button></div>
      <div class="setting-line compact-row"><strong class="compact-row-label">Protocol rules</strong><span class="compact-value"></span><span class="status-badge compact-action">Locked</span></div>
      <div class="setting-line compact-row"><strong class="compact-row-label">Local policy rules</strong><span class="compact-value">${rules.requireConfirmation ? "Confirmation" : "No confirmation"}</span><span class="status-badge is-active compact-action">Local</span></div>
      <div class="setting-line compact-row"><strong class="compact-row-label">Compliance profile</strong><span class="compact-value">${t("common.unavailable")}</span><span class="status-badge is-ready compact-action">Target</span></div>
    </div>`;
}

function walletSettingsAdvancedDetail() {
  const source = state.walletSettingsConfigDraft || walletSettingsYaml();
  return `
    <div class="yaml-toolbar"><span><strong class="mono">wallet_settings.yaml</strong></span><div><button class="button" type="button" data-demo-action="wallet-config-validate">Validate</button><button class="button button-primary" type="button" data-demo-action="wallet-config-apply">Apply locally</button></div></div>
    ${yamlEditorMarkup("wallet-settings-yaml", source, "Selected wallet settings YAML")}
    <div class="config-foot"><span>${icon("shield")} No secrets or paths</span><span>${icon("activity")} Selected wallet only</span><span>${icon("settings")} ${escapeHtml(state.configStatus)}</span></div>`;
}

function walletSettingsDetail() {
  if (state.walletSettingsSection === "security") return walletSettingsSecurityDetail();
  if (state.walletSettingsSection === "backup") return walletSettingsBackupDetail();
  if (state.walletSettingsSection === "policies") return walletSettingsPoliciesDetail();
  if (state.walletSettingsSection === "advanced") return walletSettingsAdvancedDetail();
  return walletSettingsGeneralDetail();
}

function walletSettingsView() {
  return `<div class="view-enter settings-view wallet-settings-view"><div class="workspace-layout settings-layout"><aside class="context-rail">${walletSettingsContextNav()}</aside><article class="card settings-detail">${walletSettingsDetail()}</article></div></div>`;
}

function networkDetail() {
  if (state.settingsSection === "reticulum") return `
    <div class="connection-options">
      <div class="connection-option"><span class="health-orb"></span><span><strong>Reticulum service</strong><small>Target service example · no live wallet API</small></span><span class="status-badge is-ready">Target</span></div>
      <div class="connection-option"><span class="list-icon">${icon("network")}</span><span><strong>Interfaces</strong><small>Auto · TCP client + local mesh discovery</small></span><button class="button" type="button" data-demo-action="config-stage">Configure</button></div>
      <div class="connection-option"><span class="list-icon">${icon("shield")}</span><span><strong>Network identity</strong><small class="mono">RNS 6A3E…91B2 · independent from wallet seed</small></span><span class="status-badge is-active">Separate</span></div>
    </div><div class="notice">${icon("settings")} Raw Reticulum interface definitions require a future runtime configuration route. Service/runtime changes may require restart.</div>`;

  if (state.settingsSection === "onionnet") return `
    <div class="connection-options">
      <div class="connection-option"><span class="health-orb"></span><span><strong>Privacy route</strong><small>Target example · 3 hops · epoch 1842</small></span><span class="status-badge is-ready">Target floor</span></div>
      <div class="connection-option"><span class="list-icon">${icon("shield")}</span><span><strong>Membership & replay checks</strong><small>Target telemetry · unavailable in current RPC</small></span><span class="status-badge is-ready">Target</span></div>
      <div class="connection-option"><span class="list-icon">${icon("activity")}</span><span><strong>Route age</strong><small>12 minutes · rebuilt automatically by policy</small></span><button class="button" type="button" data-demo-action="rebuild-route">Rebuild</button></div>
    </div><div class="capability-note">${icon("alert")} <span><strong>Target Phase 080 simulation</strong><small>The current live network RPC is stubbed; all route details on this screen are illustrative until an authoritative status capability exists.</small></span></div><div class="notice">${icon("shield")} This reports concrete route properties. It does not claim that the user is “anonymous” or “untraceable.”</div>`;

  return `
    <div class="network-summary-grid">
      <article><span>Mode</span><strong>Private</strong><small>No direct fallback</small></article>
      <article><span>Privacy overlay</span><strong>OnionNet</strong><small>Verified · 3 hops</small></article>
      <article><span>Active carrier</span><strong>Reticulum</strong><small>Direct underlay</small></article>
      <article><span>Chain & scan</span><strong>Main · current</strong><small>Checked just now</small></article>
    </div>
    <div class="capability-note">${icon("alert")} <span><strong>Target Phase 080 simulation</strong><small>The current network RPC is stubbed. Production must show “capability unavailable” until these properties are authoritative.</small></span></div>`;
}

function settingsDetail() {
  if (state.settingsSection === "general") {
    return `
      <div class="setting-group settings-first-group">
        <div class="setting-line compact-row app-select-setting" data-help-anchor="language"><strong class="compact-row-label">${t("app.language")}</strong><select class="compact-value" aria-label="${t("app.language")}" data-config-control="language">${languageOptionsMarkup()}</select><span class="compact-action"></span></div>
        <div class="setting-line compact-row app-select-setting"><strong class="compact-row-label">${t("app.regionalFormat")}</strong><select class="compact-value" aria-label="${t("app.regionalFormat")}" data-config-control="regional-locale">${regionalLocaleOptionsMarkup()}</select><span class="compact-action"></span></div>
        <div class="setting-line compact-row app-select-setting"><strong class="compact-row-label">${t("app.timeZone")}</strong><select class="compact-value" aria-label="${t("app.timeZone")}" data-config-control="time-zone"><option value="UTC"${state.timeZone === "UTC" ? " selected" : ""}>UTC</option><option value="Asia/Jerusalem"${state.timeZone === "Asia/Jerusalem" ? " selected" : ""}>Asia/Jerusalem</option><option value="Europe/Berlin"${state.timeZone === "Europe/Berlin" ? " selected" : ""}>Europe/Berlin</option><option value="America/New_York"${state.timeZone === "America/New_York" ? " selected" : ""}>America/New_York</option><option value="Asia/Tokyo"${state.timeZone === "Asia/Tokyo" ? " selected" : ""}>Asia/Tokyo</option><option value="Asia/Shanghai"${state.timeZone === "Asia/Shanghai" ? " selected" : ""}>Asia/Shanghai</option></select><span class="compact-action"></span></div>
        <div class="setting-line compact-row"><strong class="compact-row-label">${t("app.notifications")}</strong><span class="compact-value"></span><button class="toggle compact-action" type="button" data-demo-action="general-notifications" aria-pressed="${state.notifications}" aria-label="${t("app.notifications")} ${state.notifications ? t("common.on") : t("common.off")}"></button></div>
      </div>`;
  }

  if (state.settingsSection === "security") {
    return `
      <h2>Security</h2><p>Keep private material out of sight and end sessions automatically.</p>
      <div class="setting-group">
        <div class="setting-line"><span class="setting-line-copy"><strong>Lock app after</strong><small>Automatically lock the wallet after inactivity</small></span><select aria-label="Lock app after" data-config-control="lock-after"><option value="5"${state.autoLockMinutes === "5" ? " selected" : ""}>5 minutes</option><option value="15"${state.autoLockMinutes === "15" ? " selected" : ""}>15 minutes</option><option value="30"${state.autoLockMinutes === "30" ? " selected" : ""}>30 minutes</option><option value="never"${state.autoLockMinutes === "never" ? " selected" : ""}>Never</option></select></div>
        <div class="setting-line"><span class="setting-line-copy"><strong>Lock now</strong><small>End the in-memory wallet session and hide all wallet content</small></span><button class="button" type="button" data-demo-action="lock">${icon("lock")} Lock now</button></div>
        <div class="setting-line"><span class="setting-line-copy"><strong>Hide sensitive amounts</strong><small>Mask balances and transaction values</small></span><button class="toggle" type="button" data-demo-action="toggle-balance" aria-pressed="${state.balanceHidden}" aria-label="Hide sensitive amounts"></button></div>
      </div>
      <div class="setting-group">
        <div class="setting-line"><span class="setting-line-copy"><strong>Recovery phrase</strong><small>Requires password and a private display check</small></span><button class="button" type="button" data-demo-action="seed-warning">View phrase</button></div>
        <div class="setting-line"><span class="setting-line-copy"><strong>Master key</strong><small>Last rotated when wallet was created</small></span><button class="button" type="button" data-demo-action="key-rotation">Rotate</button></div>
      </div>`;
  }

  if (state.settingsSection === "backup") {
    return `
      <h2>Backups</h2><p>Backups are local unless you explicitly choose a configured provider.</p>
      <div class="review-card">
        <div class="summary-row"><span>Latest backup</span><strong>10 Jul 2026 · 09:42</strong></div>
        <div class="summary-row"><span>Integrity</span><strong class="trust-label">${icon("shield")} Verified</strong></div>
        <div class="summary-row"><span>Destination</span><strong>Encrypted local file</strong></div>
      </div>
      <div class="setting-group">
        <div class="setting-line"><span class="setting-line-copy"><strong>Create a fresh backup</strong><small>Choose a destination, authenticate, then verify integrity</small></span><button class="button button-primary" type="button" data-demo-action="backup">${icon("backup")} Create backup</button></div>
        <div class="setting-line"><span class="setting-line-copy"><strong>Restore a backup</strong><small>Validate a backup before replacing wallet state</small></span><button class="button" type="button" data-demo-action="restore">Restore</button></div>
      </div>`;
  }

  if (["reticulum", "onionnet"].includes(state.settingsSection)) {
    const isOnionNet = state.settingsSection === "onionnet";
    return `
      <div class="settings-heading"><div><p class="eyebrow">${isOnionNet ? "Private overlay" : "Local carrier"}</p><h2>${isOnionNet ? "OnionNet" : "Reticulum"}</h2><p>${isOnionNet ? "Route privacy and admission controls remain distinct from the carrier." : "Carrier configuration remains local and separate from wallet keys and route policy."}</p></div>${isOnionNet ? '<select aria-label="Network mode"><option>Private · no direct fallback</option><option>Auto</option><option>Resilient</option><option>Direct · warning</option></select>' : ""}</div>
      ${networkDetail()}`;
  }

  if (state.settingsSection === "policies") {
    return `
      <div class="settings-heading"><div><p class="eyebrow">Target profile preview</p><h2>Safety & policy profiles</h2><p>Profiles can narrow behavior. They cannot change protocol rules or expand your authority.</p></div><button class="button button-primary" type="button" data-demo-action="load-policy">${icon("backup")} Preview profile</button></div>
      <div class="policy-stack" aria-label="Policy precedence">
        <div class="policy-layer is-locked"><span>1</span><div><strong>Protocol rules</strong><small>Native cash conservation · immutable in wallet</small></div><span class="status-badge">Locked</span></div>
        <div class="policy-layer"><span>2</span><div><strong>Organization</strong><small>No managed profile · signed profiles only</small></div><button class="button" type="button" data-demo-action="load-policy">Load</button></div>
        <div class="policy-layer is-active"><span>3</span><div><strong>Personal Safe · v1.4</strong><small>Target example · max payment 2,500 · daily 5,000 · confirmation required</small></div><span class="status-badge is-ready">Preview</span></div>
        <div class="policy-layer"><span>4</span><div><strong>Per-action attenuation</strong><small>May only make the current action narrower</small></div><span class="status-badge">As needed</span></div>
      </div>
      <button class="why-blocked" type="button" data-demo-action="why-blocked">${icon("alert")}<span><strong>Why a 3,200 Z00Z payment would be blocked</strong><small>Target Personal Safe preview → maximum transaction is 2,500 Z00Z</small></span>${icon("chevron")}</button>
      <div class="notice">${icon("shield")} A loaded profile is not proof of legal compliance. Invalid signatures, expired schemas, and ambiguous conflicts fail closed and go to quarantine.</div>`;
  }

  if (state.settingsSection === "appearance") {
    return `
      <div class="setting-group settings-first-group">
        <div class="setting-line compact-row" data-help-anchor="theme"><strong class="compact-row-label">Theme</strong><span class="compact-value"></span><button type="button" class="theme-toggle compact-action" data-theme-toggle aria-label="Switch to ${state.theme === "dark" ? "light" : "dark"} mode" title="Switch to ${state.theme === "dark" ? "light" : "dark"} mode">${icon(state.theme === "dark" ? "moon" : "sun")} ${state.theme === "dark" ? "Dark" : "Light"}</button></div>
        <div class="setting-line palette-setting"><span class="setting-line-copy"><strong>Palette</strong></span><div class="palette-grid" aria-label="Palette presets">${paletteOptions.map(paletteCard).join("")}</div></div>
        <div class="setting-line palette-setting code-theme-setting"><span class="setting-line-copy"><strong>Code highlighting</strong></span><div class="code-theme-sections" aria-label="YAML code highlighting theme"><section><p class="code-theme-group-label">Light</p><div class="code-theme-grid">${codeThemeOptions.filter((theme) => theme.mode === "light").map(codeThemeCard).join("")}</div></section><section><p class="code-theme-group-label">Dark</p><div class="code-theme-grid">${codeThemeOptions.filter((theme) => theme.mode === "dark").map(codeThemeCard).join("")}</div></section></div></div>
        <div class="setting-line compact-row"><strong class="compact-row-label">Text scale</strong><select class="compact-value" aria-label="Text scale" data-config-control="text-scale"><option value="100"${state.textScale === "100" ? " selected" : ""}>100%</option><option value="110"${state.textScale === "110" ? " selected" : ""}>110%</option><option value="125"${state.textScale === "125" ? " selected" : ""}>125%</option></select><span class="compact-action"></span></div>
        <div class="setting-line compact-row"><strong class="compact-row-label">Reduced motion</strong><span class="compact-value"></span><button class="toggle compact-action" type="button" aria-pressed="${state.reducedMotion}" aria-label="Use reduced motion" data-demo-action="motion"></button></div>
      </div>`;
  }

  return advancedConfigContent();
}

function settingsView() {
  return `
    <div class="view-enter settings-view">
      <div class="settings-layout settings-layout--full">
        <article class="card settings-detail">${settingsDetail()}</article>
      </div>
    </div>`;
}

function telemetryValue(label, value, helper) {
  return `<article><span>${label}</span><strong>${value}</strong><small>${helper}</small></article>`;
}

function telemetryLine(iconName, title, detail) {
  return `<div class="connection-option"><span class="list-icon">${icon(iconName)}</span><span><strong>${title}</strong><small>${detail}</small></span><span class="status-badge">${t("common.unavailable")}</span></div>`;
}

const RETICULUM_TAB_ICON_LUT = Object.freeze({
  overview: "overview",
  node: "reticulum-node",
  interfaces: "reticulum-interface",
  radio: "network",
  entrypoints: "entry",
  paths: "reticulum-paths",
  probes: "probe",
  links: "reticulum-link"
});

const reticulumTelemetryTabs = [
  {
    id: "overview",
    labelKey: "reticulum.tabs.overview",
    iconName: RETICULUM_TAB_ICON_LUT.overview,
    metrics: [
      ["Managed-node state", "Unavailable", "No local Reticulum status bridge"],
      ["Interface availability", "Unavailable", "No local interface summary"],
      ["Path and link evidence", "Unavailable", "No managed transport summary"],
      ["Probe coverage", "Unavailable", "No controlled-destination probe results"]
    ]
  },
  {
    id: "node",
    label: "Node",
    labelKey: "reticulum.tabs.node",
    iconName: RETICULUM_TAB_ICON_LUT.node,
    metrics: [
      ["RNS instance", "Unavailable", "No local rnstatus bridge"],
      ["Transport role", "Unavailable", "No managed node snapshot"],
      ["Uptime", "Unavailable", "No local process observation"],
      ["Aggregate RX / TX", "Unavailable", "No local traffic counters"]
    ]
  },
  {
    id: "interfaces",
    label: "Interfaces",
    labelKey: "reticulum.tabs.interfaces",
    iconName: RETICULUM_TAB_ICON_LUT.interfaces,
    metrics: [
      ["Interfaces up / total", "Unavailable", "No local interface snapshot"],
      ["Mode", "Unavailable", "No interface-mode snapshot"],
      ["Nominal bitrate", "Unavailable", "No configured-rate snapshot"],
      ["Current RX / TX", "Unavailable", "No local traffic-rate snapshot"]
    ]
  },
  {
    id: "radio",
    label: "Radio",
    labelKey: "reticulum.tabs.radio",
    iconName: RETICULUM_TAB_ICON_LUT.radio,
    metrics: [
      ["Frequency", "Unavailable", "No RNode interface snapshot"],
      ["Channel configuration", "Unavailable", "No bandwidth / SF / CR metadata"],
      ["RF health", "Unavailable", "No noise / RSSI / SNR observation"],
      ["Airtime / channel load", "Unavailable", "No short or long-window observation"]
    ]
  },
  {
    id: "entrypoints",
    label: "Entry points",
    labelKey: "reticulum.tabs.entrypoints",
    iconName: RETICULUM_TAB_ICON_LUT.entrypoints,
    metrics: [
      ["Discovery state", "Unavailable", "No local discovery snapshot"],
      ["Available entry points", "Unavailable", "No trusted-entrypoint count"],
      ["Last heard", "Unavailable", "No discovery freshness signal"],
      ["Trust scope", "Unavailable", "No managed discovery policy"]
    ]
  },
  {
    id: "paths",
    label: "Paths",
    labelKey: "reticulum.tabs.paths",
    iconName: RETICULUM_TAB_ICON_LUT.paths,
    metrics: [
      ["Known paths", "Unavailable", "No local path-table summary"],
      ["Path freshness", "Unavailable", "No local update observation"],
      ["Path churn", "Unavailable", "No managed change-rate summary"],
      ["Announce pressure", "Unavailable", "No announce-rate or hold-state summary"]
    ]
  },
  {
    id: "probes",
    label: "Probes",
    labelKey: "reticulum.tabs.probes",
    iconName: RETICULUM_TAB_ICON_LUT.probes,
    metrics: [
      ["Probe availability", "Unavailable", "No managed-destination probe results"],
      ["RTT", "Unavailable", "No local latency sample"],
      ["Loss / jitter", "Unavailable", "No probe series"],
      ["Consecutive failures", "Unavailable", "No local failure count"]
    ]
  },
  {
    id: "links",
    label: "Links",
    labelKey: "reticulum.tabs.links",
    iconName: RETICULUM_TAB_ICON_LUT.links,
    metrics: [
      ["Active links", "Unavailable", "No local link summary"],
      ["Receipt delivery", "Unavailable", "No local receipt observation"],
      ["Expected / establish rate", "Unavailable", "No application link-rate summary"],
      ["Measured goodput", "Unavailable", "No controlled resource transfer"]
    ]
  }
];

const aggregatorsTelemetryTabs = [
  {
    id: "overview",
    labelKey: "aggregators.tabs.overview",
    iconName: "overview",
    metrics: [
      ["Service bindings", "Unavailable", "No wallet-to-node status bridge"],
      ["Publication", "Unavailable", "No latest publication record"],
      ["Placement", "Unavailable", "No batch placement observation"],
      ["Verdict", "Unavailable", "No validation or lifecycle evidence"]
    ]
  }
];

const onionnetTelemetryTabs = [
  {
    id: "overview",
    labelKey: "onionnet.tabs.overview",
    iconName: "overview",
    metrics: [
      ["Public epoch data", "Unavailable", "No verified registry or policy snapshot"],
      ["Local route evidence", "Unavailable", "No wallet or SDK status bridge"],
      ["Synthetic health", "Unavailable", "No aggregate probe feed"],
      ["Protected fields", "Hidden", "No paths, endpoints, or session IDs"]
    ]
  },
  {
    id: "epoch",
    labelKey: "onionnet.tabs.epoch",
    iconName: "activity",
    metrics: [
      ["Epoch ID", "Unavailable", "No fresh verified epoch view"],
      ["Independent derivation", "Unavailable", "No observer agreement snapshot"],
      ["Registry / policy freshness", "Unavailable", "No verified roots or snapshot age"],
      ["Lane contract expiry", "Unavailable", "No active contract snapshot"]
    ]
  },
  {
    id: "privacy",
    labelKey: "onionnet.tabs.privacy",
    iconName: "shield",
    metrics: [
      ["Privacy", "Unavailable", "No active profile evaluation"],
      ["Active lanes", "Unavailable", "No lane-contract snapshot"],
      ["Minimum bucket population", "Unavailable", "No bucket aggregate"],
      ["Compliant route floor", "Unavailable", "No policy-bound route count"]
    ]
  },
  {
    id: "transport",
    labelKey: "onionnet.tabs.transport",
    iconName: "network",
    metrics: [
      ["Carrier availability", "Unavailable", "No local carrier snapshot"],
      ["Aggregate RTT / loss", "Unavailable", "No aggregate measurement window"],
      ["Carrier distribution", "Unavailable", "No coarse traffic-class aggregate"],
      ["Geometry compliance", "Unavailable", "No packet-class validation aggregate"]
    ]
  },
  {
    id: "queues",
    labelKey: "onionnet.tabs.queues",
    iconName: "queue",
    metrics: [
      ["Queue utilization", "Unavailable", "No local bounded-queue aggregate"],
      ["Replay ledger", "Unavailable", "No durable replay snapshot"],
      ["Backpressure actions", "Unavailable", "No aggregated reason counts"],
      ["Forwarding invariant", "Unavailable", "No verified replay-before-forward proof"]
    ]
  },
  {
    id: "probation",
    labelKey: "onionnet.tabs.probation",
    iconName: "probe",
    metrics: [
      ["Probation population", "Unavailable", "No lifecycle aggregate"],
      ["Shadow-probe coverage", "Unavailable", "No aggregate probe results"],
      ["Reserve activation", "Unavailable", "No activation-time observation"],
      ["Challenge outcomes", "Unavailable", "No bounded outcome summary"]
    ]
  },
  {
    id: "ingress",
    labelKey: "onionnet.tabs.ingress",
    iconName: "entry",
    metrics: [
      ["Exit boundary", "Unavailable", "No opaque-handoff aggregate"],
      ["Inner decrypt", "Unavailable", "No result-count aggregate"],
      ["Recipient-key lifecycle", "Unavailable", "No key-age or rotation snapshot"],
      ["Runtime admission", "Unavailable", "No WorkItem admission aggregate"]
    ]
  }
];

function telemetryTabbedView({ source, tabs, selectedTabId, titleKey, localCapabilityKey }) {
  const activeTab = tabs.find((tab) => tab.id === selectedTabId) || tabs[0];
  const tabLabel = t(activeTab.labelKey);
  return `<section class="view-enter telemetry-view ${source}-telemetry-view" aria-labelledby="telemetry-heading">
    <h2 class="sr-only" id="telemetry-heading">${t(titleKey)}</h2>
    <div class="capability-note capability-note-compact">${icon("alert")}<span><strong>${t(localCapabilityKey)}</strong></span><span class="status-badge">${t("common.readOnly")}</span></div>
    <section id="${source}-panel-${activeTab.id}" class="telemetry-tab-detail" role="tabpanel" aria-label="${tabLabel}" aria-labelledby="${source}-tab-${activeTab.id}">
      <div class="telemetry-tab-heading"><div><h3>${tabLabel}</h3></div><span class="status-badge">${t("common.unavailable")}</span></div>
      <section class="network-summary-grid telemetry-summary" aria-label="${tabLabel} parameters">${activeTab.metrics.map(([label, value, helper]) => telemetryValue(label, value, helper)).join("")}</section>
    </section>
  </section>`;
}

function reticulumTelemetryView() {
  return telemetryTabbedView({
    source: "reticulum",
    tabs: reticulumTelemetryTabs,
    selectedTabId: state.reticulumTelemetryTab,
    titleKey: "reticulum.title",
    localCapabilityKey: "reticulum.localCapability"
  });
}

function onionnetTelemetryView() {
  return telemetryTabbedView({
    source: "onionnet",
    tabs: onionnetTelemetryTabs,
    selectedTabId: state.onionnetTelemetryTab,
    titleKey: "onionnet.title",
    localCapabilityKey: "onionnet.localCapability"
  });
}

function aggregatorsTelemetryView() {
  return telemetryTabbedView({
    source: "aggregators",
    tabs: aggregatorsTelemetryTabs,
    selectedTabId: state.aggregatorsTelemetryTab,
    titleKey: "aggregators.title",
    localCapabilityKey: "aggregators.localCapability"
  });
}

function telemetryView() {
  const source = state.telemetrySource;
  if (source === "reticulum") return reticulumTelemetryView();
  if (source === "onionnet") return onionnetTelemetryView();
  return aggregatorsTelemetryView();
}

function render(options = {}) {
  closeMobilePopup();
  applyAppearancePreferences();
  renderWalletShell();
  const mobileMenuLabel = t("app.menu");
  mobileMenuButton.setAttribute("aria-label", mobileMenuLabel);
  mobileMenuButton.setAttribute("title", mobileMenuLabel);
  const sidebarTarget = sidebarActiveTarget();
  const walletScreen = hasSelectedWalletContext();
  const wallet = activeWallet();
  const [title, context] = headings[state.view];
  const [telemetryTitle, telemetryContext] = telemetryTopbar[state.telemetrySource] || telemetryTopbar.onionnet;
  const telemetryScreen = state.view === "telemetry";
  const settingsScreen = state.view === "settings";
  pageTitle.textContent = walletScreen ? wallet.address : telemetryScreen ? telemetryTitle : t(title);
  pageContext.textContent = walletScreen
    ? t("app.walletContext", { wallet: wallet.name })
    : telemetryScreen
      ? t(telemetryContext)
      : t(context);
  pageTitle.classList.toggle("is-wallet-address", walletScreen);
  pageTitle.classList.toggle("is-telemetry-title", telemetryScreen);
  pageTitle.classList.toggle("is-settings-title", settingsScreen);
  topbarAddressGroup.classList.toggle("has-wallet-address", walletScreen);
  copyWalletAddress.hidden = !walletScreen;
  walletIdentity.hidden = !walletScreen;

  document.querySelectorAll("[data-view]").forEach((button) => {
    const active = button.closest(".system-nav")
      ? sidebarTarget.group === "settings"
      : button.dataset.view === state.view;
    button.classList.toggle("is-active", active);
    if (button.closest("nav")) {
      active ? button.setAttribute("aria-current", "page") : button.removeAttribute("aria-current");
    }
  });
  main.innerHTML = {
    home: homeView,
    wallet: walletView,
    "wallet-send": walletSendView,
    "wallet-receive": walletReceiveView,
    activity: activityView,
    swap: swapView,
    exchange: exchangeView,
    staking: stakingView,
    "wallet-backup": walletBackupView,
    "wallet-settings": walletSettingsView,
    settings: settingsView,
    telemetry: telemetryView
  }[state.view]();
  help.configure({ language: state.language, theme: state.theme, palette: state.palette });
  help.mountContextButton(state, main.firstElementChild);
  suppressPasswordManagerUI(document);

  syncBalanceButtons();
  const revealActiveWalletTab = () => {
    const activeWalletTab = walletTabs.querySelector(".wallet-tab.is-active");
    if (!activeWalletTab) return;

    const activeBounds = activeWalletTab.getBoundingClientRect();
    const tabsBounds = walletTabs.getBoundingClientRect();
    const tabInset = window.matchMedia("(max-width: 760px)").matches ? 16 : 0;
    if (activeBounds.right > tabsBounds.right - tabInset) {
      walletTabs.scrollLeft += activeBounds.right - (tabsBounds.right - tabInset);
    } else if (activeBounds.left < tabsBounds.left + tabInset) {
      walletTabs.scrollLeft -= tabsBounds.left + tabInset - activeBounds.left;
    }
  };
  revealActiveWalletTab();
  document.fonts?.ready.then(revealActiveWalletTab);
  requestAnimationFrame(() => {
    revealActiveWalletTab();
    const activeContext = main.querySelector(".context-nav-child.is-active") || main.querySelector(".context-nav-item.is-active");
    activeContext?.scrollIntoView({ block: "nearest", inline: "center" });
  });
  if (options.focusMain) {
    main.focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: state.reducedMotion || window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
  }
}

function syncBalanceButtons() {
  document.querySelectorAll('[data-demo-action="toggle-balance"]').forEach((button) => {
    const label = state.balanceHidden ? "Show sensitive amounts" : "Hide sensitive amounts";
    button.setAttribute("aria-label", label);
    button.setAttribute("title", label);
    if (button.classList.contains("toggle")) button.setAttribute("aria-pressed", String(state.balanceHidden));
    const use = button.querySelector("use");
    if (use) use.setAttribute("href", state.balanceHidden ? "#i-eye-off" : "#i-eye");
  });
}

function validateAndApplyWalletSettingsYaml(source, apply = false) {
  const forbidden = /(^|\n)\s*(password|seed|private_key|session_token|receiver_secret|path):/i;
  if (!/^schema_version:\s*1\s*$/m.test(source) || !/^wallet:\s*$/m.test(source)) return { valid: false, message: "Use schema_version: 1 and a wallet section." };
  if (forbidden.test(source)) return { valid: false, message: "Secrets and local paths are not allowed in wallet settings YAML." };

  const name = readYamlScalar(source, "name");
  const currency = readYamlScalar(source, "currency");
  const defaultFee = readYamlScalar(source, "default_fee");
  const lockAfter = readYamlScalar(source, "lock_after_minutes");
  const backupInterval = readYamlScalar(source, "interval_hours");
  const maxTransaction = readYamlScalar(source, "max_transaction");
  const maxDaily = readYamlScalar(source, "max_daily");
  const requireConfirmation = readYamlScalar(source, "require_confirmation");
  const allowedAssets = readYamlScalar(source, "allowed_assets");
  const allowedRecipients = readYamlScalar(source, "allowed_recipients");
  const timeRestrictions = readYamlScalar(source, "time_restrictions");
  const chainId = readYamlScalar(source, "chain");

  if (name && (name.length < 2 || name.length > 32)) return { valid: false, message: "Wallet name must contain 2–32 characters." };
  if (currency && !["Z00Z", "USD", "EUR"].includes(currency)) return { valid: false, message: "currency must be Z00Z, USD, or EUR." };
  if (defaultFee && !/^\d+(?:\.\d+)?$/.test(defaultFee)) return { valid: false, message: "default_fee must be a non-negative decimal." };
  if (lockAfter && !["5", "15", "30", "never"].includes(lockAfter.toLowerCase())) return { valid: false, message: "lock_after_minutes must be 5, 15, 30, or never." };
  if (backupInterval && !["6", "24", "72"].includes(backupInterval)) return { valid: false, message: "interval_hours must be 6, 24, or 72." };
  if (maxTransaction && !/^\d+(?:\.\d+)?$/.test(maxTransaction)) return { valid: false, message: "max_transaction must be a non-negative decimal." };
  if (maxDaily && !/^\d+(?:\.\d+)?$/.test(maxDaily)) return { valid: false, message: "max_daily must be a non-negative decimal." };
  if (requireConfirmation && !["true", "false"].includes(requireConfirmation)) return { valid: false, message: "require_confirmation must be true or false." };
  if (allowedAssets && !["all", "native"].includes(allowedAssets)) return { valid: false, message: "allowed_assets must be all or native." };
  if (timeRestrictions && !["any", "business-hours"].includes(timeRestrictions)) return { valid: false, message: "time_restrictions must be any or business-hours." };
  if (chainId !== activeWallet().chainId) return { valid: false, message: `chain is read-only and must remain ${activeWallet().chainId}.` };

  if (apply) {
    const wallet = activeWallet();
    const preferences = activeWalletPreferences();
    if (name) {
      wallet.name = name;
      wallet.initials = name.slice(0, 1).toUpperCase();
    }
    if (currency) preferences.currency = currency;
    if (defaultFee) preferences.defaultFee = defaultFee;
    if (lockAfter) preferences.lockAfterMinutes = lockAfter.toLowerCase();
    if (backupInterval) preferences.backupIntervalHours = backupInterval;
    if (maxTransaction) preferences.policyRules.maxTransaction = maxTransaction;
    if (maxDaily) preferences.policyRules.maxDaily = maxDaily;
    if (requireConfirmation) preferences.policyRules.requireConfirmation = requireConfirmation === "true";
    if (allowedAssets) preferences.policyRules.allowedAssets = allowedAssets;
    if (allowedRecipients) preferences.policyRules.allowedRecipients = allowedRecipients === "any" ? "" : allowedRecipients;
    if (timeRestrictions) preferences.policyRules.timeWindow = timeRestrictions;
    state.walletSettingsConfigDraft = "";
    syncConfigDraftFromState();
  }
  return { valid: true, message: apply ? "Selected wallet settings applied locally in this concept." : "Selected wallet YAML is valid for the concept schema." };
}

function sensitiveWalletDialog(type) {
  const wallet = activeWallet();
  const preferences = activeWalletPreferences();
  if (type === "wallet-password-change") return walletPasswordChangeDialog();
  if (type === "wallet-policy-profile") {
    return dialogFrame({
      title: "Compliance profile preview",
      subtitle: "User-configured policy, not a certificate",
      body: `<div class="confirmation-note">${icon("alert")} A profile can guide local restrictions and scoped disclosure choices. It cannot prove legal status, override protocol rules, or expand authority.</div><div class="review-card"><div class="summary-row"><span>Profile</span><strong>${escapeHtml(preferences.policyProfile)}</strong></div><div class="summary-row"><span>Scope</span><strong>${escapeHtml(wallet.name)} only</strong></div><div class="summary-row"><span>Signature / apply route</span><strong>Unavailable in current RPC</strong></div></div><div class="policy-stack"><div class="policy-layer is-locked"><span>1</span><div><strong>Protocol rules</strong><small>Always enforced and not editable.</small></div><span class="status-badge">Locked</span></div><div class="policy-layer"><span>2</span><div><strong>Jurisdiction profile</strong><small>Target preview; no managed claim or legal certification.</small></div><span class="status-badge is-ready">Target</span></div><div class="policy-layer is-active"><span>3</span><div><strong>Local <code>PolicyRules</code></strong><small>Spend limits and confirmation preferences can narrow this wallet.</small></div><span class="status-badge is-active">Local</span></div></div>`,
      footer: `<button class="button button-primary" type="button" data-dialog-close>Close</button>`
    });
  }

  const definitions = {
    "wallet-rename": {
      title: "Rename wallet",
      subtitle: "Confirm with the wallet password",
      confirmation: null,
      body: `<div class="field-group"><label class="field-label" for="wallet-rename-name">Wallet name</label><input id="wallet-rename-name" name="walletLabel" maxlength="32" value="${escapeHtml(wallet.name)}" autocomplete="section-z00z-wallet nickname" ${passwordManagerIgnoreAttributes} required><p class="field-hint">This local label does not change the wallet address or key material.</p></div>`,
      actionLabel: "Save wallet name"
    },
    "wallet-seed-reveal": {
      title: "View recovery phrase",
      subtitle: "Private display only · critical operation",
      confirmation: "SHOW SEED",
      body: `<div class="confirmation-note">${icon("alert")} Never share recovery words with support, a website, or a remote-access session. Close the dialog to clear them from this renderer.</div>`,
      actionLabel: "Reveal demonstration phrase"
    },
    "wallet-public-export": {
      title: "Prepare public-material export",
      subtitle: "Encrypted export after password check",
      confirmation: null,
      body: `<div class="notice">${icon("shield")} The wallet route exports encrypted public material. It does not expose a private key in the interface.</div>`,
      actionLabel: "Prepare encrypted export"
    },
    "wallet-key-rotation": {
      title: "Rotate master key",
      subtitle: "Rewrap protected wallet records",
      confirmation: "ROTATE",
      body: `<div class="confirmation-note">${icon("alert")} This critical operation re-encrypts protected local records. Keep a verified backup before continuing. The wallet service rate-limits successful rotation.</div>`,
      actionLabel: "Rotate master key"
    },
    "wallet-policy-apply": {
      title: "Review local spend rules",
      subtitle: "Narrow this wallet's behavior",
      confirmation: "APPLY",
      body: `<div class="form-grid policy-rule-form"><div class="field-group"><label class="field-label" for="wallet-policy-max-tx">Maximum transaction</label><div class="input-with-affix"><input id="wallet-policy-max-tx" name="maxTransaction" inputmode="decimal" value="${escapeHtml(preferences.policyRules.maxTransaction)}" required><span class="input-affix">Z00Z</span></div></div><div class="field-group"><label class="field-label" for="wallet-policy-max-daily">Maximum daily total</label><div class="input-with-affix"><input id="wallet-policy-max-daily" name="maxDaily" inputmode="decimal" value="${escapeHtml(preferences.policyRules.maxDaily)}" required><span class="input-affix">Z00Z</span></div></div><div class="field-group"><label class="field-label" for="wallet-policy-assets">Allowed assets</label><select id="wallet-policy-assets" name="allowedAssets"><option value="all"${preferences.policyRules.allowedAssets === "all" ? " selected" : ""}>All supported assets</option><option value="native"${preferences.policyRules.allowedAssets === "native" ? " selected" : ""}>Native Z00Z only</option></select></div><div class="field-group"><label class="field-label" for="wallet-policy-time">Time restrictions</label><select id="wallet-policy-time" name="timeWindow"><option value="any"${preferences.policyRules.timeWindow === "any" ? " selected" : ""}>Any time</option><option value="business-hours"${preferences.policyRules.timeWindow === "business-hours" ? " selected" : ""}>Business hours UTC</option></select></div><div class="field-group policy-rule-recipient"><label class="field-label" for="wallet-policy-recipient">Allowed recipients <span class="muted">(optional)</span></label><input id="wallet-policy-recipient" name="allowedRecipients" maxlength="160" value="${escapeHtml(preferences.policyRules.allowedRecipients)}" placeholder="Leave blank to allow all recipients"><p class="field-hint">A target integration must parse and validate each receiver identifier before save.</p></div><label class="checkbox-line"><input name="requireConfirmation" type="checkbox"${preferences.policyRules.requireConfirmation ? " checked" : ""}> <span><strong>Require settlement confirmation</strong><small>Block another local spend while a prior one awaits settlement.</small></span></label></div><div class="notice">${icon("shield")} Rules remain local to this concept. Signed profile application is a target capability, not part of this action.</div>`,
      actionLabel: "Apply local rules"
    }
  };
  const definition = definitions[type];
  if (state.flow.step === 1) {
    const result = type === "wallet-seed-reveal"
      ? `<div class="confirmation-note">${icon("alert")} Demonstration words only. Never copy recovery words to a shared clipboard.</div><ol class="seed-grid" aria-label="Demonstration recovery phrase">${demoSeedWords.map((word, index) => `<li><span>${index + 1}</span><strong>${word}</strong></li>`).join("")}</ol><p class="seed-demo-label">DEMONSTRATION WORDS · NOT A REAL WALLET SEED</p>`
      : type === "wallet-public-export"
        ? `<div class="result-state"><span class="result-icon">${icon("check")}</span><h3>Encrypted export prepared</h3><p>Only encrypted public material is represented. It is not placed on the clipboard.</p></div><code class="request-code">z00z-public-export:encrypted:${escapeHtml(wallet.id)}:account-0</code>`
        : type === "wallet-key-rotation"
          ? `<div class="result-state"><span class="result-icon">${icon("check")}</span><h3>Master key rotated</h3><p>Protected local records were rewrapped in this concept. A production UI would show the returned fingerprint and record count.</p></div>`
          : type === "wallet-policy-apply"
            ? `<div class="result-state"><span class="result-icon">${icon("check")}</span><h3>Local spend rules updated</h3><p>They narrow ${escapeHtml(wallet.name)} only and never claim regulatory compliance.</p></div>`
            : `<div class="result-state"><span class="result-icon">${icon("check")}</span><h3>Wallet name updated</h3><p>${escapeHtml(wallet.name)} remains the same local wallet with the same address and keys.</p></div>`;
    return dialogFrame({ title: definition.title, subtitle: "Local concept result", body: result, footer: `<button class="button button-primary" type="button" data-dialog-close>Done</button>` });
  }
  const passwordId = `${type}-password`;
  const confirmationMarkup = definition.confirmation ? `<div class="field-group"><label class="field-label" for="${type}-confirmation">Type ${definition.confirmation}</label><input id="${type}-confirmation" name="confirmation" autocomplete="off" autocapitalize="characters" spellcheck="false" required><p class="field-hint">This exact phrase prevents accidental execution.</p></div>` : "";
  return dialogFrame({
    title: definition.title,
    subtitle: definition.subtitle,
    body: `<form class="form-grid" id="${type}-entry" autocomplete="off" ${passwordManagerIgnoreAttributes} novalidate>${definition.body}<div class="field-group"><label class="field-label" for="${passwordId}">Wallet password</label><input id="${passwordId}" name="walletSecret" ${secureEntryAttributes("wallet-action")} minlength="8" required><p class="field-hint">This concept validates locally and clears the value immediately after use.</p><p class="field-error" id="${type}-error" role="alert"></p></div>${confirmationMarkup}</form>`,
    footer: `<button class="button button-quiet" type="button" data-dialog-close>Cancel</button><button class="button button-primary" type="submit" form="${type}-entry">${definition.actionLabel}</button>`
  });
}

function walletPasswordChangeDialog() {
  if (state.flow.step === 1) {
    return dialogFrame({
      title: t("walletSettings.passwordChangedTitle"),
      subtitle: "Local concept result",
      body: `<div class="result-state"><span class="result-icon">${icon("check")}</span><h3>${t("walletSettings.passwordChangedTitle")}</h3><p>${t("walletSettings.passwordChangedResult")}</p></div>`,
      footer: `<button class="button button-primary" type="button" data-dialog-close>Done</button>`
    });
  }

  return dialogFrame({
    title: t("walletSettings.changePasswordTitle"),
    subtitle: t("walletSettings.changePasswordSubtitle"),
    body: `<form class="form-grid" id="wallet-password-change-entry" autocomplete="off" ${passwordManagerIgnoreAttributes} novalidate>
      <div class="field-group"><label class="field-label" for="wallet-current-password">${t("walletSettings.currentPassword")}</label><input id="wallet-current-password" name="currentWalletSecret" ${secureEntryAttributes("current-wallet-secret")} minlength="8" required></div>
      <div class="field-group"><label class="field-label" for="wallet-new-password">${t("walletSettings.newPassword")}</label><input id="wallet-new-password" name="newWalletSecret" ${secureEntryAttributes("new-wallet-secret")} minlength="8" required><p class="field-hint">${t("walletSettings.passwordChangeHint")}</p></div>
      <div class="field-group"><label class="field-label" for="wallet-confirm-new-password">${t("walletSettings.confirmNewPassword")}</label><input id="wallet-confirm-new-password" name="confirmNewWalletSecret" ${secureEntryAttributes("new-wallet-secret-confirmation")} minlength="8" required></div>
      <p class="field-error" id="wallet-password-change-error" role="alert"></p>
    </form>`,
    footer: `<button class="button button-quiet" type="button" data-dialog-close>Cancel</button><button class="button button-primary" type="submit" form="wallet-password-change-entry">${t("walletSettings.changePasswordSubmit")}</button>`
  });
}

function dialogFrame({ title, subtitle, body, footer = "", steps = 0, activeStep = 0, closeLabel, headerLeading = "", helpTopic = "" }) {
  const resolvedCloseLabel = closeLabel || t("common.close");
  const indicators = steps > 1
    ? `<div class="step-indicator" aria-label="Step ${activeStep + 1} of ${steps}">${Array.from({ length: steps }, (_, index) => `<span class="${index < activeStep ? "is-done" : index === activeStep ? "is-active" : ""}"></span>`).join("")}</div>`
    : "";
  return `
    <div class="dialog-shell">
      <header class="dialog-header${headerLeading ? " has-leading-visual" : ""}">
        ${headerLeading}
        <div class="dialog-header-copy"><h2 id="dialog-title">${title}</h2><p>${subtitle}</p></div>
        ${indicators}
        ${helpTopic ? `<button class="icon-button dialog-help-button" type="button" data-help-topic="${escapeHtml(helpTopic)}" aria-label="${escapeHtml(t("help.openContext"))}" title="${escapeHtml(t("help.title"))}">${icon("question")}</button>` : ""}
        <button class="icon-button" type="button" data-dialog-close aria-label="${escapeHtml(resolvedCloseLabel)}">${icon("close")}</button>
      </header>
      <div class="dialog-body">${body}</div>
      ${footer ? `<footer class="dialog-footer">${footer}</footer>` : ""}
    </div>`;
}

function assetClaimDialog() {
  if (state.flow.step === 0) {
    return dialogFrame({
      title: "Claim asset allocation",
      subtitle: "One source, one recipient, one replay-safe claim",
      steps: 2,
      activeStep: 0,
      body: `
        <div class="review-card review-hero"><span class="list-icon is-claim">${icon("claim")}</span><strong>86.00 Z00Z</strong><span>Genesis allocation #014</span></div>
        <div class="review-card"><div class="summary-row"><span>Claim source</span><strong>Allocation root · proof present</strong></div><div class="summary-row"><span>Authority</span><strong>Signature present</strong></div><div class="summary-row"><span>Recipient</span><strong>Everyday wallet · bound</strong></div><div class="summary-row"><span>Output</span><strong>Z00Z Coin · 86.00</strong></div><div class="summary-row"><span>Replay protection</span><strong>Chain-bound nullifier</strong></div></div>
        <div class="confirmation-note">${icon("shield")} The claim package is separate from vouchers. A successful claim creates owned Asset output and can be used only once.</div>
        <div class="capability-note">${icon("alert")} <span><strong>Target claim intake</strong><small>Live code verifies ClaimTxPackage, but the current wallet RPC has no dedicated high-level claim intake/build method. Production keeps this action capability-gated.</small></span></div>`,
      footer: `<button class="button button-quiet" type="button" data-dialog-close>Cancel</button><button class="button button-primary" type="button" data-dialog-action="asset-claim-submit">Verify and claim once</button>`
    });
  }

  return dialogFrame({
    title: "Claim submitted",
    subtitle: "Waiting for final settlement",
    steps: 2,
    activeStep: 1,
    body: `<div class="result-state"><span class="result-icon is-settling">${icon("activity")}</span><h3>Asset receiving · settling</h3><p>The verified claim output is tracked as an Asset. It is not included in Available until authoritative settlement makes it spendable.</p><div class="receipt-ref mono">Claim CLM-883C · nullifier reserved once</div></div>`,
    footer: `<button class="button" type="button" data-dialog-action="view-activity">View history</button><button class="button button-primary" type="button" data-dialog-close>Done</button>`
  });
}

function voucherDialog(settled = false) {
  if (settled) {
    return dialogFrame({
      title: "Event deposit return",
      subtitle: "Voucher history",
      body: `<div class="result-state"><span class="result-icon">${icon("check")}</span><h3>Redeemed · settled</h3><p>The voucher was redeemed and its resulting asset settled on 12 Jul 2026.</p></div><div class="review-card"><div class="summary-row"><span>Issuer</span><strong>Riverside Events</strong></div><div class="summary-row"><span>Face / remaining</span><strong>150.00 / 0.00 Z00Z</strong></div><div class="summary-row"><span>Lifecycle</span><strong>Redeemed</strong></div></div><details class="technical"><summary>Technical details</summary><div class="technical-content mono"><span>Object: voucher_04e9…af31</span><span>Lifecycle: offered → accepted → redeemed</span></div></details>`,
      footer: `<button class="button button-primary" type="button" data-dialog-close>Done</button>`
    });
  }

  if (state.flow.step === 0) {
    return dialogFrame({
      title: "Review voucher",
      subtitle: "Conditional value offered to this wallet",
      steps: 3,
      activeStep: 0,
      body: `<div class="review-card review-hero"><span class="list-icon is-voucher">${objectFamilyIcon("voucher")}</span><strong>86.00 Z00Z</strong><span>Travel refund voucher</span></div><div class="review-card"><div class="summary-row"><span>Issuer</span><strong>Northwind Travel</strong></div><div class="summary-row"><span>Backing</span><strong>Consumed asset reference</strong></div><div class="summary-row"><span>Face / remaining</span><strong>86.00 / 86.00 Z00Z</strong></div><div class="summary-row"><span>Acceptance</span><strong>Required</strong></div><div class="summary-row"><span>Ends</span><strong>21 Jul 2026 · 18:00</strong></div><div class="summary-row"><span>Holder options</span><strong>Accept · Reject</strong></div></div><div class="confirmation-note">${icon("shield")} Accepting changes the voucher lifecycle. It does not directly add 86.00 Z00Z to Available.</div>`,
      footer: `<button class="button button-danger" type="button" data-dialog-action="voucher-reject">Reject voucher</button><button class="button button-primary" type="button" data-dialog-action="voucher-accept">Accept voucher</button>`
    });
  }

  if (state.flow.step === 1) {
    return dialogFrame({
      title: "Voucher accepted",
      subtitle: "Now redeemable",
      steps: 3,
      activeStep: 1,
      body: `<div class="result-state"><span class="result-icon">${icon("check")}</span><h3>Accepted · redeemable</h3><p>The voucher remains conditional value. Redeem it to request its asset outcome.</p></div><div class="review-card"><div class="summary-row"><span>Remaining value</span><strong>86.00 Z00Z</strong></div><div class="summary-row"><span>Next action</span><strong>Redeem full voucher</strong></div></div>`,
      footer: `<button class="button" type="button" data-dialog-close>Later</button><button class="button button-primary" type="button" data-dialog-action="voucher-redeem">Redeem voucher</button>`
    });
  }

  return dialogFrame({
    title: "Voucher redeemed",
    subtitle: "Asset outcome is settling",
    steps: 3,
    activeStep: 2,
    body: `<div class="result-state"><span class="result-icon is-settling">${icon("activity")}</span><h3>Redeemed · receiving</h3><p>The voucher lifecycle is redeemed. Its asset outcome is waiting for authoritative settlement and is not Available yet.</p></div>`,
    footer: `<button class="button" type="button" data-dialog-action="view-activity">View history</button><button class="button button-primary" type="button" data-dialog-close>Done</button>`
  });
}

function createVoucherDialog() {
  return dialogFrame({
    title: "Create voucher",
    subtitle: "Create conditional value in this wallet",
    body: `
      <form class="form-grid" id="create-voucher-entry" novalidate>
        <div class="field-group"><label class="field-label" for="voucher-create-name">Voucher name</label><input id="voucher-create-name" name="title" maxlength="48" value="Gift voucher" autocomplete="off" required aria-describedby="voucher-create-error"><p class="field-error" id="voucher-create-error" role="alert"></p></div>
        <div class="field-group"><label class="field-label" for="voucher-create-amount">Value</label><div class="input-with-affix"><input id="voucher-create-amount" name="amount" type="number" min="0.01" step="0.01" value="10.00" inputmode="decimal" required><span class="input-affix">Z00Z</span></div></div>
        <div class="field-group"><label class="field-label" for="voucher-create-expiry">Expires</label><input id="voucher-create-expiry" name="expiry" type="date" value="2026-12-31" min="2026-07-22" required></div>
        <div class="confirmation-note">${icon("shield")} The voucher remains a distinct wallet object. Its value is not added to Available.</div>
      </form>`,
    footer: `<button class="button button-quiet" type="button" data-dialog-close>Cancel</button><button class="button button-primary" type="submit" form="create-voucher-entry">Create voucher</button>`
  });
}

function voucherDetailDialog() {
  const voucher = walletObjectEntry("voucher", state.flow.data.objectId);
  if (!voucher) return dialogFrame({ title: "Voucher unavailable", subtitle: "The wallet state changed", body: `<div class="empty-state"><p>This voucher is no longer available.</p></div>`, footer: `<button class="button button-primary" type="button" data-dialog-close>Done</button>` });
  return dialogFrame({
    title: voucher.title,
    subtitle: "Wallet voucher",
    body: `<div class="review-card review-hero"><span class="list-icon is-voucher">${objectFamilyIcon("voucher")}</span><strong>${escapeHtml(voucher.value)}</strong><span>${escapeHtml(voucher.status)}</span></div><div class="review-card"><div class="summary-row"><span>Expires</span><strong>${escapeHtml(voucher.expiry)}</strong></div><div class="summary-row"><span>Transfer</span><strong>${voucher.transferable ? "Ready" : escapeHtml(voucher.status)}</strong></div><div class="summary-row"><span>Wallet</span><strong>${escapeHtml(activeWallet().name)}</strong></div></div>`,
    footer: `<button class="button button-primary" type="button" data-dialog-close>Done</button>`
  });
}

function createPermissionDialog() {
  return dialogFrame({
    title: "Create permission",
    subtitle: "Define bounded authority held by this wallet",
    body: `
      <form class="form-grid" id="create-permission-entry" novalidate>
        <div class="field-group"><label class="field-label" for="permission-create-name">Permission name</label><input id="permission-create-name" name="title" maxlength="48" value="Service access" autocomplete="off" required aria-describedby="permission-create-error"><p class="field-error" id="permission-create-error" role="alert"></p></div>
        <div class="field-group"><label class="field-label" for="permission-create-action">Allowed action</label><select id="permission-create-action" name="action"><option>View status</option><option>Deploy release</option><option>Read receipt</option></select></div>
        <div class="field-group"><label class="field-label" for="permission-create-scope">Scope</label><input id="permission-create-scope" name="scope" value="service.example" autocomplete="off" required></div>
        <div class="field-group"><label class="field-label" for="permission-create-uses">Maximum uses</label><input id="permission-create-uses" name="uses" type="number" min="1" max="100" value="1" inputmode="numeric" required></div>
        <div class="field-group"><label class="field-label" for="permission-create-expiry">Expires</label><input id="permission-create-expiry" name="expiry" type="date" value="2026-12-31" min="2026-07-22" required></div>
        <div class="confirmation-note">${icon("shield")} A permission carries bounded authority and no monetary value.</div>
      </form>`,
    footer: `<button class="button button-quiet" type="button" data-dialog-close>Cancel</button><button class="button button-primary" type="submit" form="create-permission-entry">Create permission</button>`
  });
}

function permissionDialog() {
  const data = state.flow.data;
  if (state.flow.step === 0) {
    return dialogFrame({
      title: "Give permission",
      subtitle: "Delegate a narrower right you already hold",
      steps: 3,
      activeStep: 0,
      body: `
        <form class="form-grid" id="permission-entry" novalidate>
          <div class="field-group"><label class="field-label" for="permission-source">Held authority</label><select id="permission-source" name="source"><option>Deploy to staging · machine capability</option></select><p class="field-hint">Only held, delegable authority is offered. Right creation is a separate issuer capability.</p></div>
          <div class="field-group"><label class="field-label" for="permission-delegate">Delegate</label><input id="permission-delegate" name="delegate" value="${escapeHtml(data.delegate)}" placeholder="Verified service or known identity" required aria-describedby="permission-delegate-error"><p class="field-error" id="permission-delegate-error"></p></div>
          <div class="field-group"><label class="field-label" for="permission-action">Allowed action</label><select id="permission-action" name="action"><option>Deploy release</option><option>View status</option></select></div>
          <div class="field-group"><label class="field-label" for="permission-scope">Scope</label><input id="permission-scope" name="scope" value="${escapeHtml(data.scope)}" readonly></div>
          <div class="field-group"><label class="field-label" for="permission-uses">Maximum uses</label><input id="permission-uses" name="uses" type="number" min="1" max="5" inputmode="numeric" value="${escapeHtml(data.uses)}" required aria-describedby="permission-uses-error"><p class="field-error" id="permission-uses-error"></p></div>
          <div class="field-group"><label class="field-label" for="permission-expiry">Ends</label><input id="permission-expiry" name="expiry" type="date" value="${escapeHtml(data.expiry)}" min="2026-07-20" required></div>
        </form>`,
      footer: `<button class="button button-quiet" type="button" data-dialog-close>Cancel</button><button class="button button-primary" type="submit" form="permission-entry">Review permission ${icon("chevron")}</button>`
    });
  }

  if (state.flow.step === 1) {
    return dialogFrame({
      title: "Review permission",
      subtitle: "The delegated right can only become narrower",
      steps: 3,
      activeStep: 1,
      body: `
        <div class="review-card review-hero"><span class="list-icon is-right">${objectFamilyIcon("right")}</span><strong>${escapeHtml(data.uses)} uses</strong><span>for ${escapeHtml(data.delegate)}</span></div>
        <div class="review-card"><div class="summary-row"><span>Class</span><strong>Machine capability</strong></div><div class="summary-row"><span>Can</span><strong>${escapeHtml(data.action)}</strong></div><div class="summary-row"><span>Only within</span><strong>${escapeHtml(data.scope)}</strong></div><div class="summary-row"><span>Use limit</span><strong>${escapeHtml(data.uses)}</strong></div><div class="summary-row"><span>Ends</span><strong>${escapeHtml(data.expiryLabel)}</strong></div><div class="summary-row"><span>Cannot</span><strong>Sub-delegate or broaden scope</strong></div><div class="summary-row"><span>Monetary value</span><strong>None · Right is zero-value</strong></div></div>
        <div class="confirmation-note">${icon("alert")} Delegation transfers bounded authority. Revocation cannot be described as cancelling work already accepted by the protocol.</div>`,
      footer: `<button class="button" type="button" data-dialog-action="permission-back">Back</button><button class="button button-primary" type="button" data-dialog-action="permission-submit">Give permission</button>`
    });
  }

  return dialogFrame({
    title: "Permission delegated",
    subtitle: "Bounded authority is being tracked",
    steps: 3,
    activeStep: 2,
    body: `<div class="result-state"><span class="result-icon is-settling">${icon("activity")}</span><h3>Delegating · settling</h3><p>${escapeHtml(data.delegate)} may ${escapeHtml(data.action).toLowerCase()} within ${escapeHtml(data.scope)} up to ${escapeHtml(data.uses)} times, ending ${escapeHtml(data.expiryLabel)}.</p><div class="receipt-ref mono">Right RGT-40A1 · zero-value · attenuation only</div></div>`,
    footer: `<button class="button" type="button" data-dialog-action="go-actions">View permissions</button><button class="button button-primary" type="button" data-dialog-close>Done</button>`
  });
}

function permissionDetailDialog() {
  const permission = (activeWallet().permissions || []).find((entry) => entry.id === state.flow.data.permissionId) || permissionDetails[state.flow.data.permissionId] || permissionDetails.receipt;
  return dialogFrame({
    title: permission.title,
    subtitle: permission.subtitle || "Held bounded permission",
    body: `
      <div class="review-card review-hero"><span class="list-icon is-right">${objectFamilyIcon("right")}</span><strong>${permission.remaining}</strong><span>remaining</span></div>
      <div class="review-card"><div class="summary-row"><span>Class</span><strong>${permission.classLabel}</strong></div><div class="summary-row"><span>Allowed action</span><strong>${permission.action}</strong></div><div class="summary-row"><span>Scope</span><strong>${permission.scope}</strong></div><div class="summary-row"><span>Delegation</span><strong>${permission.delegation}</strong></div><div class="summary-row"><span>Ends</span><strong>${permission.expiry}</strong></div><div class="summary-row"><span>Monetary value</span><strong>None</strong></div><div class="summary-row"><span>Status</span><strong><span class="status-badge is-${escapeHtml(permission.tone || "active")}">${escapeHtml(permission.status || "Held")}</span></strong></div></div>
      <details class="technical"><summary>Technical details</summary><div class="technical-content mono"><span>Right: ${permission.rightId}</span><span>Class: ${permission.typeLabel || permission.kind}</span><span>Lifecycle: granted → held</span></div></details>`,
    footer: `<button class="button button-danger" type="button" data-dialog-action="permission-revoke">Revoke permission</button><button class="button button-primary" type="button" data-dialog-close>Done</button>`
  });
}

function activityDialog(item) {
  const lifecycle = t(item.status === "settling" ? "history.lifecyclePending" : "history.lifecycleConfirmed");
  return dialogFrame({
    title: activityText(item, "title"),
    subtitle: t("history.details"),
    body: `
      <div class="review-card review-hero"><span class="list-icon ${item.direction === "in" ? "is-claim" : ""}">${icon(item.direction === "in" ? "receive" : item.direction === "out" ? "send" : "activity")}</span><strong>${escapeHtml(activityText(item, "amount") || statusText(item.status))}</strong><span>${escapeHtml(activityText(item, "detail"))}</span></div>
      <div class="review-card"><div class="summary-row"><span>${t("history.status")}</span><strong><span class="status-badge is-${escapeHtml(item.status)}">${statusText(item.status)}</span></strong></div><div class="summary-row"><span>${t("history.when")}</span><strong>${escapeHtml(activityText(item, "time"))}</strong></div><div class="summary-row"><span>${t("history.fee")}</span><strong>${t(item.type === "money" ? "history.feeIncluded" : "history.feeNotApplicable")}</strong></div><div class="summary-row"><span>${t("history.privacy")}</span><strong>${t("history.privacyValue")}</strong></div><div class="summary-row"><span>${t("history.carrierChain")}</span><strong>${t("history.carrierChainValue")}</strong></div></div>
      <details class="technical"><summary>${t("history.technicalDetails")}</summary><div class="technical-content mono"><span>${t("history.idLabel")}: ${escapeHtml(item.id)}-b4c9…8e20</span><span>${t("history.lifecycleLabel")}: ${lifecycle}</span><span>${t("history.receiptLabel")}: public_4a92…c71e</span></div></details>`,
    footer: `<button class="button" type="button" data-demo-action="copy-receipt">${icon("copy")} ${t("history.copyReceipt")}</button><button class="button button-primary" type="button" data-dialog-close>${t("history.done")}</button>`
  });
}

function assetDetailDialog() {
  const asset = supportedAsset(state.flow.data.assetKey);
  const rows = [
    ["Asset name", asset.label],
    ["Ticker", asset.ticker],
    ["Owner", asset.owner],
    ["Asset ID", asset.assetId],
    ["Current supply", asset.currentSupply],
    ["Max supply", asset.maxSupply]
  ];
  return dialogFrame({
    title: "Asset details",
    subtitle: `${asset.label} · ${asset.kind}`,
    headerLeading: assetIcon(asset, "asset-detail-logo"),
    helpTopic: "asset.details",
    body: `<div class="asset-detail-table">${rows.map(([label, value]) => `<div class="asset-detail-row"><span>${escapeHtml(label)}</span><strong class="${["Owner", "Asset ID"].includes(label) ? "mono" : ""}" title="${escapeHtml(value)}">${escapeHtml(value)}</strong></div>`).join("")}</div>`,
    footer: `<button class="button button-primary" type="button" data-dialog-close>OK</button>`
  });
}

function connectionDialog() {
  const chain = activeWallet().chainId;
  return dialogFrame({
    title: "Network",
    subtitle: "Overlay, carrier, and chain are separate",
    body: `
      <p class="eyebrow">Privacy mode · target simulation</p>
      <div class="connection-options"><div class="connection-option"><span class="health-orb"></span><span><strong>OnionNet</strong><small>Target overlay example · 3 hops</small></span><span class="status-badge is-ready">Target</span></div><div class="connection-option"><span class="health-orb"></span><span><strong>Reticulum</strong><small>Target primary resilient carrier</small></span><span class="status-badge is-ready">Target</span></div><div class="connection-option"><span class="health-orb"></span><span><strong>Tor</strong><small>Current switch method is a placeholder</small></span><span class="status-badge">Stub</span></div></div>
      <p class="eyebrow" style="margin-top:22px">Chain</p>
      <div class="connection-options"><div class="connection-option">${walletChainBadgeMarkup(chain)}<span><strong>${escapeHtml(walletChain(chain).label)}</strong><small>Bound when this wallet profile was created</small></span><span class="status-badge">Read-only</span></div></div>
      <div class="capability-note">${icon("alert")} <span><strong>Phase 080 target</strong><small>Current network RPC is stubbed; production must not show these properties until authoritative.</small></span></div>`,
    footer: `<button class="button button-primary" type="button" data-dialog-close>Done</button>`
  });
}

function notificationsDialog() {
  return dialogFrame({
    title: "Notifications",
    subtitle: "One item needs attention",
    body: `<div class="attention-list"><button class="attention-item" type="button" data-dialog-action="notification-voucher"><span class="list-icon is-voucher">${objectFamilyIcon("voucher")}</span><span class="list-copy"><strong>Travel refund voucher expires soon</strong><small>Review 86.00 Z00Z from Northwind Travel</small></span>${icon("chevron")}</button><div class="attention-item"><span class="list-icon">${icon("backup")}</span><span class="list-copy"><strong>Backup verified</strong><small>Your 10 Jul local backup passed integrity checks</small></span><span class="status-badge is-settled">Done</span></div></div>`,
    footer: `<button class="button button-primary" type="button" data-dialog-close>Done</button>`
  });
}

const demoSeedWords = [
  "canvas", "orbit", "maple", "velvet", "harbor", "copper", "quiet", "meadow",
  "lamp", "river", "winter", "piano", "forest", "amber", "window", "salt",
  "comet", "paper", "garden", "silver", "cloud", "stone", "echo", "north"
];

function randomIndex(upperBound) {
  if (globalThis.crypto?.getRandomValues) {
    const range = 0x100000000;
    const limit = Math.floor(range / upperBound) * upperBound;
    const value = new Uint32Array(1);
    do globalThis.crypto.getRandomValues(value); while (value[0] >= limit);
    return value[0] % upperBound;
  }
  return Math.floor(Math.random() * upperBound);
}

function randomSeedVerificationIndexes(previousIndexes = []) {
  const previous = new Set(previousIndexes);
  const candidates = demoSeedWords.map((_, index) => index).filter((index) => !previous.has(index));
  for (let index = candidates.length - 1; index > 0; index -= 1) {
    const swapIndex = randomIndex(index + 1);
    [candidates[index], candidates[swapIndex]] = [candidates[swapIndex], candidates[index]];
  }
  return candidates.slice(0, 4).sort((left, right) => left - right);
}

function seedVerificationOptions(seedIndex) {
  const choices = [
    seedIndex,
    (seedIndex + 7) % demoSeedWords.length,
    (seedIndex + 13) % demoSeedWords.length
  ];
  const rotation = seedIndex % choices.length;
  return [...choices.slice(rotation), ...choices.slice(0, rotation)]
    .map((index) => `<option value="${escapeHtml(demoSeedWords[index])}">${escapeHtml(demoSeedWords[index])}</option>`)
    .join("");
}

function seedVerificationPositionList(indexes) {
  const positions = indexes.map((index) => index + 1);
  return `${positions.slice(0, -1).join(", ")}, and ${positions.at(-1)}`;
}

function walletsDialog() {
  const selected = activeWallet();
  return dialogFrame({
    title: "Your wallets",
    subtitle: "Local profiles on this device",
    body: `
      <div class="wallet-list">
        ${state.wallets.map((wallet) => `<button class="wallet-choice${wallet.id === selected.id ? " is-current" : ""}" type="button" data-dialog-action="select-wallet" data-wallet-id="${escapeHtml(wallet.id)}">
          <span class="wallet-avatar" aria-hidden="true">${escapeHtml(wallet.initials)}</span><span><strong>${escapeHtml(wallet.name)}</strong><small class="mono">${escapeHtml(wallet.address)} · ${escapeHtml(walletChain(wallet.chainId).label)}</small></span><span class="status-badge${wallet.id === selected.id ? " is-active" : ""}">${wallet.id === selected.id ? "Open" : "Select"}</span>
        </button>`).join("")}
      </div>
      <div class="notice">${icon("shield")} Wallet profiles are local. Switching never sends a seed or password to another service.</div>`,
    footer: `<button class="button" type="button" data-dialog-action="add-wallet">${icon("plus")} Add wallet</button><button class="button button-primary" type="button" data-dialog-close>Close</button>`
  });
}

function networksDialog() {
  const selectedNetwork = state.view === "telemetry" ? state.telemetrySource : "";
  return dialogFrame({
    title: t("app.network"),
    subtitle: t("settings.networkPrivacyHelp"),
    body: `
      <div class="wallet-list network-picker-list">
        ${networkEntries.map((entry) => `<button class="wallet-choice${entry.key === selectedNetwork ? " is-current" : ""}" type="button"${entry.key === selectedNetwork ? ' aria-current="page"' : ""} data-dialog-action="select-network" data-network-section="${entry.key}">
          <span class="network-avatar" aria-hidden="true">${entry.initials}</span>
          <span><strong>${entry.label}</strong><small>${t(entry.helperKey)}</small></span>
          ${entry.key === selectedNetwork ? `<span class="status-badge is-active">${t("walletShell.current")}</span>` : ""}
        </button>`).join("")}
      </div>`,
    footer: `<button class="button button-quiet" type="button" data-dialog-close>${t("common.close")}</button>`
  });
}

function removeWalletDialog() {
  const selectedIds = new Set(state.flow.data.walletIds || []);
  const selectedCount = selectedIds.size;
  const canRemove = selectedCount > 0;
  return dialogFrame({
    title: "Remove wallet profiles",
    subtitle: "Remove local demo profiles from this concept. Wallet files are not deleted.",
    body: `
      <fieldset class="wallet-remove-list" aria-describedby="wallet-remove-summary">
        <legend class="sr-only">Wallet profiles to remove</legend>
        ${state.wallets.map((wallet) => {
          const checked = selectedIds.has(wallet.id);
          return `<label class="wallet-remove-choice${checked ? " is-selected" : ""}">
            <input type="checkbox" data-remove-wallet-id="${escapeHtml(wallet.id)}"${checked ? " checked" : ""}>
            <span class="wallet-avatar" aria-hidden="true">${escapeHtml(wallet.initials)}</span>
            <span class="wallet-remove-copy"><strong>${escapeHtml(wallet.name)}</strong><small class="mono">${escapeHtml(wallet.address)} · ${escapeHtml(wallet.summary.available)} Z00Z</small></span>
          </label>`;
        }).join("")}
      </fieldset>
      <p class="remove-selection-summary" id="wallet-remove-summary">${selectedCount} of ${state.wallets.length} selected. This removes concept profiles only.</p>
      ${selectedCount === state.wallets.length ? `<p class="field-error">All concept profiles will be removed. You can add a wallet again afterward.</p>` : ""}`,
    footer: `<button class="button button-quiet" type="button" data-dialog-close>Cancel</button><button class="button button-danger" type="button" data-dialog-action="confirm-remove-wallet"${canRemove ? "" : " disabled"}>${icon("remove")} Remove profiles${selectedCount ? ` (${selectedCount})` : ""}</button>`
  });
}

function addWalletDialog() {
  return dialogFrame({
    title: "Add wallet",
    subtitle: "Create, open, or restore a local wallet",
    body: `
      <div class="add-wallet-dialog-options" aria-label="Add wallet options">
        <p class="add-wallet-copy">Wallet keys, passwords, and recovery words remain local to this device in this concept.</p>
        <button class="button add-wallet-choice is-primary" type="button" data-demo-action="create-wallet">${icon("plus")} Create new wallet</button>
        <button class="button add-wallet-choice is-primary" type="button" data-demo-action="open-existing-wallet">${icon("wallet")} Open existing wallet</button>
        <button class="button add-wallet-choice" type="button" data-demo-action="restore-wallet">${icon("backup")} Restore from backup</button>
      </div>`,
    footer: `<button class="button button-quiet" type="button" data-dialog-close>Cancel</button>`
  });
}

function createWalletDialog() {
  const data = state.flow.data;
  if (state.flow.step === 0) {
    return dialogFrame({
      title: "Create wallet",
      subtitle: "A private local wallet",
      steps: 4,
      activeStep: 0,
      body: `
        <form class="form-grid" id="create-wallet-entry" autocomplete="off" ${passwordManagerIgnoreAttributes} novalidate>
          <div class="field-group"><label class="field-label" for="create-name">Wallet name</label><input id="create-name" name="walletLabel" value="${escapeHtml(data.name)}" maxlength="32" placeholder="Everyday wallet" autocomplete="section-z00z-new-wallet nickname" ${passwordManagerIgnoreAttributes} required aria-describedby="create-name-error"><p class="field-error" id="create-name-error"></p></div>
          <div class="field-group"><label class="field-label" for="create-chain">${t("common.chain")}</label><select id="create-chain" name="chainId" aria-describedby="create-chain-hint create-chain-error">${walletChainOptionsMarkup(data.chainId)}</select><p class="field-hint" id="create-chain-hint">${t("common.chainLocked")}</p><p class="field-error" id="create-chain-error"></p></div>
          <div class="field-group"><label class="field-label" for="create-password">Wallet password</label><input id="create-password" name="newWalletSecret" ${secureEntryAttributes("new-wallet-secret")} minlength="8" required aria-describedby="create-password-hint create-password-error"><p class="field-hint" id="create-password-hint">Use at least 8 characters. This concept never stores the value.</p><p class="field-error" id="create-password-error"></p></div>
          <div class="field-group"><label class="field-label" for="create-confirm">Confirm password</label><input id="create-confirm" name="confirmWalletSecret" ${secureEntryAttributes("new-wallet-secret-confirmation")} minlength="8" required aria-describedby="create-confirm-error"><p class="field-error" id="create-confirm-error"></p></div>
        </form>`,
      footer: `<button class="button" type="button" data-dialog-action="create-back-wallets">Back</button><button class="button button-primary" type="submit" form="create-wallet-entry">Create securely</button>`
    });
  }

  if (state.flow.step === 1) {
    return dialogFrame({
      title: "Save your recovery phrase",
      subtitle: "Shown once · demonstration words only",
      steps: 4,
      activeStep: 1,
      closeLabel: "Close and clear recovery phrase",
      body: `
        <div class="confirmation-note">${icon("alert")} Anyone with these 24 words can control the wallet. In production, check your surroundings and keep them offline.</div>
        <ol class="seed-grid" aria-label="Demonstration 24-word recovery phrase">${demoSeedWords.map((word, index) => `<li><span>${index + 1}</span><strong>${word}</strong></li>`).join("")}</ol>
        <p class="seed-demo-label">DEMONSTRATION WORDS · NOT A REAL WALLET SEED</p>
        <button class="button button-full" type="button" data-demo-action="copy-seed-warning">${icon("copy")} Copy requires an extra warning</button>`,
      footer: `<button class="button button-primary" type="button" data-dialog-action="create-seed-saved">I've saved these words</button>`
    });
  }

  if (state.flow.step === 2) {
    const verificationIndexes = state.flow.data.verificationIndexes || randomSeedVerificationIndexes();
    state.flow.data.verificationIndexes = verificationIndexes;
    return dialogFrame({
      title: "Check your backup",
      subtitle: "Confirm four random words before continuing",
      steps: 4,
      activeStep: 2,
      body: `
        <form class="form-grid" id="create-wallet-verify" novalidate>
          ${verificationIndexes.map((seedIndex) => `<div class="field-group"><label class="field-label" for="seed-word-${seedIndex + 1}">Word ${seedIndex + 1}</label><select id="seed-word-${seedIndex + 1}" name="word${seedIndex + 1}" data-seed-index="${seedIndex}" required><option value="">Choose word</option>${seedVerificationOptions(seedIndex)}</select></div>`).join("")}
          <p class="field-error" id="seed-verify-error" role="alert"></p>
        </form>`,
      footer: `<button class="button" type="button" data-dialog-action="create-seed-back">View words again</button><button class="button button-primary" type="submit" form="create-wallet-verify">Finish setup</button>`
    });
  }

  return dialogFrame({
    title: "Wallet ready",
    subtitle: "Recovery check completed",
    steps: 4,
    activeStep: 3,
    body: `<div class="result-state"><span class="result-icon">${icon("check")}</span><h3>${escapeHtml(data.name || "New wallet")} is ready</h3><p>The wallet is encrypted on this device. The demonstration phrase has been cleared from the view.</p></div><div class="review-card"><div class="summary-row"><span>${t("common.chain")}</span><strong>${walletChainBadgeMarkup(data.chainId)}</strong></div><div class="summary-row"><span>Backup check</span><strong class="trust-label">${icon("shield")} Completed</strong></div></div>`,
    footer: `<button class="button button-primary" type="button" data-dialog-action="create-finish">Open wallet</button>`
  });
}

function recoverWalletDialog() {
  const data = state.flow.data;
  if (state.flow.step === 0) {
    return dialogFrame({
      title: "Recover wallet",
      subtitle: "Enter the same 24 English words twice",
      steps: 2,
      activeStep: 0,
      body: `
        <div class="confirmation-note">${icon("shield")} Recovery is validated locally. Never enter your words into a website or support chat.</div>
        <form class="form-grid" id="recover-wallet-entry" novalidate>
          <div class="field-group"><label class="field-label" for="recover-name">Wallet name</label><input id="recover-name" name="name" value="${escapeHtml(data.name || "Recovered wallet")}" maxlength="32" placeholder="Recovered wallet" autocomplete="off" required aria-describedby="recover-name-error"><p class="field-error" id="recover-name-error"></p></div>
          <div class="field-group"><label class="field-label" for="recover-phrase-a">Recovery phrase</label><textarea class="seed-entry" id="recover-phrase-a" name="phraseA" rows="4" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="Enter 24 English words" required></textarea><p class="field-hint">0 of 24 words</p></div>
          <div class="field-group"><label class="field-label" for="recover-phrase-b">Enter it again</label><textarea class="seed-entry" id="recover-phrase-b" name="phraseB" rows="4" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="Repeat the same 24 words" required></textarea><p class="field-hint">0 of 24 words</p></div>
          <p class="field-error" id="recover-phrase-error" role="alert"></p>
          <button class="text-button" type="button" data-demo-action="fill-demo-seed">Fill demonstration words</button>
        </form>`,
      footer: `<button class="button" type="button" data-dialog-action="recover-back-wallets">Back</button><button class="button button-primary" type="submit" form="recover-wallet-entry">Validate and recover</button>`
    });
  }

  return dialogFrame({
    title: "Wallet recovered",
    subtitle: "Updating private wallet state",
    steps: 2,
    activeStep: 1,
    body: `<div class="result-state"><span class="result-icon is-settling">${icon("activity")}</span><h3>Recovery complete · scanning</h3><p>Your keys are available locally. Money and history will appear as the wallet scan catches up.</p></div><div class="review-card"><div class="summary-row"><span>Wallet scan</span><strong>42%</strong></div><div class="progress-track"><div class="progress-bar" style="width:42%"></div></div><div class="summary-row"><span>Safe to close</span><strong>Yes · resumes automatically</strong></div></div>`,
    footer: `<button class="button button-primary" type="button" data-dialog-action="recover-finish">Open wallet</button>`
  });
}

function openWalletDialog() {
  const data = state.flow.data;
  return dialogFrame({
    title: "Open existing wallet",
    subtitle: "Add a local encrypted wallet profile",
    body: `
      <form class="form-grid" id="open-wallet-entry" novalidate>
        <div class="field-group"><label class="field-label" for="open-wallet-name">Wallet name</label><input id="open-wallet-name" name="name" value="${escapeHtml(data.name || "Existing wallet")}" maxlength="32" placeholder="Existing wallet" autocomplete="off" required aria-describedby="open-wallet-error"><p class="field-error" id="open-wallet-error" role="alert"></p></div>
        <div class="review-card"><div class="summary-row"><span>Storage</span><strong>Encrypted local profile</strong></div><div class="summary-row"><span>After opening</span><strong>Wallet scan begins</strong></div></div>
        <div class="notice">${icon("shield")} This concept does not ask for, access, or upload a wallet file path.</div>
      </form>`,
    footer: `<button class="button" type="button" data-dialog-close>Cancel</button><button class="button button-primary" type="submit" form="open-wallet-entry">Open wallet</button>`
  });
}

function renderDialog() {
  if (!state.flow) return;
  const type = state.flow.type;
  const content = type === "asset-claim" ? assetClaimDialog()
    : type === "create-voucher" ? createVoucherDialog()
    : type === "voucher-detail" ? voucherDetailDialog()
    : type === "voucher-review" ? voucherDialog(false)
    : type === "voucher-settled" ? voucherDialog(true)
    : type === "create-permission" ? createPermissionDialog()
    : type === "permission" ? permissionDialog()
    : type === "permission-detail" ? permissionDetailDialog()
    : type === "activity" ? activityDialog(state.flow.data.item)
    : type === "asset-detail" ? assetDetailDialog()
    : type === "connection" ? connectionDialog()
    : type === "wallets" ? walletsDialog()
    : type === "networks" ? networksDialog()
    : type === "remove-wallet" ? removeWalletDialog()
    : type === "add-wallet" ? addWalletDialog()
    : type === "create-wallet" ? createWalletDialog()
    : type === "open-wallet" ? openWalletDialog()
    : type === "recover-wallet" ? recoverWalletDialog()
    : ["wallet-rename", "wallet-password-change", "wallet-seed-reveal", "wallet-public-export", "wallet-key-rotation", "wallet-policy-apply", "wallet-policy-profile"].includes(type) ? sensitiveWalletDialog(type)
    : notificationsDialog();
  dialogContent.innerHTML = content;
  suppressPasswordManagerUI(dialogContent);
}

function defaultFlowData(type) {
  if (type === "permission") return { delegate: "", action: "Deploy release", scope: "staging.example", uses: "1", expiry: "2026-08-19", expiryLabel: "19 Aug 2026" };
  if (type === "create-wallet") return { name: "", chainId: "mainnet", verificationIndexes: randomSeedVerificationIndexes() };
  if (type === "open-wallet") return { name: "Existing wallet" };
  if (type === "recover-wallet") return { name: "Recovered wallet" };
  if (type === "remove-wallet") return { walletIds: [] };
  return {};
}

function openFlow(type, trigger = document.activeElement, extraData = {}) {
  state.lastDialogTrigger = trigger;
  state.flow = { type, step: 0, data: { ...defaultFlowData(type), ...extraData } };
  renderDialog();
  if (!dialog.open) dialog.showModal();
  requestAnimationFrame(() => {
    const target = dialog.querySelector("input:not([type='hidden']), select, button:not([data-dialog-close])");
    target?.focus();
  });
}

function closeDialog() {
  if (dialog.open) dialog.close();
}

function showToast(message, iconName = "check") {
  const region = document.querySelector("#toast-region");
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = `${icon(iconName)}<span>${escapeHtml(message)}</span><button type="button" aria-label="Dismiss notification">${icon("close")}</button>`;
  toast.querySelector("button").addEventListener("click", () => toast.remove());
  region.append(toast);
  window.setTimeout(() => toast.remove(), 4200);
}

function qrCells(seed = "") {
  const size = 21;
  const fixedDark = new Set();
  const fixedLight = new Set();
  const seedValue = Array.from(seed).reduce((total, character, index) => total + character.charCodeAt(0) * (index + 1), 0);
  function square(startX, startY) {
    for (let y = 0; y < 7; y += 1) {
      for (let x = 0; x < 7; x += 1) {
        const index = (startY + y) * size + startX + x;
        const isDark = x === 0 || y === 0 || x === 6 || y === 6 || (x >= 2 && x <= 4 && y >= 2 && y <= 4);
        (isDark ? fixedDark : fixedLight).add(index);
      }
    }
  }
  square(0, 0); square(14, 0); square(0, 14);
  return Array.from({ length: size * size }, (_, index) => {
    let hash = (seedValue ^ Math.imul(index + 1, 0x45d9f3b)) >>> 0;
    hash = Math.imul(hash ^ (hash >>> 16), 0x45d9f3b);
    hash = Math.imul(hash ^ (hash >>> 16), 0x45d9f3b);
    const pseudo = ((hash ^ (hash >>> 16)) & 1) === 1;
    const isDark = fixedDark.has(index) || (!fixedLight.has(index) && pseudo);
    return `<span class="${isDark ? "is-dark" : ""}"></span>`;
  }).join("");
}

function validateSend(form) {
  const draft = activeSendDraft();
  const recipient = form.elements.recipient;
  const amount = form.elements.amount || null;
  const item = sendOptionEntries(draft.family).find((entry) => entry.key === form.elements.itemKey.value);
  let valid = true;
  document.querySelector("#send-recipient-error").textContent = "";
  document.querySelector("#send-amount-error").textContent = "";
  recipient.removeAttribute("aria-invalid");
  amount?.removeAttribute("aria-invalid");

  if (recipient.value.trim().length < 3) {
    document.querySelector("#send-recipient-error").textContent = "Enter or scan a valid recipient request.";
    recipient.setAttribute("aria-invalid", "true");
    valid = false;
  }
  if (!item) {
    document.querySelector("#send-amount-error").textContent = "Choose an available wallet item.";
    valid = false;
  }
  let normalizedAmount = "";
  if (item?.family === "asset") {
    const number = Number(amount?.value);
    if (!Number.isFinite(number) || number <= 0 || number > Number(item.asset.balance.replaceAll(",", "")) || (!item.asset.divisible && !Number.isInteger(number))) {
      const minimum = item.asset.divisible ? "0.01" : "1";
      document.querySelector("#send-amount-error").textContent = `Enter ${item.asset.divisible ? "an amount" : "a whole unit"} between ${minimum} and ${item.asset.balance} ${item.asset.unit}.`;
      amount?.setAttribute("aria-invalid", "true");
      valid = false;
    } else {
      normalizedAmount = item.asset.divisible ? number.toFixed(2) : String(number);
    }
  }
  if (!valid) {
    form.querySelector('[aria-invalid="true"]')?.focus();
    return;
  }

  Object.assign(draft, {
    recipient: recipient.value.trim(),
    recipientLabel: recipient.value.trim().startsWith("z00z:") ? "Verified asset request" : recipient.value.trim(),
    amount: normalizedAmount,
    memo: form.elements.memo.value.trim(),
    itemKey: item.key,
    step: 1,
    completed: null
  });
  render({ focusMain: true });
}

function validateExchange(form) {
  const draft = captureExchangeDraft(form);
  const source = supportedAsset(draft.sourceAssetKey);
  const amount = Number(draft.amount);
  const error = document.querySelector("#exchange-error");
  const amountInput = form.elements.amount;
  error.textContent = "";
  amountInput.removeAttribute("aria-invalid");

  if (!Number.isFinite(amount) || amount <= 0 || amount > Number(source.balance.replaceAll(",", "")) || (!source.divisible && !Number.isInteger(amount))) {
    error.textContent = t("exchange.amountError", { balance: source.balance, unit: source.unit });
    amountInput.setAttribute("aria-invalid", "true");
    amountInput.focus();
    return;
  }
  if (draft.providerId === "hyperliquid" && draft.orderType === "limit" && !(Number(draft.limitPrice) > 0)) {
    error.textContent = t("exchange.limitPriceError");
    form.elements.limitPrice?.setAttribute("aria-invalid", "true");
    form.elements.limitPrice?.focus();
    return;
  }
  if (draft.providerId === "near-intents" && (draft.recipient.length < 3 || draft.refundAddress.length < 3)) {
    error.textContent = t("exchange.addressError");
    (draft.recipient.length < 3 ? form.elements.recipient : form.elements.refundAddress)?.setAttribute("aria-invalid", "true");
    (draft.recipient.length < 3 ? form.elements.recipient : form.elements.refundAddress)?.focus();
    return;
  }
  draft.amount = source.divisible ? amount.toFixed(2) : String(amount);
  draft.step = 1;
  render({ focusMain: true });
}

function validatePermission(form) {
  const delegate = form.elements.delegate;
  const uses = form.elements.uses;
  let valid = true;
  document.querySelector("#permission-delegate-error").textContent = "";
  document.querySelector("#permission-uses-error").textContent = "";
  delegate.removeAttribute("aria-invalid");
  uses.removeAttribute("aria-invalid");

  if (delegate.value.trim().length < 3) {
    document.querySelector("#permission-delegate-error").textContent = "Choose a verified service or known person.";
    delegate.setAttribute("aria-invalid", "true");
    valid = false;
  }
  const useCount = Number(uses.value);
  if (!Number.isInteger(useCount) || useCount < 1 || useCount > 5) {
    document.querySelector("#permission-uses-error").textContent = "Choose between 1 and 5 uses, within the held authority.";
    uses.setAttribute("aria-invalid", "true");
    valid = false;
  }
  if (!valid) {
    form.querySelector('[aria-invalid="true"]')?.focus();
    return;
  }

  const expiry = new Date(`${form.elements.expiry.value}T12:00:00`);
  state.flow.data = {
    delegate: delegate.value.trim(),
    action: form.elements.action.value,
    scope: form.elements.scope.value,
    uses: String(useCount),
    expiry: form.elements.expiry.value,
    expiryLabel: new Intl.DateTimeFormat("en", { day: "2-digit", month: "short", year: "numeric" }).format(expiry)
  };
  state.flow.step = 1;
  renderDialog();
}

function validateWalletSettingsAction(form) {
  const type = state.flow?.type;
  const error = form.querySelector(".field-error");
  const password = form.elements.walletSecret;
  if (error) error.textContent = "";
  password?.removeAttribute("aria-invalid");
  if (!password || password.value.length < 8) {
    if (error) error.textContent = "Enter at least 8 characters for this concept password check.";
    password?.setAttribute("aria-invalid", "true");
    password?.focus();
    return;
  }

  const requiredConfirmation = {
    "wallet-seed-reveal": "SHOW SEED",
    "wallet-key-rotation": "ROTATE",
    "wallet-policy-apply": "APPLY"
  }[type];
  if (requiredConfirmation && form.elements.confirmation?.value.trim() !== requiredConfirmation) {
    if (error) error.textContent = `Type ${requiredConfirmation} to continue.`;
    form.elements.confirmation?.setAttribute("aria-invalid", "true");
    form.elements.confirmation?.focus();
    return;
  }

  const wallet = activeWallet();
  const preferences = activeWalletPreferences();
  if (type === "wallet-rename") {
    const name = form.elements.walletLabel.value.trim();
    if (name.length < 2 || name.length > 32) {
      if (error) error.textContent = "Wallet name must contain 2–32 characters.";
      form.elements.walletLabel.setAttribute("aria-invalid", "true");
      form.elements.walletLabel.focus();
      return;
    }
    const result = walletGateway.renameWallet({ walletId: wallet.id, name });
    if (!result.ok) {
      if (error) error.textContent = result.error.message;
      form.elements.walletLabel.setAttribute("aria-invalid", "true");
      form.elements.walletLabel.focus();
      return;
    }
  }
  if (type === "wallet-policy-apply") {
    const maxTransaction = form.elements.maxTransaction.value.trim();
    const maxDaily = form.elements.maxDaily.value.trim();
    if (!/^\d+(?:\.\d+)?$/.test(maxTransaction) || !/^\d+(?:\.\d+)?$/.test(maxDaily)) {
      if (error) error.textContent = "Spend limits must be non-negative decimals.";
      (!/^\d+(?:\.\d+)?$/.test(maxTransaction) ? form.elements.maxTransaction : form.elements.maxDaily).focus();
      return;
    }
    preferences.policyRules = {
      maxTransaction,
      maxDaily,
      requireConfirmation: form.elements.requireConfirmation.checked,
      allowedAssets: form.elements.allowedAssets.value,
      allowedRecipients: form.elements.allowedRecipients.value.trim(),
      timeWindow: form.elements.timeWindow.value
    };
  }
  if (type === "wallet-key-rotation") preferences.lastMasterKeyRotation = "Just now · concept";
  password.value = "";
  if (form.elements.confirmation) form.elements.confirmation.value = "";
  state.walletSettingsConfigDraft = "";
  syncConfigDraftFromState();
  state.flow.step = 1;
  render();
  renderDialog();
}

function validateWalletPasswordChange(form) {
  const currentPassword = form.elements.currentWalletSecret;
  const newPassword = form.elements.newWalletSecret;
  const confirmNewPassword = form.elements.confirmNewWalletSecret;
  const error = form.querySelector(".field-error");
  const fields = [currentPassword, newPassword, confirmNewPassword];
  if (error) error.textContent = "";
  fields.forEach((field) => field.removeAttribute("aria-invalid"));

  if (currentPassword.value.length < 8) {
    error.textContent = t("walletSettings.passwordCurrentError");
    currentPassword.setAttribute("aria-invalid", "true");
    currentPassword.focus();
    return;
  }
  if (newPassword.value.length < 8) {
    error.textContent = t("walletSettings.passwordNewError");
    newPassword.setAttribute("aria-invalid", "true");
    newPassword.focus();
    return;
  }
  if (newPassword.value === currentPassword.value) {
    error.textContent = t("walletSettings.passwordSameError");
    newPassword.setAttribute("aria-invalid", "true");
    newPassword.focus();
    return;
  }
  if (confirmNewPassword.value !== newPassword.value) {
    error.textContent = t("walletSettings.passwordMismatchError");
    confirmNewPassword.setAttribute("aria-invalid", "true");
    confirmNewPassword.focus();
    return;
  }

  const result = walletGateway.changePassword({
    walletId: activeWallet().id,
    currentPassword: currentPassword.value,
    newPassword: newPassword.value
  });
  if (!result.ok) {
    error.textContent = result.error.message;
    currentPassword.focus();
    return;
  }
  fields.forEach((field) => { field.value = ""; });
  state.flow.step = 1;
  renderDialog();
}

function setButtonLoading(button, label) {
  button.disabled = true;
  button.dataset.original = button.innerHTML;
  button.textContent = label;
}

function completeSend() {
  const data = activeSendDraft();
  const wallet = activeWallet();
  const item = selectedSendOption(data);
  if (!item) {
    showToast("This wallet item is no longer available.", "alert");
    resetActiveSendDraft();
    render({ focusMain: true });
    return;
  }

  let amountLabel = item.meta;
  if (item.family === "asset") {
    amountLabel = `${data.amount} ${item.asset.unit}`;
    wallet.activities.unshift({ id: `tx-${wallet.activities.length + 1}`, type: item.asset.key === "z00z" ? "money" : "asset", direction: "out", title: `${item.label} sent`, detail: `Sent to ${data.recipientLabel} · waiting to settle`, amount: `− ${amountLabel}`, time: "Now", status: "settling" });
  } else {
    const result = walletGateway.transferObject({
      walletId: wallet.id,
      family: item.family,
      objectId: item.entry.id,
      recipient: data.recipient
    });
    if (!result.ok) {
      showToast(result.error.message, "alert");
      resetActiveSendDraft();
      render({ focusMain: true });
      return;
    }
    wallet.activities.unshift({
      id: `${item.family}-send-${wallet.activities.length + 1}`,
      type: item.family,
      direction: "out",
      title: `${item.label} sent`,
      detail: `Sent to ${data.recipient} · waiting to settle`,
      amount: item.family === "voucher" ? item.entry.value : "",
      time: "Now",
      status: "settling"
    });
  }

  data.completed = {
    family: item.family,
    label: item.label,
    amountLabel,
    recipientLabel: data.recipientLabel
  };
  data.step = 2;
  render({ focusMain: true });
}

function handleDialogAction(action, button) {
  if (action === "permission-back") {
    state.flow.step = 0;
    renderDialog();
  } else if (action === "permission-submit") {
    setButtonLoading(button, "Delegating…");
    window.setTimeout(() => { state.flow.step = 2; renderDialog(); }, 650);
  } else if (action === "asset-claim-submit") {
    setButtonLoading(button, "Verifying once…");
    window.setTimeout(() => { state.flow.step = 1; renderDialog(); }, 600);
  } else if (action === "voucher-accept") {
    setButtonLoading(button, "Accepting voucher…");
    window.setTimeout(() => { state.flow.step = 1; renderDialog(); }, 600);
  } else if (action === "voucher-redeem") {
    setButtonLoading(button, "Redeeming…");
    window.setTimeout(() => { state.flow.step = 2; renderDialog(); }, 600);
  } else if (action === "voucher-reject") {
    showToast("Rejecting a voucher requires a separate consequence confirmation.", "alert");
  } else if (action === "permission-revoke") {
    showToast("Revocation requires re-authentication and consequence review.", "alert");
  } else if (action === "view-activity") {
    closeDialog();
    state.view = "activity";
    state.activityFilter = "all";
    render({ focusMain: true });
  } else if (action === "go-actions") {
    closeDialog();
    state.view = "wallet";
    state.walletSection = "permissions";
    render({ focusMain: true });
  } else if (action === "notification-voucher") {
    closeDialog();
    window.setTimeout(() => openFlow("voucher-review", button), 0);
  } else if (action === "select-wallet") {
    closeDialog();
    state.selectedWalletId = button.dataset.walletId;
    state.view = "wallet";
    state.activityFilter = "all";
    state.assetFilter = "all";
    render({ focusMain: true });
    showToast(`${activeWallet().name} wallet opened in concept mode.`);
  } else if (action === "select-network") {
    closeDialog();
    state.view = "telemetry";
    state.telemetrySource = button.dataset.networkSection;
    state.isNetworkOpen = false;
    render({ focusMain: true });
  } else if (action === "confirm-remove-wallet") {
    const selectedIds = new Set(state.flow?.data.walletIds || []);
    const result = walletGateway.removeProfiles({
      walletIds: selectedIds,
      selectedWalletId: state.selectedWalletId
    });
    if (!result.ok) {
      showToast(result.error.message, "alert");
      return;
    }
    const { removed: walletsToRemove, selectedWalletId } = result.data;
    const needsWalletSetup = state.wallets.length === 0;
    if (needsWalletSetup) {
      state.selectedWalletId = null;
      state.view = "home";
    } else {
      state.selectedWalletId = selectedWalletId;
      state.view = "wallet";
    }
    state.activityFilter = "all";
    closeDialog();
    render({ focusMain: true });
    showToast(state.wallets.length === 0 ? "All wallet profiles removed. Add a wallet to continue." : `${walletsToRemove.length} wallet${walletsToRemove.length === 1 ? "" : "s"} removed from this concept.`);
    if (needsWalletSetup) window.setTimeout(() => openFlow("add-wallet", button), 0);
  } else if (action === "add-wallet") {
    openFlow("add-wallet", button);
  } else if (["start-create", "start-recover"].includes(action)) {
    openFlow("add-wallet", button);
  } else if (["create-back-wallets", "recover-back-wallets"].includes(action)) {
    openFlow("add-wallet", button);
  } else if (action === "create-seed-saved") {
    state.flow.step = 2;
    renderDialog();
  } else if (action === "create-seed-back") {
    state.flow.data.verificationIndexes = randomSeedVerificationIndexes(state.flow.data.verificationIndexes);
    state.flow.step = 1;
    renderDialog();
  } else if (action === "create-finish" || action === "recover-finish") {
    const recovered = action === "recover-finish";
    const wallet = addWalletProfile(
      state.flow.data.name || (recovered ? "Recovered wallet" : "New wallet"),
      recovered ? "mainnet" : state.flow.data.chainId,
      "Scanning"
    );
    state.selectedWalletId = wallet.id;
    state.view = "wallet";
    state.activityFilter = "all";
    state.assetFilter = "all";
    closeDialog();
    if (state.locked) {
      state.locked = false;
      lockScreen.hidden = true;
      appShell.hidden = false;
      appShell.inert = false;
    }
    render();
    showToast(recovered ? "Recovered wallet opened; scan continues." : "New wallet opened in concept mode.");
  }
}

function handleDemoAction(action, button) {
  if (action === "toggle-balance") {
    state.balanceHidden = !state.balanceHidden;
    syncConfigDraftFromState();
    render();
    showToast(state.balanceHidden ? "Sensitive amounts hidden." : "Sensitive amounts visible.");
  } else if (["lock", "logout"].includes(action)) {
    closeDialog();
    state.locked = true;
    appShell.hidden = true;
    appShell.inert = true;
    lockScreen.hidden = false;
    document.querySelector("#unlock-password").value = "";
    document.querySelector("#unlock-error").textContent = "";
    document.querySelector("#unlock-password").focus();
    if (action === "logout") showToast("Wallet session ended.");
  } else if (action === "add-wallet") {
    openFlow("add-wallet", button);
  } else if (action === "remove-wallet") {
    if (state.wallets.length === 0) {
      openFlow("add-wallet", button);
      return;
    }
    openFlow("remove-wallet", button);
  } else if (action === "create-wallet") {
    openFlow("create-wallet", button);
  } else if (action === "open-existing-wallet") {
    openFlow("open-wallet", button);
  } else if (action === "restore-wallet") {
    openFlow("recover-wallet", button);
  } else if (action === "switch-wallet") {
    openFlow("wallets", button);
  } else if (action === "network-picker") {
    openFlow("networks", button);
  } else if (action === "notifications") {
    openFlow("notifications", button);
  } else if (["copy-receipt", "copy-wallet-address"].includes(action)) {
    const messages = {
      "copy-receipt": "Public receipt copied.",
      "copy-wallet-address": "Wallet address copied."
    };
    showToast(messages[action]);
  } else if (action === "wallet-auto-backup") {
    const preferences = activeWalletPreferences();
    preferences.autoBackup = !preferences.autoBackup;
    state.walletSettingsConfigDraft = "";
    syncConfigDraftFromState();
    render();
    showToast(`Automatic backup ${preferences.autoBackup ? "enabled" : "disabled"} for ${activeWallet().name}.`);
  } else if (action === "wallet-config-validate") {
    const source = document.querySelector("#wallet-settings-yaml")?.value ?? state.walletSettingsConfigDraft;
    state.walletSettingsConfigDraft = source;
    const result = validateAndApplyWalletSettingsYaml(source);
    state.configStatus = result.message;
    render();
    showToast(result.message, result.valid ? "check" : "alert");
  } else if (action === "wallet-config-apply") {
    const source = document.querySelector("#wallet-settings-yaml")?.value ?? state.walletSettingsConfigDraft;
    state.walletSettingsConfigDraft = source;
    const result = validateAndApplyWalletSettingsYaml(source, true);
    state.configStatus = result.message;
    if (result.valid) state.walletSettingsConfigDraft = "";
    render();
    showToast(result.message, result.valid ? "check" : "alert");
  } else if (action === "seed-warning") {
    showToast("Seed reveal requires re-authentication and a private display check.", "alert");
  } else if (action === "key-rotation") {
    showToast("Key rotation requires re-authentication and a fresh backup.", "alert");
  } else if (action === "backup") {
    showToast("Backup destination selection would open next.");
  } else if (action === "restore") {
    showToast("Restore validates integrity before any replacement.", "alert");
  } else if (action === "preview-swap") {
    showToast(`${activeWallet().name} wallet needs a verified quote before a swap can be reviewed.`);
  } else if (action === "request-exchange-quote") {
    showToast("An exchange quote requires a verified provider and an authoritative route.");
  } else if (action === "prepare-stake") {
    showToast(`${activeWallet().name} wallet needs validator and lock-up terms before staking can be reviewed.`);
  } else if (action === "asset-review") {
    showToast("Declared domain and metadata are not the same as an authoritative trust verdict.", "alert");
  } else if (action === "general-notifications") {
    state.notifications = !state.notifications;
    syncConfigDraftFromState();
    render();
    showToast(`Notifications ${state.notifications ? "enabled" : "disabled"}.`);
  } else if (action === "motion") {
    state.reducedMotion = !state.reducedMotion;
    syncConfigDraftFromState();
    render();
    showToast(`Reduced motion ${state.reducedMotion ? "enabled" : "disabled"}.`);
  } else if (action === "expert") {
    state.expertDetails = !state.expertDetails;
    syncConfigDraftFromState();
    render();
    showToast(`Expert details ${state.expertDetails ? "enabled" : "disabled"}.`);
  } else if (action === "diagnostics") {
    showToast("Diagnostics would open sanitized RPC and route records.");
  } else if (action === "load-policy") {
    showToast("Profile would be parsed, signature-checked, capability-checked, and previewed before Apply.");
  } else if (action === "why-blocked") {
    showToast("Target preview: Personal Safe v1.4 would block this above its 2,500 Z00Z maximum.", "alert");
  } else if (action === "config-validate") {
    const source = document.querySelector("#config-yaml")?.value ?? state.configDraft;
    state.configDraft = source;
    const result = validateAndApplyDemoConfig(source);
    state.configStatus = result.message;
    render();
    showToast(result.message, result.valid ? "check" : "alert");
  } else if (action === "config-apply") {
    const source = document.querySelector("#config-yaml")?.value ?? state.configDraft;
    state.configDraft = source;
    const result = validateAndApplyDemoConfig(source, true);
    state.configStatus = result.message;
    if (result.valid) syncConfigDraftFromState();
    render();
    showToast(result.message, result.valid ? "check" : "alert");
  } else if (action === "config-stage") {
    showToast("Reticulum interface changes would be staged in YAML; restart required.");
  } else if (action === "rebuild-route") {
    showToast("OnionNet would build and verify a new route before cutover.");
  } else if (action === "route-onion") {
    showToast("Route switch requires a live connectivity check.");
  } else if (action === "copy-seed-warning") {
    showToast("Production copy requires a second warning and timed clipboard clearing.", "alert");
  } else if (action === "fill-demo-seed") {
    const phrase = demoSeedWords.join(" ");
    const first = document.querySelector("#recover-phrase-a");
    const second = document.querySelector("#recover-phrase-b");
    if (first && second) {
      first.value = phrase;
      second.value = phrase;
      first.dispatchEvent(new Event("input", { bubbles: true }));
      second.dispatchEvent(new Event("input", { bubbles: true }));
      showToast("Demonstration words filled; they are not a real seed.");
    }
  }
}

document.addEventListener("z00z:help-opening", () => closeMobilePopup());

document.addEventListener("click", (event) => {
  if (event.target.closest("#mobile-menu-backdrop")) {
    closeMobilePopup({ restoreFocus: true });
    return;
  }

  const mobileMenuToggle = event.target.closest("#mobile-menu-button");
  if (mobileMenuToggle) {
    openMobilePopup("menu", mobileMenuToggle);
    return;
  }

  const mobilePopupClose = event.target.closest("[data-mobile-popup-close]");
  if (mobilePopupClose) {
    closeMobilePopup({ restoreFocus: true });
    return;
  }

  const mobileMenuGroup = event.target.closest("[data-mobile-menu-group]");
  if (mobileMenuGroup) {
    const group = mobileMenuGroup.dataset.mobileMenuGroup;
    const panel = mobilePopupMenu.querySelector(`[data-mobile-menu-panel="${group}"]`);
    if (!panel) return;
    const expanded = !mobileMenuExpandedGroups.has(group);
    if (expanded) {
      mobileMenuExpandedGroups.add(group);
    } else {
      mobileMenuExpandedGroups.delete(group);
    }
    mobileMenuGroup.setAttribute("aria-expanded", String(expanded));
    panel.hidden = !expanded;
    return;
  }

  const mobileWalletChoice = event.target.closest("[data-mobile-select-wallet]");
  if (mobileWalletChoice) {
    state.selectedWalletId = mobileWalletChoice.dataset.mobileSelectWallet;
    state.view = "wallet";
    state.walletSection = "assets";
    state.activityFilter = "all";
    state.assetFilter = "all";
    closeMobilePopup();
    render({ focusMain: true });
    return;
  }

  const mobileNetworkChoice = event.target.closest("[data-mobile-select-network]");
  if (mobileNetworkChoice) {
    state.view = "telemetry";
    state.telemetrySource = mobileNetworkChoice.dataset.mobileSelectNetwork;
    state.isNetworkOpen = false;
    closeMobilePopup();
    render({ focusMain: true });
    return;
  }

  const mobileAppView = event.target.closest("[data-mobile-app-view]");
  if (mobileAppView) {
    state.view = mobileAppView.dataset.mobileAppView;
    state.settingsSection = "general";
    state.networkSection = "overview";
    state.isNetworkOpen = false;
    closeMobilePopup();
    render({ focusMain: true });
    return;
  }

  const mobilePopupAction = event.target.closest("[data-mobile-popup-action]");
  if (mobilePopupAction) {
    const action = mobilePopupAction.dataset.mobilePopupAction;
    closeMobilePopup();
    handleDemoAction(action, mobileMenuButton);
    return;
  }

  const mobileWalletSection = event.target.closest("[data-mobile-wallet-section]");
  if (mobileWalletSection) {
    state.view = "wallet";
    state.walletSection = mobileWalletSection.dataset.mobileWalletSection;
    closeMobilePopup();
    render({ focusMain: true });
    return;
  }

  const mobileWalletSettingsSection = event.target.closest("[data-mobile-wallet-settings-section]");
  if (mobileWalletSettingsSection) {
    state.view = "wallet-settings";
    state.walletSettingsSection = mobileWalletSettingsSection.dataset.mobileWalletSettingsSection;
    closeMobilePopup();
    render({ focusMain: true });
    return;
  }

  const mobileExchangeProvider = event.target.closest("[data-mobile-exchange-provider]");
  if (mobileExchangeProvider) {
    const draft = activeExchangeDraft();
    draft.providerId = mobileExchangeProvider.dataset.mobileExchangeProvider;
    draft.destinationId = demoRuntime.exchangeProvider(draft.providerId).defaultDestination;
    draft.orderType = "market";
    draft.limitPrice = "";
    draft.step = 0;
    state.view = "exchange";
    closeMobilePopup();
    render({ focusMain: true });
    return;
  }

  const mobileContextTrigger = event.target.closest("#wallet-tabs [data-mobile-popup]");
  if (mobileContextTrigger && isMobileNavigation()) {
    openMobilePopup(mobileContextTrigger.dataset.mobilePopup, mobileContextTrigger);
    return;
  }

  if (!mobilePopupMenu.hidden
    && !event.target.closest("#mobile-popup-menu")
    && !event.target.closest("#mobile-menu-button")) {
    closeMobilePopup();
  }

  const viewButton = event.target.closest("[data-view]");
  if (viewButton) {
    const view = viewButton.dataset.view;
    if (view === "settings" && viewButton.closest(".system-nav")) {
      state.settingsSection = "general";
      state.networkSection = "overview";
      state.isNetworkOpen = false;
    }
    state.view = view;
    render({ focusMain: true });
    return;
  }

  const sendFamilyButton = event.target.closest("[data-send-family]");
  if (sendFamilyButton) {
    const draft = activeSendDraft();
    draft.family = sendFamilyButton.dataset.sendFamily;
    draft.itemKey = sendOptionEntries(draft.family)[0]?.key || "";
    draft.amount = "";
    draft.step = 0;
    draft.completed = null;
    render({ focusMain: true });
    return;
  }

  const exchangeProviderButton = event.target.closest("[data-exchange-provider]");
  if (exchangeProviderButton) {
    const form = document.querySelector("#exchange-entry");
    const draft = form ? captureExchangeDraft(form) : activeExchangeDraft();
    draft.providerId = exchangeProviderButton.dataset.exchangeProvider;
    draft.destinationId = demoRuntime.exchangeProvider(draft.providerId).defaultDestination;
    draft.orderType = "market";
    draft.limitPrice = "";
    draft.step = 0;
    render({ focusMain: true });
    requestAnimationFrame(() => document.querySelector(`[data-exchange-provider="${draft.providerId}"]`)?.focus());
    return;
  }

  const exchangeActionButton = event.target.closest("[data-exchange-action]");
  if (exchangeActionButton) {
    const draft = activeExchangeDraft();
    draft.step = 0;
    render({ focusMain: true });
    return;
  }

  const sendActionButton = event.target.closest("[data-send-action]");
  if (sendActionButton) {
    const action = sendActionButton.dataset.sendAction;
    const draft = activeSendDraft();
    if (action === "cancel") {
      resetActiveSendDraft();
      state.view = "wallet";
      render({ focusMain: true });
    } else if (action === "back") {
      draft.step = 0;
      draft.completed = null;
      render({ focusMain: true });
    } else if (action === "submit") {
      setButtonLoading(sendActionButton, "Sending once…");
      window.setTimeout(completeSend, 650);
    } else if (action === "history") {
      resetActiveSendDraft();
      state.view = "activity";
      render({ focusMain: true });
    } else if (action === "done") {
      resetActiveSendDraft();
      render({ focusMain: true });
    }
    return;
  }

  const walletSectionButton = event.target.closest("[data-wallet-section]");
  if (walletSectionButton) {
    state.view = "wallet";
    state.walletSection = walletSectionButton.dataset.walletSection;
    render({ focusMain: true });
    return;
  }

  const walletSettingsSectionButton = event.target.closest("[data-wallet-settings-section]");
  if (walletSettingsSectionButton) {
    state.view = "wallet-settings";
    state.walletSettingsSection = walletSettingsSectionButton.dataset.walletSettingsSection;
    render({ focusMain: true });
    return;
  }

  const flowButton = event.target.closest("[data-open-flow]");
  if (flowButton) {
    const flowData = flowButton.dataset.assetKey
      ? { assetKey: flowButton.dataset.assetKey }
      : flowButton.dataset.objectKind
        ? { objectKind: flowButton.dataset.objectKind, objectId: flowButton.dataset.objectId }
        : flowButton.dataset.objectId
          ? { objectId: flowButton.dataset.objectId }
      : flowButton.dataset.permissionId
        ? { permissionId: flowButton.dataset.permissionId }
        : {};
    openFlow(flowButton.dataset.openFlow, flowButton, flowData);
    return;
  }

  const activityButton = event.target.closest("[data-open-activity]");
  if (activityButton) {
    const item = activeWallet().activities.find((entry) => entry.id === activityButton.dataset.openActivity);
    if (item) openFlow("activity", activityButton, { item });
    return;
  }

  const walletButton = event.target.closest("[data-wallet-id]");
  if (walletButton && !walletButton.dataset.dialogAction) {
    state.selectedWalletId = walletButton.dataset.walletId;
    state.view = "wallet";
    state.activityFilter = "all";
    state.assetFilter = "all";
    render({ focusMain: true });
    return;
  }

  const filterButton = event.target.closest("[data-filter]");
  if (filterButton) {
    state.activityFilter = filterButton.dataset.filter;
    render();
    return;
  }

  const assetFilterButton = event.target.closest("[data-asset-filter]");
  if (assetFilterButton) {
    state.assetFilter = assetFilterButton.dataset.assetFilter;
    render();
    return;
  }

  const settingButton = event.target.closest("[data-settings-section]");
  if (settingButton) {
    const section = settingButton.dataset.settingsSection;
    state.settingsSection = section;
    state.isNetworkOpen = ["reticulum", "onionnet"].includes(section);
    if (state.isNetworkOpen) state.networkSection = section;
    render();
    return;
  }

  const networkButton = event.target.closest("[data-network-section]");
  if (networkButton) {
    if (networkButton.closest("#network-nav")) {
      state.view = "telemetry";
      state.telemetrySource = networkButton.dataset.networkSection;
      state.isNetworkOpen = false;
      render({ focusMain: true });
      return;
    }
  }

  const reticulumTelemetryButton = event.target.closest("[data-reticulum-telemetry-tab]");
  if (reticulumTelemetryButton) {
    state.reticulumTelemetryTab = reticulumTelemetryButton.dataset.reticulumTelemetryTab;
    render();
    return;
  }

  const onionnetTelemetryButton = event.target.closest("[data-onionnet-telemetry-tab]");
  if (onionnetTelemetryButton) {
    state.onionnetTelemetryTab = onionnetTelemetryButton.dataset.onionnetTelemetryTab;
    render();
    return;
  }

  const aggregatorsTelemetryButton = event.target.closest("[data-aggregators-telemetry-tab]");
  if (aggregatorsTelemetryButton) {
    state.aggregatorsTelemetryTab = aggregatorsTelemetryButton.dataset.aggregatorsTelemetryTab;
    render();
    return;
  }

  const themeToggle = event.target.closest("[data-theme-toggle]");
  if (themeToggle && themeToggle.tagName === "BUTTON") {
    state.theme = state.theme === "dark" ? "light" : "dark";
    syncConfigDraftFromState();
    applyAppearancePreferences();
    render();
    showToast(`${state.theme === "dark" ? "Dark" : "Light"} theme applied locally.`);
    return;
  }

  const paletteButton = event.target.closest("[data-palette]");
  if (paletteButton && paletteButton.tagName === "BUTTON") {
    state.palette = paletteButton.dataset.palette;
    syncConfigDraftFromState();
    applyAppearancePreferences();
    render();
    showToast(`${paletteOptions.find((palette) => palette.id === state.palette)?.label || "Palette"} applied locally.`);
    return;
  }

  const codeThemeButton = event.target.closest("[data-code-theme]");
  if (codeThemeButton && codeThemeButton.tagName === "BUTTON") {
    state.codeTheme = codeThemeButton.dataset.codeTheme;
    syncConfigDraftFromState();
    applyAppearancePreferences();
    render();
    showToast(`${codeThemeOptions.find((theme) => theme.id === state.codeTheme)?.label || "Code"} highlighting applied across the application.`);
    return;
  }

  const configViewButton = event.target.closest("[data-config-view]");
  if (configViewButton) {
    state.configView = configViewButton.dataset.configView;
    render();
    return;
  }

  const closeButton = event.target.closest("[data-dialog-close]");
  if (closeButton) {
    closeDialog();
    return;
  }

  const dialogAction = event.target.closest("[data-dialog-action]");
  if (dialogAction) {
    handleDialogAction(dialogAction.dataset.dialogAction, dialogAction);
    return;
  }

  const demoAction = event.target.closest("[data-demo-action]");
  if (demoAction) handleDemoAction(demoAction.dataset.demoAction, demoAction);
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !mobilePopupMenu.hidden) {
    event.preventDefault();
    closeMobilePopup({ restoreFocus: true });
    return;
  }
  if (event.key === "Tab" && isMobileDrawer(mobilePopupType) && !mobilePopupMenu.hidden) {
    const focusable = [...mobilePopupMenu.querySelectorAll("button:not([disabled])")];
    if (focusable.length === 0) return;
    const first = focusable[0];
    const last = focusable.at(-1);
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }
});

window.addEventListener("resize", () => {
  if (!isMobileNavigation()) {
    closeMobilePopup();
  } else if (!mobilePopupMenu.hidden) {
    positionMobilePopup(mobilePopupTrigger);
  }
});

document.addEventListener("submit", (event) => {
  event.preventDefault();
  if (["wallet-rename-entry", "wallet-seed-reveal-entry", "wallet-public-export-entry", "wallet-key-rotation-entry", "wallet-policy-apply-entry"].includes(event.target.id)) {
    validateWalletSettingsAction(event.target);
  } else if (event.target.id === "wallet-password-change-entry") {
    validateWalletPasswordChange(event.target);
  } else if (event.target.id === "create-voucher-entry") {
    const form = event.target;
    const result = walletGateway.createVoucher({
      walletId: activeWallet().id,
      title: form.elements.title.value,
      amount: form.elements.amount.value,
      expiry: form.elements.expiry.value
    });
    const error = document.querySelector("#voucher-create-error");
    if (!result.ok) {
      error.textContent = result.error.message;
      form.elements.title.focus();
      return;
    }
    const wallet = activeWallet();
    wallet.activities.unshift({ id: `voucher-create-${wallet.activities.length + 1}`, type: "voucher", direction: "neutral", title: `${result.data.voucher.title} created`, detail: "Ready to transfer", amount: result.data.voucher.value, time: "Now", status: "active" });
    closeDialog();
    render({ focusMain: true });
    showToast("Voucher created and available in Send.");
  } else if (event.target.id === "create-permission-entry") {
    const form = event.target;
    const result = walletGateway.createPermission({
      walletId: activeWallet().id,
      title: form.elements.title.value,
      action: form.elements.action.value,
      scope: form.elements.scope.value,
      uses: form.elements.uses.value,
      expiry: form.elements.expiry.value
    });
    const error = document.querySelector("#permission-create-error");
    if (!result.ok) {
      error.textContent = result.error.message;
      form.elements.title.focus();
      return;
    }
    const wallet = activeWallet();
    wallet.activities.unshift({ id: `permission-create-${wallet.activities.length + 1}`, type: "permission", direction: "neutral", title: `${result.data.permission.title} created`, detail: "Held · ready to transfer", amount: "", time: "Now", status: "active" });
    closeDialog();
    render({ focusMain: true });
    showToast("Permission created and available in Send.");
  } else if (event.target.id === "send-entry") {
    validateSend(event.target);
  } else if (event.target.id === "exchange-entry") {
    validateExchange(event.target);
  } else if (event.target.id === "permission-entry") {
    validatePermission(event.target);
  } else if (event.target.id === "create-wallet-entry") {
    const name = event.target.elements.walletLabel;
    const chainId = event.target.elements.chainId;
    const password = event.target.elements.newWalletSecret;
    const confirm = event.target.elements.confirmWalletSecret;
    let valid = true;
    document.querySelector("#create-name-error").textContent = "";
    document.querySelector("#create-chain-error").textContent = "";
    document.querySelector("#create-password-error").textContent = "";
    document.querySelector("#create-confirm-error").textContent = "";
    [name, chainId, password, confirm].forEach((field) => field.removeAttribute("aria-invalid"));
    if (name.value.trim().length < 2) {
      document.querySelector("#create-name-error").textContent = "Enter a recognizable wallet name.";
      name.setAttribute("aria-invalid", "true");
      valid = false;
    }
    if (!walletChainOptions.some(({ id }) => id === chainId.value)) {
      document.querySelector("#create-chain-error").textContent = "Choose a supported wallet chain.";
      chainId.setAttribute("aria-invalid", "true");
      valid = false;
    }
    if (password.value.length < 8) {
      document.querySelector("#create-password-error").textContent = "Use at least 8 characters.";
      password.setAttribute("aria-invalid", "true");
      valid = false;
    }
    if (confirm.value !== password.value) {
      document.querySelector("#create-confirm-error").textContent = "Passwords do not match.";
      confirm.setAttribute("aria-invalid", "true");
      valid = false;
    }
    if (!valid) {
      event.target.querySelector('[aria-invalid="true"]')?.focus();
      return;
    }
    state.flow.data.name = name.value.trim();
    state.flow.data.chainId = chainId.value;
    state.flow.step = 1;
    renderDialog();
  } else if (event.target.id === "create-wallet-verify") {
    const verificationIndexes = state.flow.data.verificationIndexes;
    const wordSelectors = [...event.target.querySelectorAll("select[data-seed-index]")];
    const firstIncorrect = wordSelectors.find((select) => select.value !== demoSeedWords[Number(select.dataset.seedIndex)]);
    if (wordSelectors.length !== 4 || firstIncorrect) {
      document.querySelector("#seed-verify-error").textContent = `Choose the words shown at positions ${seedVerificationPositionList(verificationIndexes)}.`;
      firstIncorrect?.focus();
      return;
    }
    state.flow.step = 3;
    renderDialog();
  } else if (event.target.id === "open-wallet-entry") {
    const name = event.target.elements.name;
    const error = document.querySelector("#open-wallet-error");
    error.textContent = "";
    name.removeAttribute("aria-invalid");
    if (name.value.trim().length < 2) {
      error.textContent = "Enter a recognizable wallet name.";
      name.setAttribute("aria-invalid", "true");
      name.focus();
      return;
    }
    const wallet = addWalletProfile(name.value.trim(), "mainnet", "Scanning");
    state.selectedWalletId = wallet.id;
    state.view = "wallet";
    state.activityFilter = "all";
    state.assetFilter = "all";
    closeDialog();
    render({ focusMain: true });
    showToast("Existing wallet opened; scan continues.");
  } else if (event.target.id === "recover-wallet-entry") {
    const name = event.target.elements.name;
    const phraseA = event.target.elements.phraseA.value.trim().split(/\s+/).filter(Boolean);
    const phraseB = event.target.elements.phraseB.value.trim().split(/\s+/).filter(Boolean);
    const error = document.querySelector("#recover-phrase-error");
    const nameError = document.querySelector("#recover-name-error");
    error.textContent = "";
    nameError.textContent = "";
    name.removeAttribute("aria-invalid");
    if (name.value.trim().length < 2) {
      nameError.textContent = "Enter a recognizable wallet name.";
      name.setAttribute("aria-invalid", "true");
      name.focus();
      return;
    }
    if (phraseA.length !== 24 || phraseB.length !== 24) {
      error.textContent = "Both entries must contain exactly 24 words.";
      event.target.elements.phraseA.focus();
      return;
    }
    if (phraseA.join(" ") !== phraseB.join(" ")) {
      error.textContent = "The two recovery phrase entries do not match.";
      event.target.elements.phraseB.focus();
      return;
    }
    event.target.elements.phraseA.value = "";
    event.target.elements.phraseB.value = "";
    state.flow.data.name = name.value.trim();
    state.flow.step = 1;
    renderDialog();
  } else if (event.target.id === "unlock-form") {
    const input = document.querySelector("#unlock-password");
    if (input.value.length < 4) {
      document.querySelector("#unlock-error").textContent = "Enter at least four characters for this concept.";
      input.setAttribute("aria-invalid", "true");
      input.focus();
      return;
    }
    input.removeAttribute("aria-invalid");
    input.value = "";
    state.locked = false;
    lockScreen.hidden = true;
    appShell.hidden = false;
    appShell.inert = false;
    render();
    document.querySelector('[data-demo-action="lock"]')?.focus();
    showToast("Wallet unlocked for this concept.");
  }
});

document.addEventListener("input", (event) => {
  if (["send-recipient", "send-amount", "send-memo"].includes(event.target.id)) {
    const draft = activeSendDraft();
    if (event.target.id === "send-recipient") draft.recipient = event.target.value;
    if (event.target.id === "send-amount") draft.amount = event.target.value;
    if (event.target.id === "send-memo") draft.memo = event.target.value;
  } else if (event.target.closest("#exchange-entry")) {
    captureExchangeDraft(event.target.form);
  } else if (event.target.id === "activity-search") {
    const term = event.target.value.trim().toLowerCase();
    const items = activeWallet().activities.filter((item) => {
      const matchesFilter = matchesActivityFilter(item, state.activityFilter);
      return matchesFilter && `${activityText(item, "title")} ${activityText(item, "detail")} ${item.id}`.toLowerCase().includes(term);
    });
    document.querySelector("#activity-results").innerHTML = activityRows(items);
  } else if (event.target.classList.contains("seed-entry")) {
    const count = event.target.value.trim() ? event.target.value.trim().split(/\s+/).length : 0;
    const hint = event.target.closest(".field-group")?.querySelector(".field-hint");
    if (hint) hint.textContent = `${count} of 24 words`;
  } else if (event.target.id === "config-yaml") {
    state.configDraft = event.target.value;
    const result = validateAndApplyDemoConfig(state.configDraft);
    state.configStatus = result.message;
    event.target.setAttribute("aria-invalid", String(!result.valid));
    syncYamlHighlight(event.target);
  } else if (event.target.id === "wallet-settings-yaml") {
    state.walletSettingsConfigDraft = event.target.value;
    const result = validateAndApplyWalletSettingsYaml(state.walletSettingsConfigDraft);
    state.configStatus = result.message;
    event.target.setAttribute("aria-invalid", String(!result.valid));
    syncYamlHighlight(event.target);
  }
});

document.addEventListener("scroll", (event) => {
  if (event.target instanceof HTMLTextAreaElement && event.target.classList.contains("yaml-editor")) syncYamlHighlight(event.target);
}, true);

document.addEventListener("change", (event) => {
  if (event.target.id === "send-item") {
    const form = event.target.form;
    const draft = activeSendDraft();
    draft.recipient = form.elements.recipient.value;
    draft.memo = form.elements.memo.value;
    draft.itemKey = event.target.value;
    draft.amount = "";
    render();
    requestAnimationFrame(() => document.querySelector("#send-item")?.focus());
    return;
  }
  if (event.target.closest("#exchange-entry")) {
    const draft = captureExchangeDraft(event.target.form);
    if (["exchange-source", "exchange-order-type"].includes(event.target.id)) {
      render();
      requestAnimationFrame(() => document.querySelector(`#${event.target.id}`)?.focus());
    } else {
      state.exchangeDrafts[activeWallet().id] = draft;
    }
    return;
  }
  if (event.target.matches("[data-remove-wallet-id]")) {
    const walletId = event.target.dataset.removeWalletId;
    const selectedIds = new Set(state.flow?.data.walletIds || []);
    if (event.target.checked) selectedIds.add(walletId);
    else selectedIds.delete(walletId);
    state.flow.data.walletIds = [...selectedIds];
    renderDialog();
    document.querySelector(`[data-remove-wallet-id="${walletId}"]`)?.focus();
    return;
  }
  const walletSettingsControl = event.target.dataset.walletSettingsControl;
  if (walletSettingsControl) {
    const preferences = activeWalletPreferences();
    if (walletSettingsControl === "currency") preferences.currency = event.target.value;
    if (walletSettingsControl === "default-fee") {
      if (!/^\d+(?:\.\d+)?$/.test(event.target.value.trim())) {
        showToast("Default fee must be a non-negative decimal.", "alert");
        render();
        return;
      }
      preferences.defaultFee = event.target.value.trim();
    }
    if (walletSettingsControl === "lock-after") preferences.lockAfterMinutes = event.target.value;
    if (walletSettingsControl === "backup-interval") preferences.backupIntervalHours = event.target.value;
    state.walletSettingsConfigDraft = "";
    syncConfigDraftFromState();
    render();
    showToast(`${activeWallet().name} wallet setting updated locally.`);
    return;
  }
  const configControl = event.target.dataset.configControl;
  if (configControl) {
    const languageChanged = configControl === "language" && state.language !== event.target.value;
    if (configControl === "language") state.language = i18n.resolveLanguage(event.target.value);
    if (configControl === "regional-locale") state.regionalLocale = event.target.value;
    if (configControl === "time-zone") state.timeZone = event.target.value;
    if (configControl === "network-units") state.networkUnits = event.target.value;
    if (configControl === "palette") state.palette = event.target.value;
    if (configControl === "text-scale") state.textScale = event.target.value;
    if (configControl === "code-theme") state.codeTheme = event.target.value;
    if (configControl === "lock-after") {
      state.autoLockMinutes = event.target.value;
      activeWalletPreferences().lockAfterMinutes = event.target.value;
    }
    if (configControl === "default-fee") activeWalletPreferences().defaultFee = event.target.value.trim();
    syncConfigDraftFromState();
    applyAppearancePreferences();
    render();
    if (languageChanged) showToast(t("app.languageChanged"));
    return;
  }
});

document.addEventListener("click", (event) => {
  const toggle = event.target.closest("[data-toggle-password]");
  if (!toggle) return;
  const input = document.querySelector("#unlock-password");
  const visible = input.classList.toggle("is-revealed");
  toggle.setAttribute("aria-label", visible ? "Hide password" : "Show password");
  toggle.querySelector("use").setAttribute("href", visible ? "#i-eye-off" : "#i-eye");
});

dialog.addEventListener("click", (event) => {
  if (event.target !== dialog) return;
  const rect = dialog.getBoundingClientRect();
  const inside = event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
  if (!inside) closeDialog();
});

dialog.addEventListener("close", () => {
  state.flow = null;
  const trigger = state.lastDialogTrigger;
  state.lastDialogTrigger = null;
  if (trigger?.isConnected) trigger.focus();
});

syncConfigDraftFromState();
applyAppearancePreferences();
render();
