#!/bin/bash

LOGGER_ROOT=".github/logs/copilot-sessions"
LOGGER_SESSION_DIR="$LOGGER_ROOT"
LOGGER_FALLBACK_FILE="$LOGGER_ROOT/fallback-events.jsonl"

logger_ensure_dirs() {
    mkdir -p "$LOGGER_SESSION_DIR"
}

logger_extract_session_id() {
    local payload="${1:-}"

    if [[ -z "$payload" ]]; then
        return 0
    fi

    printf '%s' "$payload" | jq -r '
        first(
            .. | objects |
            (.sessionId? // .session_id? // .conversationId? // .conversation_id? // .chatSessionId? // .chat_session_id? // .chatId? // .chat_id?) |
            strings |
            select(length > 0)
        ) // empty
    ' 2>/dev/null || true
}

logger_sanitize_id() {
    local raw_id="${1:-}"

    printf '%s' "$raw_id" | tr -cs 'A-Za-z0-9._-' '_'
}

logger_payload_hash() {
    local payload="${1:-}"

    printf '%s' "$payload" | sha256sum | awk '{print $1}'
}

logger_target_file() {
    local session_id="${1:-}"

    if [[ -n "$session_id" ]]; then
        printf '%s/%s.jsonl\n' "$LOGGER_SESSION_DIR" "$session_id"
        return 0
    fi

    printf '%s\n' "$LOGGER_FALLBACK_FILE"
}

logger_append_event() {
    local event_name="$1"
    local payload="${2:-}"
    local level="${3:-INFO}"

    logger_ensure_dirs

    local timestamp cwd payload_hash session_id_raw session_id session_id_source target_file
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    cwd=$(pwd)
    payload_hash=$(logger_payload_hash "$payload")
    session_id_raw=$(logger_extract_session_id "$payload")
    session_id=""
    session_id_source="none"

    if [[ -n "$session_id_raw" ]]; then
        session_id=$(logger_sanitize_id "$session_id_raw")
        session_id_source="payload"
    fi

    target_file=$(logger_target_file "$session_id")

    jq -cn \
        --arg timestamp "$timestamp" \
        --arg event "$event_name" \
        --arg cwd "$cwd" \
        --arg level "$level" \
        --arg session_id "$session_id" \
        --arg session_id_source "$session_id_source" \
        --arg payload_sha256 "$payload_hash" \
        --arg target_file "$target_file" \
        '{
            timestamp: $timestamp,
            event: $event,
            cwd: $cwd,
            level: $level,
            session_id: ($session_id | if . == "" then null else . end),
            session_id_source: $session_id_source,
            payload_sha256: $payload_sha256,
            target_file: $target_file
        }' >> "$target_file"
}