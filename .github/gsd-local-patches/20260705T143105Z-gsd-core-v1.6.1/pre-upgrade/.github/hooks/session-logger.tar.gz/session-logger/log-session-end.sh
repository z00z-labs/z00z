#!/bin/bash

# Log session end event

set -euo pipefail

# Skip if logging disabled
if [[ "${SKIP_LOGGING:-false}" == "true" ]]; then
  exit 0
fi

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=.github/hooks/session-logger/common.sh
source "$SCRIPT_DIR/common.sh"

# Read input from Copilot
INPUT=$(cat)

logger_append_event "sessionEnd" "$INPUT" "${LOG_LEVEL:-INFO}"

exit 0
