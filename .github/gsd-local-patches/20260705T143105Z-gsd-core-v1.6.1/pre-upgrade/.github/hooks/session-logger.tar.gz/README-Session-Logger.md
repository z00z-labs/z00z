---
name: 'Session Logger'
description: 'Logs all Copilot coding agent session activity for audit and analysis'
tags: ['logging', 'audit', 'analytics']
---

# Session Logger Hook

Comprehensive logging for GitHub Copilot coding agent sessions, tracking session starts, ends, and user prompts for audit trails and usage analytics.

## Overview

This hook provides detailed logging of Copilot coding agent activity:

- Session start/end times with working directory context
- User prompt submission events
- Configurable log levels
- Per-session JSONL files when the hook payload contains a stable session identifier

## Features

- **Session Tracking**: Log session start and end events
- **Prompt Logging**: Record when user prompts are submitted
- **Structured Logging**: JSON format for easy parsing
- **Privacy Aware**: Configurable to disable logging entirely

## Installation

1. Copy this hook folder to your repository's `.github/hooks/` directory:

   ```bash
   cp -r hooks/session-logger .github/hooks/
   ```

2. Create the logs directory:

   ```bash
   mkdir -p .github/logs/copilot-sessions
   ```

3. Ensure scripts are executable:

   ```bash
   chmod +x .github/hooks/session-logger/*.sh
   ```

4. Commit the hook configuration to your repository's default branch

## Log Format

Events are written in JSONL format under `.github/logs/copilot-sessions/`.

- When the hook payload exposes a stable session identifier such as `sessionId` or `conversationId`, the event is appended to `.github/logs/copilot-sessions/<session-id>.jsonl`.
- When the payload does not expose a stable session identifier, the event is appended to `.github/logs/copilot-sessions/fallback-events.jsonl`.

This means parallel chat sessions are isolated into separate files only when Copilot provides a stable session identifier in the hook payload. The logger records that fact in each event as `session_id` and `session_id_source`.

Example event:

```json
{"timestamp":"2024-01-15T10:30:00Z","event":"sessionStart","cwd":"/workspace/project","level":"INFO","session_id":"abc123","session_id_source":"payload","payload_sha256":"...","target_file":".github/logs/copilot-sessions/abc123.jsonl"}
{"timestamp":"2024-01-15T10:35:00Z","event":"sessionEnd","cwd":"/workspace/project","level":"INFO","session_id":null,"session_id_source":"none","payload_sha256":"...","target_file":".github/logs/copilot-sessions/fallback-events.jsonl"}
```

## Privacy & Security

- Add `logs/` and `.github/logs/copilot-sessions/` to `.gitignore` to avoid committing session data
- The repository hook config sets `LOG_LEVEL=INFO` and `SKIP_LOGGING=false`
- Set `SKIP_LOGGING=true` in the hook environment to disable logging
- Logs are stored locally only
